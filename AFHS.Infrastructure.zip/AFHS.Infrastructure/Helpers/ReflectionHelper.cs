﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Helpers
{
    public class ReflectionHelper
    {
        /// <summary>
        /// Compares only the provided fields name on the dictionary, between the provided objects.
        /// This compares each KeyValuePair as following: objectForKeys[Key] == objectForValues[Value] ?
        /// </summary>
        /// <typeparam name="A">The type of the 'objectForKeys'</typeparam>
        /// <typeparam name="B">The type of the 'objectForValues'</typeparam>
        /// <param name="objectForKeys">The object that has the fields names as keys on the dictionary</param>
        /// <param name="objectForValues">The object that has the fields names as values on the dictionary</param>
        /// <param name="FieldNames">A dictionary that contains the matching field names to compare as following:
        /// Keys: All the keys must be field name of the provided 'objectForKeys'
        /// Values: All the values must be field name of the provided 'objectForValues'</param>
        /// <returns>Returns those KeyValuePairs where the compared objects hasn't the same values</returns>
        public static Dictionary<string, string> GetFieldsWithDifferences<T, S>(T objectForKeys, S objectForValues, Dictionary<string, string> FieldNames)
        {
            Dictionary<string, string> FieldsWithDifferences = new Dictionary<string, string>();

            var QueryResult = (from field in FieldNames
                               where !(typeof(T).GetProperty(field.Key).GetValue(objectForKeys, null).Equals(
                               typeof(S).GetProperty(field.Value).GetValue(objectForValues, null)))
                               select field);
            foreach (KeyValuePair<string, string> field in QueryResult)
                FieldsWithDifferences.Add(field.Key, field.Value);

            return FieldsWithDifferences;
        }

        /// <summary>
        /// Applies the values from 'objectToRead' on 'objectToWrite' for the specified fields on 'FieldsToCopy'
        /// </summary>
        /// <typeparam name="WT">The type of 'objectToWrite'</typeparam>
        /// <typeparam name="RT">The type of 'objectToRead'</typeparam>
        /// <param name="objectToWrite">The object that needs to update their values with values from 'objectToRead'</param>
        /// <param name="objectToRead">The object that contains the values to be applied on 'objectToWrite'</param>
        /// <param name="FieldsToCopy">A dictionary that contains the matching field names to copy as following:
        /// Keys: All the keys must be field name of the provided 'objectToWrite'
        /// Values: All the values must be field name of the provided 'objectToRead'</param>
        /// <returns>The provided 'objectToWrite' with the values from 'objectToRead' applied</returns>
        public static WT PerformChangesForFields<WT, RT>(WT objectToWrite, RT objectToRead, Dictionary<string, string> FieldsToCopy)
        {
            foreach (KeyValuePair<string, string> fieldToCopy in FieldsToCopy)
            {
                PropertyInfo WriteInfoField = typeof(WT).GetProperty(fieldToCopy.Key);
                PropertyInfo ReadInfoField = typeof(RT).GetProperty(fieldToCopy.Key);
                WriteInfoField.SetValue(objectToWrite, ReadInfoField.GetValue(objectToRead, null));
            }
            return objectToWrite;
        }
    }
}
