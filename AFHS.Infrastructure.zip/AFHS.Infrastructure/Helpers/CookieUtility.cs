﻿using AFM.Commerce.Framework.Extensions.Utils;
using Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Helpers
{
    
        /// <summary>
        /// Cookie Key for storing the CartCounter
        /// </summary>
        /// 
    
    public static class CookieUtility
    {
        public static readonly string CartCounterCookie = "afmCartCount";
        public static readonly string AffiliationIdCookie = "AffiliationId";

        public static void SetAffiliationIdCookieWithExpiry(long value, DateTime expireDate) 
        {
            RemoveCookie(AffiliationIdCookie);
            HttpContext.Current.Response.Cookies.Add(new HttpCookie(AffiliationIdCookie, value.ToString()));
            HttpContext.Current.Response.Cookies[AffiliationIdCookie].Expires = expireDate;
            HttpContext.Current.Response.Cookies[AffiliationIdCookie].HttpOnly = false;
        }

        public static long GetAffiliationIdFromCookie()
        {
            var affiliationIdCookieValue = CookieManager.GetRequestCookieValue(HttpContext.Current, AffiliationIdCookie);
            bool hasData = !string.IsNullOrWhiteSpace(affiliationIdCookieValue) && !string.IsNullOrEmpty(affiliationIdCookieValue);
            return (!hasData ? 0 : Convert.ToInt64(affiliationIdCookieValue));
        }

        public static void SetAFMZipCodeWithExpiry(string value, DateTime expireDate)
        {
            AFMDataUtilities.ClearAFMZipCodeFromCookie();
            AFMDataUtilities.SetAFMZipCodeInCookie(value);
            HttpContext.Current.Response.Cookies["AFMZipCode"].Value = value;
            HttpContext.Current.Response.Cookies["AFMZipCode"].Expires = expireDate;
            long affiliationId = PricingHelper.GetAffiliationIdByZipCode(value);
            SetAffiliationIdCookieWithExpiry(affiliationId, expireDate);
        }

        public static string GetZipCodeFromCookie()
        {
            var zipCodeConstant = CookieConstants.AFMZipCode;
            var zipCodeCookieValue = CookieManager.GetRequestCookieValue(HttpContext.Current, zipCodeConstant);
            bool hasData = !string.IsNullOrWhiteSpace(zipCodeCookieValue) && !string.IsNullOrEmpty(zipCodeCookieValue);
            if (!hasData)
                zipCodeCookieValue = !string.IsNullOrEmpty(HttpContext.Current.Response.Cookies["AFMZipCode"].Value) ? 
                                    HttpContext.Current.Response.Cookies["AFMZipCode"].Value : string.Empty;
            return !hasData ? string.Empty : zipCodeCookieValue;
        }

        public static void SetCookieCartCount(int count)
        {
            CookieManager.SetResponseCookieValue(HttpContext.Current, CartCounterCookie, count.ToString(),
                DateTime.Now.AddDays(30), false, true);  
        }

        public static string GetCookieCartCount()
        {
            return CookieManager.GetRequestCookieValue(HttpContext.Current, CartCounterCookie);
        }

        public static void RemoveCookie(string cookieName)
        {
            CookieManager.DeleteCookie(HttpContext.Current, cookieName);
        }

        public static void ClearAllCookies()
        {
            RemoveCookie(CartCounterCookie);
            AFMDataUtilities.ClearCustomerIdFromCookie();
            AFMDataUtilities.ClearUserCartInfoFromCookie();            
            AFMDataUtilities.ClearCartIdResponseCookies(SessionType.All);
            AFMDataUtilities.ClearCheckoutCartIdResponseCookies(SessionType.All);
            AFMDataUtilities.ClearUserPageModeFromCookie();
        }
    }
}
