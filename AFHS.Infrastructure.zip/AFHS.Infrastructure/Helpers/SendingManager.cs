﻿using Sitecore.Diagnostics;
using Sitecore.Modules.EmailCampaign;
using Sitecore.Modules.EmailCampaign.Core.Dispatch;
using Sitecore.Modules.EmailCampaign.Core.MessageTransfer;
using Sitecore.Modules.EmailCampaign.Core.Pipelines;
using Sitecore.Modules.EmailCampaign.Core.Pipelines.SendEmail;
using Sitecore.Modules.EmailCampaign.Messages;
using SCModules=Sitecore.Modules;

namespace Afhs.Infrastructure.Helpers
{
    public class SendingManager : global::Sitecore.Modules.EmailCampaign.SendingManager
    {
        protected bool DedicatedInstance { get; set; }
        protected SMTPSettings MailSettings { get; set; }
        private SendingProcessData processData;
        protected SendingProcessData ProcessData
        {
            get
            {
                if (processData == null)
                {
                    processData = new SendingProcessData();
                }
                return processData;
            }
        }
        protected MessageItem Message { get; set; }

        public SendingManager(MessageItem message)
            : base(message)
        {
            Message = message;
            string smptSetingsError = "";
            MailSettings = GetSmtpSettings(out smptSetingsError);
        }

        public SendingManager(MessageItem message, bool isService)
            : base(message, isService)
        {
            Message = message;
            var smptSetingsError = "";
            MailSettings = GetSmtpSettings(out smptSetingsError);
            DedicatedInstance = isService;
        }


        protected string SendNonCampaignMessageCore(Contact receiver)
        {
            Assert.ArgumentNotNull(receiver, "receiver");

            if (Message is INonCampaignEmail)
            {
                INonCampaignEmail message = Message as INonCampaignEmail;
                if (message != null)
                {
                    if (!message.SendAsCampaign)
                    {
                        Message.To = receiver.Profile.Email;
                        Message.PersonalizationContact = receiver;

                        if (Message.Body == null)
                            Message.Body = Message.GetMessageBody();

                        SendMessageArgs paramz = new SendMessageArgs(Message, new FakeTask(Message, MailSettings));
                        FillEmail fill = new FillEmail();
                        fill.Process(paramz);

                        SendEmail sender = new SendEmail();
                        sender.Process(paramz);
                    }
                    else
                    {
                        SendStandardMessage(receiver);
                    }
                }
            }
            return "";
        }

        public string SendNonCampaignMessage(Contact receiver)
        {
            string str;
            Assert.ArgumentNotNull(receiver, "receiver");
            if (HasAccessToMailServer(false, out str))
            {
                return SendNonCampaignMessageCore(receiver);
            }
            return str;
        }
    }
    public interface INonCampaignEmail
    {
        bool SendAsCampaign
        {
            get;
            set;
        }
    }
}
