﻿using Afhs.Data.CustomClasses;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Afhs.Infrastructure.Cache;
using AFM.Commerce.Entities;
using AFM.Commerce.Framework.Core.Models;
using AFM.Commerce.Services;
using Glass.Mapper.Sc;
using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Text;

namespace Afhs.Infrastructure.Helpers
{
    public static class PricingHelper
    {
        #region Public Methods

        public static long GetAffiliationIdByZipCode(string zipCode)
        {
            var cachedAffiliationId = GlobalCachingProvider<long>.Instance.GetItem(zipCode, false);
            if (cachedAffiliationId != null)
            {
                return (long)cachedAffiliationId;
            }

            long affiliationId = 0;
            var priceService = new AFMPricingService();

            AFMVendorAffiliation affiliation = priceService.GetAffiliationByZipCode(zipCode);
            if (affiliation != null)
            {
                affiliationId = affiliation.AffiliationId;
            }

            GlobalCachingProvider<long>.Instance.AddItem(zipCode, affiliationId);

            return affiliationId;
        }

        public static ProductWithPrice GetProductWithPrice(string productId, long affiliationId = 0)
        {
            using (new ProfileSection("Afhs.Infrastructure.Helpers.PricingHelper.GetProductWithPrice"))
            {
                ProductWithPrice result;

                try
                {
                    var productWithPrice = GetProductFromCache(affiliationId.ToString() + productId);

                    if (productWithPrice == null)
                    {
                        var prices = GetPrices(new List<string> { productId }, affiliationId);
                        AFMItemPriceSnapshot affiliationIdPrice = null;

                        if (prices != null && prices.Count > 0)
                        {
                            //affiliationIdPrice = prices.FirstOrDefault(x => x.AffiliationId == affiliationId);
                            affiliationIdPrice = prices.FirstOrDefault();
                        }

                        if (affiliationIdPrice != null)
                        {
                            productWithPrice = new ProductWithPrice
                            {
                                ExternalId = productId,
                                RegularPrice = affiliationIdPrice.BasePrice,
                                SalePrice = affiliationIdPrice.BestPrice
                            };
                        }
                        else
                        {
                            productWithPrice = GetZeroProductWithPrice(productId, true);
                        }

                        CacheProduct(productWithPrice, affiliationId);
                    }

                    return productWithPrice;
                }
                catch (Exception ex)
                {
                    var errorMessage = new StringBuilder();
                    errorMessage.Append("An exception was thrown getting price for productid=");
                    errorMessage.Append(productId);
                    errorMessage.Append(", setting price to zero. This product will NOT BE CACHED");
                    errorMessage.Append(ex.Message);
                    errorMessage.Append(ex.StackTrace);

                    Log.Error(errorMessage.ToString(), typeof(PricingHelper));

                    result = GetZeroProductWithPrice(productId, false);
                }

                return result;
            }
        }

        public static List<ProductWithPrice> GetProductsWithPrice(List<ExtendedProduct> products, long affiliationId = 0)
        {
            using (new ProfileSection("Afhs.Infrastructure.Helpers.PricingHelper.GetProductsWithPrice"))
            {
                if (products != null && products.Count > 0)
                {
                    var productIds = products.Select(c => c.ExternalID).Distinct().ToList();
                    var productsWithPrice = GetProductsPrice(productIds, affiliationId);

                    return productsWithPrice;
                }
                return new List<ProductWithPrice>();
            }
        }

        public static List<ProductWithPrice> GetProductsWithPrice(List<ProductSearchResultItem> products, long affiliationId = 0)
        {
            using (new ProfileSection("Afhs.Infrastructure.Helpers.PricingHelper.GetProductsWithPrice"))
            {
                if (products.Count > 0)
                {
                    var productIds = products.Select(c => c.ExternalID).Distinct().ToList();
                    var productsWithPrice = GetProductsPrice(productIds, affiliationId);
                    return productsWithPrice;
                }
                return new List<ProductWithPrice>();
            }
        }

        public static decimal GetProductPrice(string productId, long affiliationId = 0)
        {
            using (new ProfileSection("Afhs.Infrastructure.Helpers.PricingHelper.GetProductPrice"))
            {
                var productWithPrice = GetProductWithPrice(productId, affiliationId);
                return decimal.Round(productWithPrice.RegularPrice < 0 ? productWithPrice.RegularPrice : productWithPrice.SalePrice, 2);
            }
        }

        public static List<ProductWithPrice> GetProductsPrice(IEnumerable<string> productsIds, long affiliationId = 0)
        {
            using (new ProfileSection("AFHS.Web.Support.PricingHelper.GetProductsPrice"))
            {
                var result = new List<ProductWithPrice>();

                try
                {
                    var uncachedProductIds = new List<string>();

                    foreach (var productId in productsIds)
                    {
                        Log.Info("Start:Retrevied from Cache filter data", "");
                        var productFromCache = GetProductFromCache(affiliationId.ToString() + productId);
                        Log.Info("End:Retrevied from Cache filter data", "");

                        if (productFromCache != null)
                        {
                            result.Add(productFromCache);
                        }
                        else
                        {
                            uncachedProductIds.Add(productId);
                        }
                    }

                    Log.Info("Start CRT Call to retreive the filter data","");

                    var pricesFromAX = GetPrices(uncachedProductIds, affiliationId);

                    Log.Info("End CRT Call to retreive the filter data", "");
                    foreach (var productId in uncachedProductIds)
                    {
                        var productWithPrice = new ProductWithPrice
                        {
                            ExternalId = productId
                        };

                        //var price = pricesFromAX.FirstOrDefault(x => x.ItemId == productId);
                        //var price = pricesFromAX.Where(x => x.ItemId == productId).FirstOrDefault(x => x.AffiliationId == affiliationId);
                        var price = pricesFromAX.Where(x => x.ItemId == productId).FirstOrDefault();

                        if (price != null)
                        {
                            productWithPrice.RegularPrice = price.BasePrice;
                            productWithPrice.SalePrice = price.BestPrice;
                        }
                        else
                        {
                            productWithPrice = GetZeroProductWithPrice(productId, true);
                        }

                        CacheProduct(productWithPrice, affiliationId);

                        result.Add(productWithPrice);
                    }
                }
                catch (Exception ex)
                {
                    var errorMessage = new StringBuilder();
                    errorMessage.Append("Problem getting prices for productids=");

                    result.Clear();
                    foreach (var productid in productsIds)
                    {
                        errorMessage.Append(productid);
                        errorMessage.Append(",");

                        var zeroPriceProduct = GetZeroProductWithPrice(productid, false);
                        result.Add(zeroPriceProduct);
                    }

                    errorMessage.Append(" setting prices to zero. ");
                    errorMessage.Append(ex.Message);
                    errorMessage.Append(ex.StackTrace);

                    Log.Error(errorMessage.ToString(), typeof(PricingHelper));
                }

                return result;
            }
        }

        //public static decimal GetBestPrice(string externalId)
        //{
        //    using (new ProfileSection("Afhs.Infrastructure.Helpers.PricingHelper.GetBestPrice"))
        //    {
        //        decimal result;

        //        try
        //        {
        //            var cacheid = externalId + "_bestprice";
        //            var productWithPrice = GlobalCachingProvider<ProductWithPrice>.Instance.GetItem(cacheid, false) as ProductWithPrice;

        //            if (productWithPrice == null)
        //            {
        //                var prodIds = new List<string> { externalId };
        //                var priceService = new AFMPricingService();
        //                var prices = priceService.GetAllPrices(prodIds);
        //                decimal price = -1;

        //                if (prices != null && prices.AFMAllAffiliationPrices != null && prices.AFMAllAffiliationPrices.Count > 0)
        //                {
        //                    decimal.TryParse(prices.AFMAllAffiliationPrices[0].BestPrice, out price);
        //                }

        //                productWithPrice = new ProductWithPrice { ExternalId = externalId, BestPrice = price };
        //                GlobalCachingProvider<ProductWithPrice>.Instance.AddItem(cacheid, productWithPrice);
        //            }
        //            return productWithPrice.BestPrice;
        //        }
        //        catch (Exception ex)
        //        {
        //            var errorMessage = new StringBuilder();
        //            errorMessage.Append("Problem getting price for productid=");
        //            errorMessage.Append(externalId);
        //            errorMessage.Append(", setting price to zero. ");
        //            errorMessage.Append(ex.Message);
        //            errorMessage.Append(ex.StackTrace);

        //            Log.Error(errorMessage.ToString(), typeof(PricingHelper));
        //            result = 0;
        //        }

        //        return result;
        //    }
        //}

        #endregion
        #region Private Methods

        private static string GetProductSetCacheKey(List<string> productIds)
        {
            return string.Format("Set{0}", productIds.OrderBy(a => a).Aggregate((i, j) => i + j));
        }

        private static List<AfmAffiliationPrice> GetMockAffiliationList(List<string> products)
        {
            return products.Select(p => new AfmAffiliationPrice { AffiliationId = 0, ItemId = p, RegularPrice = 300, SalePrice = 200 }).ToList();
        }

        private static IReadOnlyCollection<AFMItemPriceSnapshot> GetPrices(IEnumerable<string> productIds, long affiliationId = 0)
        {
            if (productIds != null && productIds.Count() > 0)
            {
                var priceService = new AFMPricingService();
                //return priceService.GetPriceByAffiliation(0, productIds.ToList<string>());
                return priceService.GetPriceSnapshot(productIds.ToList<string>(), affiliationId);
            }
            else
                return new List<AFMItemPriceSnapshot>();
        }

        private static void CacheProduct(ProductWithPrice product, long affiliationId = 0)
        {
            if (product != null && !string.IsNullOrEmpty(product.ExternalId))
            {
                GlobalCachingProvider<ProductWithPrice>.Instance.AddItem(affiliationId.ToString() + product.ExternalId, product);
            }
        }

        private static ProductWithPrice GetProductFromCache(string key)
        {
            return GlobalCachingProvider<ProductWithPrice>.Instance.GetItem(key, false) as ProductWithPrice;
        }

        private static ProductWithPrice GetZeroProductWithPrice(string productId, bool log = true)
        {
            if (log)
            {
                var errorMessage = new StringBuilder();
                errorMessage.Append("Error getting price for product ");
                errorMessage.Append(productId);
                errorMessage.Append(" setting price to zero. ");
                errorMessage.Append("Error logged by PricingHelper.GetZeroProductWithPrice.");
                Log.Error(errorMessage.ToString(), typeof(PricingHelper));
            }

            var zeroPriceProduct = new ProductWithPrice
            {
                ExternalId = productId,
                RegularPrice = 0M,
                SalePrice = 0M
            };

            return zeroPriceProduct;
        }

    }
        #endregion
}
