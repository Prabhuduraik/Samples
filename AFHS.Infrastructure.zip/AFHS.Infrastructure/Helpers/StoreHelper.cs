﻿using Afhs.Data.CustomClasses;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Afhs.Infrastructure.BingMaps;
using Afhs.Infrastructure.Sitecore.StoreSync;
using Glass.Mapper.Sc;
using Sitecore.Data.Items;
using Sitecore.Links;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Helpers
{
    public class StoreHelper
    {
        public static string GetNearestStoreLocatorUrl(string zipCode = null)
        {
            var storeItem = GetNearestStoreItem(zipCode);
            string url = null;

            if(storeItem != null)
                url = LinkManager.GetItemUrl(storeItem);
            
            return url;
        }

        public static ExtendedStore GetNearestExtendedStore(string zipCode = null, int radius = 50)
        {
            if (string.IsNullOrEmpty(zipCode))
                return null;

            Item store = GetNearestStoreItem(zipCode, radius);
            if (store != null)
                return store.GlassCast<ExtendedStore>();
            else
                return null;
        }

        private static Item GetNearestStoreItem(string zipCode = null, int radius = 50)
        {
            Item storeItem = null;

            if (zipCode == null)
                zipCode = CookieUtility.GetZipCodeFromCookie();

            var country = GetCountryByZipCode(zipCode);

            WebServiceManager serviceManager = new WebServiceManager();

            if (!string.IsNullOrEmpty(country))
            {
                var store = serviceManager.GetNearestStore(zipCode, country);

                if (store != null && (!string.IsNullOrEmpty(store.CustomerNumber) && !string.IsNullOrEmpty(store.ShipTo)))
                {
                    SitecoreContext context = new SitecoreContext();
                    ExtendStoreLocator storeLocator = context.GetItem<ExtendStoreLocator>(Constants.GetContentPath("CONTENT_STORE_LOCATOR"));
                    var sitecoreStore = storeLocator.Stores.Where(x => x.CustomerNumber == store.CustomerNumber && x.ShipTo == store.ShipTo).FirstOrDefault();
                    if (sitecoreStore != null)
                        storeItem = sitecoreStore.item;
                }
            }

            return storeItem;
        }

        private static string GetCountryByZipCode(string zipCode)
        {
            string country = null;
            Regex zipCodeUS = new Regex(@"^([0-9]{5})(?:[-\s]*([0-9]{4}))?$");
            Regex zipCodeCA = new Regex(@"^([A-Z][0-9][A-Z])\s*([0-9][A-Z][0-9])$");

            if (zipCodeUS.IsMatch(zipCode))
            {
                country = "USA";
            }
            else if (zipCodeCA.IsMatch(zipCode))
            {
                country = "CA";
            }

            return country;
        }
    }
}
