﻿using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Helpers
{
    public class NoCharSetJsonMediaTypeFormatter : JsonMediaTypeFormatter
    {
        public override void SetDefaultContentHeaders(Type type, HttpContentHeaders headers, MediaTypeHeaderValue mediaType)
        {
            base.SetDefaultContentHeaders(type, headers, mediaType);
            headers.ContentType.CharSet = "";
        }
    }

    public static class HttpClientExtensions
    {
        public static async Task<HttpResponseMessage> PostAsJsonWithNoCharSetAsync<T>(this HttpClient client, string requestUri, T value, CancellationToken cancellationToken) { return await client.PostAsync(requestUri, value, new NoCharSetJsonMediaTypeFormatter(), cancellationToken); }
        public static async Task<HttpResponseMessage> PostAsJsonWithNoCharSetAsync<T>(this HttpClient client, string requestUri, T value) { 
            HttpResponseMessage ResponseClient = await client.PostAsync(requestUri, value, new NoCharSetJsonMediaTypeFormatter());
            ResponseClient.EnsureSuccessStatusCode();
            return ResponseClient; 
        }
    }

    public class AkamaiCacheClearerManager
    {
        static readonly string BaseUrl =  ConfigurationManager.AppSettings[Constants.WEBCONFIG_AKAMI_BASE_URL];
        static readonly string Username = ConfigurationManager.AppSettings[Constants.WEBCONFIG_AKAMI_USER];
        static readonly string Password = ConfigurationManager.AppSettings[Constants.WEBCONFIG_AKAMI_PASSWORD];
        static readonly string PurgueRequestUrl = ConfigurationManager.AppSettings[Constants.WEBCONFIG_AKAMI_PURGUE_REQUEST_URL];

        public static void RefreshMediaUrls(List<string> mediaUrls)
        {
            RunAsync(mediaUrls).Wait();
        }

        static async Task RunAsync(List<string> mediaUrls)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.Default.GetBytes(string.Format("{0}:{1}",Username,Password))));
                var objects = new { objects = mediaUrls };
                var purgueResponse = await client.PostAsJsonWithNoCharSetAsync(PurgueRequestUrl, objects);

                if (purgueResponse.IsSuccessStatusCode)
                {
                    var purgueRequest = await purgueResponse.Content.ReadAsAsync<PurgueRequestResponse>();

                    if(purgueRequest.httpStatus==201)
                    {
                        Log.Info("Purge request has been created successfully", typeof(AkamaiCacheClearerManager));  
                        var progressUri = purgueRequest.progressUri;
                        Thread.Sleep(purgueRequest.pingAfterSeconds * 1000);
                        HttpResponseMessage statusResponse;
                        var purgueStatus = new PurgueStatusRespose();

                        do
                        {
                            statusResponse = await client.GetAsync(progressUri);
                            
                            if (statusResponse.IsSuccessStatusCode)
                            {
                                purgueStatus = await statusResponse.Content.ReadAsAsync<PurgueStatusRespose>();

                                if (purgueRequest.httpStatus == 201)
                                {
                                    switch (purgueStatus.purgeStatus)
                                    {
                                        case "Done":
                                            Log.Info("Purge request has been completed successfully", typeof(AkamaiCacheClearerManager));
                                            break;
                                        case "In-Progress":
                                            Log.Info("Purge request is in-progress", typeof(AkamaiCacheClearerManager));
                                            Thread.Sleep(purgueStatus.pingAfterSeconds * 1000);
                                            break;
                                        case "Unknown":
                                            Log.Error("Purge Status check returns an 'Unknown' purge status.", typeof(AkamaiCacheClearerManager));
                                            break;
                                        default:
                                            Log.Error("Purge Status check returns an unexpected purge status.", typeof(AkamaiCacheClearerManager));
                                            break;
                                    }
                                }
                                else
                                {
                                    var error = await purgueResponse.Content.ReadAsAsync<ErrorResponse>();
                                    Log.Error(string.Format("HttpStatus:'{0}' Error:'{1}' Detail:'{2}'", error.httpStatus, error.title, error.detail), typeof(AkamaiCacheClearerManager));
                                }

                            }
                            else
                            {
                                Log.Error(string.Format("HttpStatus:'{0}' Reason:'{1}'", purgueResponse.StatusCode, purgueResponse.ReasonPhrase), typeof(AkamaiCacheClearerManager));
                            }

                        } while (statusResponse.IsSuccessStatusCode && purgueStatus.purgeStatus.Equals("In-Progress"));
                    }
                    else
                    {
                        var error = await purgueResponse.Content.ReadAsAsync<ErrorResponse>();
                        Log.Error(string.Format("HttpStatus:'{0}' Error:'{1}' Detail:'{2}'", error.httpStatus, error.title, error.detail), typeof(AkamaiCacheClearerManager));
                    }
                }
                else
                {
                    Log.Error(string.Format("HttpStatus:'{0}' Reason:'{1}'",purgueResponse.StatusCode, purgueResponse.ReasonPhrase),typeof(AkamaiCacheClearerManager));
                }
            }
        }

        private class PurgueRequestResponse
        {
            public int httpStatus;
            public string detail;
            public int estimatedSeconds;
            public string purgeId;
            public string progressUri;
            public int pingAfterSeconds;
            public string supportId;
        }

        private class PurgueStatusRespose
        {
            public int originalEstimatedSeconds;
            public string progressUri;
            public int originalQueueLength;
            public string purgeId;
            public string supportId;
            public int httpStatus;
            public string completionTime;
            public string submittedBy;
            public string purgeStatus;
            public string submissionTime;
            public int pingAfterSeconds;
        }

        private abstract class ErrorResponse 
        {
            public string supportId;
            public string title;
            public int httpStatus;
            public string detail;
            public string describedBy;
        }
    }
}
