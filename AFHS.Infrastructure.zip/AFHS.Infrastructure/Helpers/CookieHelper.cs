﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Helpers
{
    public static class CartCookieConstants
    {
        /// <summary>
        /// Cookie name for shopping cart token for the signed-in user.
        /// </summary>
        public static readonly string SignedInShoppingCartToken = "sisct";

        /// <summary>
        /// Cookie name for checkout cart token for the signed-in user.
        /// </summary>
        public static readonly string SignedInCheckoutCartToken = "sicct";

        /// <summary>
        /// Cookie name for shopping cart token for the anonymous user.
        /// </summary>
        public static readonly string AnonymousShoppingCartToken = "sct";

        /// <summary>
        /// Cookie name for checkout cart token for the anonymous user.
        /// </summary>
        public static readonly string AnonymousCheckoutCartToken = "cct";

        /// <summary>
        /// Token to test session cookie.
        /// </summary>
        internal const string MSAXSessionCookieCheck = "MSAXSCC";

        /// <summary>
        /// Token to test regular cookie.
        /// </summary>
        internal const string MSAXPersistentCookieCheck = "MSAXPCC";
    }

    public static class CookieHelper
    {
        public static string GetRequestCookieValue(HttpContext context, string cookieName)
        {
            try
            {
                if (context != null && context.Request != null && !string.IsNullOrWhiteSpace(cookieName))
                {
                    return GetCookieValue(context.Request.Cookies, cookieName);
                }

                return null;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message, e);
            }
        }

        public static string GetResponseCookieValue(HttpContext context, string cookieName)
        {
            try
            {
                if (context != null && context.Request != null && !String.IsNullOrWhiteSpace(cookieName))
                {
                    return GetCookieValue(context.Request.Cookies, cookieName);
                }

                return null;
            }
            catch (Exception e)
            {                
                throw e;
            }
        }

        public static void SetResponseCookieValue(HttpContext context, string cookieName, string cookieValue, DateTime expiry, bool isSecure)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cookieName))
                {
                    throw new ArgumentException("The cookie name cannot be null or contain white space only.");
                }

                if (context != null && context.Response != null)
                {
                    SetCookieValue(context.Response.Cookies, cookieName, cookieValue, expiry, isSecure);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }        

        private static string GetCookieValue(HttpCookieCollection cookieCollection, string cookieName)
        {
            if (cookieCollection != null)
            {
                HttpCookie cookie = cookieCollection[cookieName];
                if (cookie != null)
                {
                    return cookie.Value;
                }
            }
            return null;
        }

        private static bool IsSessionOnlyCookieEnabled()
        {
            bool hasSessionCookie = false;
            bool hasPersistentCookie = false;

            foreach (string key in HttpContext.Current.Request.Cookies.AllKeys)
            {
                hasSessionCookie ^= key.Equals(CartCookieConstants.MSAXSessionCookieCheck, StringComparison.Ordinal);
                hasPersistentCookie ^= key.Equals(CartCookieConstants.MSAXPersistentCookieCheck, StringComparison.Ordinal);

                if (hasSessionCookie && hasPersistentCookie)
                {
                    break;
                }
            }
            return hasSessionCookie && !hasPersistentCookie;
        }

        private static void SetCookieValue(HttpCookieCollection cookieCollection, string cookieName, string cookieValue, DateTime expiry, bool isSecure)
        {
            if (cookieCollection != null)
            {
                HttpCookie cookie = new HttpCookie(cookieName)
                {
                    Value = cookieValue,
                    Secure = isSecure,
                    HttpOnly = true,
                };

                // Set date only if persistence is allowed.
                if (!IsSessionOnlyCookieEnabled() && !isSecure)
                {
                    cookie.Expires = expiry;
                }

                // Set will ensure no duplicate keys are persisted.
                cookieCollection.Set(cookie);
            }
        }
    }
}
