﻿using Afhs.Data.CustomClasses;
using Afhs.Data.CustomClasses.Search;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Afhs.Infrastructure.Factories.Search;
using Glass.Mapper.Sc;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Links;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Helpers
{
    public static class SwatchGroupHelper
    {
        #region Colors

        /// <summary>
        /// Retrieves the available colors for the current product
        /// </summary>
        /// <param name="currentProduct">The product to search his available colors</param>
        /// <param name="orderByDefault">If true, will retrieve the color of the current product first.</param>
        /// <returns></returns>
        public static List<ColorSwatchGroupItem> GetAvailableColors(CustomProduct currentProduct, bool orderByDefault)
        {
            try
            {
                var colorSwatchGroup = new List<ColorSwatchGroupItem>();

                if (String.IsNullOrWhiteSpace(currentProduct.SwatchGroupId))
                {
                    return colorSwatchGroup;
                }

                var ScContext = new SitecoreContext();

                
                List<CustomProduct> products = new List<CustomProduct>();
                Dictionary<string, List<string>> filters = new Dictionary<string, List<string>>();
                List<string> facets = new List<string>();
                List<string> toSearch = new List<string>();

                toSearch.Add(currentProduct.SwatchGroupId);
                var swatchGroupId = currentProduct.SwatchGroupId;
                filters.Add("MA.SwatchGroupId", toSearch);

                using (var searchProductManager = new ProductSearchManager())
                {
                    var searchResult = searchProductManager.GetAll("*", 0, 0, "", filters, facets);

                    if (searchResult.TotalSearchResults != 0)
                    {
                        var colorSwatchProducts = new List<CustomProduct>();
                        products = searchResult.Hits.Select(x => x.Document.GetItem().GlassCast<CustomProduct>()).ToList();
                        products = products.Where(x => !string.IsNullOrEmpty(x.ColorSwatch)).ToList();

                        foreach (string color in products.Where(x => !string.IsNullOrEmpty(x.Color)).Select(y => y.Color).Distinct())
                            colorSwatchGroup.Add(GetBestCaseForColor(products, currentProduct, ScContext, color));
                    }

                    if (orderByDefault)
                        colorSwatchGroup = colorSwatchGroup.OrderByDescending(x => x.Color.ToLower() == currentProduct.Color.ToLower()).ToList();

                    return colorSwatchGroup;
                }

            }
            catch(Exception ex)
            {
                var errorMessage = new StringBuilder();
                errorMessage.Append("Error getting item from Sitecore.");
                errorMessage.AppendLine();
                errorMessage.Append("Message: ");
                errorMessage.Append(ex.Message);
                errorMessage.AppendLine();
                errorMessage.Append("StackTrace: ");
                errorMessage.Append(ex.StackTrace);
                Log.Error(errorMessage.ToString(), typeof(SwatchGroupHelper));
                throw ex;
            }
        }

        /// <summary>
        /// Gets from the products, the color by comparing the size and display name of the current product for the specified color
        /// </summary>
        /// <param name="products">The list of products with same swatch group id</param>
        /// <param name="currentProduct">The product that is being rendered</param>
        /// <param name="ScContext">The sitecore context</param>
        /// <param name="color">The target color to find</param>
        /// <returns></returns>
        private static ColorSwatchGroupItem GetBestCaseForColor(List<CustomProduct> products, CustomProduct currentProduct, SitecoreContext ScContext, string color)
        {
            CustomProduct bestCaseProduct = null;
            CustomProduct defaultProduct = products.FirstOrDefault(x => x.IsDefaultProduct);
            ProductSwatchValues bestCaseValues = new ProductSwatchValues();
            bestCaseValues.ColorDescription = color;

            if (defaultProduct != null && !string.IsNullOrEmpty(defaultProduct.Size))
            {
                if (!string.IsNullOrEmpty(defaultProduct.Size1))
                    bestCaseValues.Size1 = currentProduct.Size1;
                if (!string.IsNullOrEmpty(defaultProduct.Size2))
                    bestCaseValues.Size2 = currentProduct.Size2;
                if (!string.IsNullOrEmpty(defaultProduct.Size3))
                    bestCaseValues.Size3 = currentProduct.Size3;
                if (!string.IsNullOrEmpty(defaultProduct.Size4))
                    bestCaseValues.Size4 = currentProduct.Size4;
                if (!string.IsNullOrEmpty(defaultProduct.Size5))
                    bestCaseValues.Size5 = currentProduct.Size5;
            }
            else
                bestCaseValues.AllSizes = currentProduct.Size;

            bestCaseValues.Option = currentProduct.Option;
            bestCaseValues.ProductDisplayName = currentProduct.DisplayName;
            List<int> ranks = products.Select(x => RankBestCase(x, bestCaseValues, 9, 5, 2, 1)).ToList();

            bestCaseProduct = products.OrderByDescending(x => RankBestCase(x, bestCaseValues, 9, 5, 2, 1)).FirstOrDefault();

            if (bestCaseProduct == null || string.IsNullOrEmpty(bestCaseProduct.ExternalID))
                bestCaseProduct = products.FirstOrDefault(x => x.Color.Equals(color));

            return CreateColorSwatchGroupItem(bestCaseProduct, ScContext);
        }

        public static ColorSwatchGroupItem CreateColorSwatchGroupItem(CustomProduct product, SitecoreContext context)
        {
            var swatchImageData = ImageHelper.GetColorSwatchImageData(product.ColorSwatch, product.Color);

            var colorSwatchGroupItem = new ColorSwatchGroupItem();
            colorSwatchGroupItem.SwatchProductUrl = LinkManager.GetItemUrl(product.item);
            colorSwatchGroupItem.Color = product.Color;

            if (!String.IsNullOrEmpty(swatchImageData.ImageID))
                colorSwatchGroupItem.ImageSource = swatchImageData.GetURL(Data.Enums.ImagePresetKeys.swatch_image);
            else
                colorSwatchGroupItem.ImageSource = ImageHelper.SwatchImageNotFoundURL ?? String.Empty;

            colorSwatchGroupItem.Guid = product.Id.ToString();

            return colorSwatchGroupItem;
        }

        #endregion

        #region Sizes

        /// <summary>
        /// Retrieves the available sizes for the current product
        /// </summary>
        /// <param name="currentProduct">The product to search his available sizes</param>
        /// <param name="orderByDefault">If true, will retrieve the size of the current product first.</param>
        /// <returns></returns>
        public static List<SizeItem> GetAvailableSizes(CustomProduct currentProduct, bool orderByDefault)
        {
            var sizeSwatches = new List<SizeItem>();

            if (String.IsNullOrWhiteSpace(currentProduct.SwatchGroupId))
            {
                return sizeSwatches;
            }

            var ScContext = new SitecoreContext();

            ProductSearchManager searchProductManager = new ProductSearchManager();
            List<CustomProduct> products = new List<CustomProduct>();
            Dictionary<string, List<string>> filters = new Dictionary<string, List<string>>();
            List<string> facets = new List<string>();
            List<string> toSearch = new List<string>();

            toSearch.Add(currentProduct.SwatchGroupId);
            filters.Add("MA.SwatchGroupId", toSearch);

            var searchResult = searchProductManager.GetAll("*", 0, 0, "", filters, facets);

            if (searchResult.TotalSearchResults != 0)
            {
                var sizeSwatchProducts = new List<CustomProduct>();
                products = searchResult.Hits.Select(x => x.Document.GetItem().GlassCast<CustomProduct>()).ToList();
                SizeType sizeType;
                if (products.Exists(x => x.IsDefaultProduct))
                    sizeType = SwatchGroupHelper.GetSizeType(products.FirstOrDefault(x => x.IsDefaultProduct));
                else
                    sizeType = SizeType.noSizeDefined;

                foreach (string size in products.Where(x => !string.IsNullOrEmpty(x.Size)).Select(y => GetSize(y, sizeType)).Distinct())
                    sizeSwatches.Add(GetBestCaseForSize(products, currentProduct, ScContext, sizeType, size));
            }

            if (orderByDefault)
                sizeSwatches = sizeSwatches.OrderByDescending(x => x.Size.ToLower() == currentProduct.Size.ToLower()).ToList();

            return sizeSwatches;
        }

        private static SizeItem GetBestCaseForSize(List<CustomProduct> products, CustomProduct currentProduct, SitecoreContext ScContext, SizeType sizeType, string size)
        {
            CustomProduct bestCaseProduct = null;
            ProductSwatchValues bestCaseValues = new ProductSwatchValues();
            bestCaseValues.ColorDescription = currentProduct.Color;

            if (sizeType != SizeType.noSizeDefined)
            {
                if (sizeType == SizeType.size)
                    bestCaseValues.Size1 = size;
                if (sizeType == SizeType.size2)
                    bestCaseValues.Size2 = size;
                if (sizeType == SizeType.size3)
                    bestCaseValues.Size3 = size;
                if (sizeType == SizeType.size4)
                    bestCaseValues.Size4 = size;
                if (sizeType == SizeType.size5)
                    bestCaseValues.Size5 = size;
            }
            else
                bestCaseValues.AllSizes = size;

            bestCaseValues.Option = currentProduct.Option;
            bestCaseValues.ProductDisplayName = currentProduct.DisplayName;
            List<int> ranks = products.Select(x => RankBestCase(x, bestCaseValues, 5, 2, 9, 1)).ToList();

            bestCaseProduct = products.OrderByDescending(x => RankBestCase(x, bestCaseValues, 5, 2, 9, 1)).FirstOrDefault();

            if (bestCaseProduct == null || string.IsNullOrEmpty(bestCaseProduct.ExternalID))
                bestCaseProduct = products.FirstOrDefault(x => x.Color.Equals(size));

            return CreateSizeSeriesItem(bestCaseProduct, ScContext);
        }

        public static SizeItem CreateSizeSeriesItem(CustomProduct product, SitecoreContext context)
        {
            var sizeSerieItem = new SizeItem();

            sizeSerieItem.ProductUrl = LinkManager.GetItemUrl(product.item);
            sizeSerieItem.Size = product.Size;
            sizeSerieItem.ProductDisplayName = product.item.DisplayName;
            sizeSerieItem.ProductExternalId = product.ExternalID;
            sizeSerieItem.SwatchGroupId = product.SwatchGroupId;
            sizeSerieItem.Guid = product.Id.ToString();

            return sizeSerieItem;
        }

        public static SizeType GetSizeType(CustomProduct product)        
        {
            if (!string.IsNullOrEmpty(product.Size1))
                return SizeType.size;
            else if (!string.IsNullOrEmpty(product.Size2))
                return SizeType.size2;
            else if (!string.IsNullOrEmpty(product.Size3))
                return SizeType.size3;
            else if (!string.IsNullOrEmpty(product.Size4))
                return SizeType.size4;
            else if (!string.IsNullOrEmpty(product.Size5))
                return SizeType.size5;
            else
                return SizeType.noSizeDefined;
        }

        public static SizeType GetLuceneSizeType(string luceneFieldName)
        {
            if (string.IsNullOrEmpty(luceneFieldName))
                return SizeType.noSizeDefined;
            else if (luceneFieldName.ToLower().Equals("ma.size"))
                return SizeType.size;
            else if (luceneFieldName.ToLower().Equals("ma.size2"))
                return SizeType.size2;
            else if (luceneFieldName.ToLower().Equals("ma.size3"))
                return SizeType.size3;
            else if (luceneFieldName.ToLower().Equals("ma.size4"))
                return SizeType.size4;
            else if (luceneFieldName.ToLower().Equals("ma.size5"))
                return SizeType.size5;
            else
                return SizeType.noSizeDefined;
        }

        public static string GetLuceneSizeType(SizeType sizeType)
        {
            if (sizeType == SizeType.size)
                return "ma.size";
            else if (sizeType == SizeType.size2)
                return "ma.size2";
            else if (sizeType == SizeType.size3)
                return "ma.size3";
            else if (sizeType == SizeType.size4)
                return "ma.size4";
            else if (sizeType == SizeType.size5)
                return "ma.size5";
            else
                return string.Empty;
        }

        public static SizeType GetSizeType(ProductThumbnail product)
        {
            if (!string.IsNullOrEmpty(product.Size))
                return SizeType.size;
            else if (!string.IsNullOrEmpty(product.Size2))
                return SizeType.size2;
            else if (!string.IsNullOrEmpty(product.Size3))
                return SizeType.size3;
            else if (!string.IsNullOrEmpty(product.Size4))
                return SizeType.size4;
            else if (!string.IsNullOrEmpty(product.Size5))
                return SizeType.size5;
            else
                return SizeType.noSizeDefined;
        }

        public static SizeType GetSimilarProductsSizeType(List<ProductThumbnail> products)
        {
            SizeType type = SizeType.noSizeDefined;
            if (products.Exists(x => x.IsDefaultProduct))
                type = GetSizeType(products.FirstOrDefault(x => x.IsDefaultProduct));
            return type;
        }

        public static string GetSize(CustomProduct product, SizeType type)
        {
            switch (type)
            {
                case SizeType.size:
                    return product[ConfigurationManager.AppSettings["ProductSize1"]];
                case SizeType.size2:
                    return product[ConfigurationManager.AppSettings["ProductSize2"]];
                case SizeType.size3:
                    return product[ConfigurationManager.AppSettings["ProductSize3"]];
                case SizeType.size4:
                    return product[ConfigurationManager.AppSettings["ProductSize4"]];
                case SizeType.size5:
                    return product[ConfigurationManager.AppSettings["ProductSize5"]];
                default:
                    return product[ConfigurationManager.AppSettings["ProductSizeAttributes"]];
            }
        }

        public static string GetSize(ProductThumbnail product, SizeType type)
        {
            switch (type)
            {
                case SizeType.size:
                    return product.Size;
                case SizeType.size2:
                    return product.Size2;
                case SizeType.size3:
                    return product.Size3;
                case SizeType.size4:
                    return product.Size4;
                case SizeType.size5:
                    return product.Size5;
                default:
                    return string.Empty;
            }
        }

        public static CustomProduct SetSize(CustomProduct product, string newSize, SizeType type)
        {
            switch (type)
            {
                case SizeType.size:
                    product[ConfigurationManager.AppSettings["ProductSize1"]] = newSize;
                    break;
                case SizeType.size2:
                    product[ConfigurationManager.AppSettings["ProductSize2"]] = newSize;
                    break;
                case SizeType.size3:
                    product[ConfigurationManager.AppSettings["ProductSize3"]] = newSize;
                    break;
                case SizeType.size4:
                    product[ConfigurationManager.AppSettings["ProductSize4"]] = newSize;
                    break;
                case SizeType.size5:
                    product[ConfigurationManager.AppSettings["ProductSize5"]] = newSize;
                    break;
                default:
                    product[ConfigurationManager.AppSettings["ProductSizeAttributes"]] = newSize;
                    break;
            }
            return product;
        }

        #endregion

        #region Options

        /// <summary>
        /// Retrieves the available options for the current product
        /// </summary>
        /// <param name="currentProduct">The product to search his available options</param>
        /// <param name="orderByDefault">If true, will retrieve the option of the current product first.</param>
        /// <returns></returns>
        public static List<OptionItem> GetAvailableOptions(CustomProduct currentProduct, bool orderByDefault)
        {
            var options = new List<OptionItem>();

            if (String.IsNullOrWhiteSpace(currentProduct.SwatchGroupId))
            {
                return options;
            }

            var ScContext = new SitecoreContext();

            ProductSearchManager searchProductManager = new ProductSearchManager();
            List<CustomProduct> products = new List<CustomProduct>();
            Dictionary<string, List<string>> filters = new Dictionary<string, List<string>>();
            List<string> facets = new List<string>();
            List<string> toSearch = new List<string>();

            toSearch.Add(currentProduct.SwatchGroupId);
            filters.Add("MA.SwatchGroupId", toSearch);

            var searchResult = searchProductManager.GetAll("*", 0, 0, "", filters, facets);

            if (searchResult.TotalSearchResults != 0)
            {
                var optionProducts = new List<CustomProduct>();
                products = searchResult.Hits.Select(x => x.Document.GetItem().GlassCast<CustomProduct>()).ToList();

                foreach (string option in products.Where(x => !string.IsNullOrEmpty(x.Option)).Select(y => y.Option).Distinct())
                    options.Add(GetBestCaseForOption(products, currentProduct, ScContext, option));
            }

            if (orderByDefault)
                options = options.OrderByDescending(x => x.Option.ToLower() == currentProduct.Option.ToLower()).ToList();

            return options;
        }

        private static OptionItem GetBestCaseForOption(List<CustomProduct> products, CustomProduct currentProduct, SitecoreContext ScContext, string option)
        {
            CustomProduct defaultProduct = products.FirstOrDefault(x => x.IsDefaultProduct);
            CustomProduct bestCaseProduct = null;
            ProductSwatchValues bestCaseValues = new ProductSwatchValues();
            bestCaseValues.ColorDescription = currentProduct.Color;

            if (defaultProduct != null && !string.IsNullOrEmpty(defaultProduct.Size))
            {
                if (!string.IsNullOrEmpty(defaultProduct.Size1))
                    bestCaseValues.Size1 = currentProduct.Size1;
                if (!string.IsNullOrEmpty(defaultProduct.Size2))
                    bestCaseValues.Size2 = currentProduct.Size2;
                if (!string.IsNullOrEmpty(defaultProduct.Size3))
                    bestCaseValues.Size3 = currentProduct.Size3;
                if (!string.IsNullOrEmpty(defaultProduct.Size4))
                    bestCaseValues.Size4 = currentProduct.Size4;
                if (!string.IsNullOrEmpty(defaultProduct.Size5))
                    bestCaseValues.Size5 = currentProduct.Size5;
            }
            else
                bestCaseValues.AllSizes = currentProduct.Size;

            bestCaseValues.Option = option;
            bestCaseValues.ProductDisplayName = currentProduct.DisplayName;
            List<int> ranks = products.Select(x => RankBestCase(x, bestCaseValues, 5, 9, 2, 1)).ToList();

            bestCaseProduct = products.OrderByDescending(x => RankBestCase(x, bestCaseValues, 5, 9, 2, 1)).FirstOrDefault();

            if (bestCaseProduct == null || string.IsNullOrEmpty(bestCaseProduct.ExternalID))
                bestCaseProduct = products.FirstOrDefault(x => x.Color.Equals(option));

            return CreateOptionSwatchItem(bestCaseProduct, ScContext);
        }

        public static OptionItem CreateOptionSwatchItem(CustomProduct product, SitecoreContext context)
        {
            var optionSwatchItem = new OptionItem();

            optionSwatchItem.ProductUrl = LinkManager.GetItemUrl(product.item);
            optionSwatchItem.Option = product.Option;
            optionSwatchItem.ProductDisplayName = product.item.DisplayName;
            optionSwatchItem.ProductExternalId = product.ExternalID;
            optionSwatchItem.SwatchGroupID = product.SwatchGroupId;
            optionSwatchItem.Guid = product.Id.ToString();

            return optionSwatchItem;
        }

        #endregion

        public static int RankBestCase(CustomProduct product, ProductSwatchValues searchingValues, int colorScore, int optionScore, int sizeScore, int nameScore)
        {
            int score = 0;
            int sizeRank = 0;
            score += product.Color == searchingValues.ColorDescription ? colorScore : 0;
            score += product.Option == searchingValues.Option ? optionScore : 0;
            sizeRank += !string.IsNullOrEmpty(searchingValues.Size1) && product.Size1 == searchingValues.Size1 ? sizeScore : 0;
            sizeRank += !string.IsNullOrEmpty(searchingValues.Size2) && product.Size2 == searchingValues.Size2 ? sizeScore : 0;
            sizeRank += !string.IsNullOrEmpty(searchingValues.Size3) && product.Size3 == searchingValues.Size3 ? sizeScore : 0;
            sizeRank += !string.IsNullOrEmpty(searchingValues.Size4) && product.Size4 == searchingValues.Size4 ? sizeScore : 0;
            sizeRank += !string.IsNullOrEmpty(searchingValues.Size5) && product.Size5 == searchingValues.Size5 ? sizeScore : 0;
            if (sizeRank == 0)
                sizeRank += !string.IsNullOrEmpty(searchingValues.AllSizes) && product.Size == searchingValues.AllSizes ? sizeScore : 0;
            sizeRank = sizeRank > sizeScore ? sizeScore : sizeRank;
            score += sizeRank;
            score += product.DisplayName == searchingValues.ProductDisplayName ? nameScore : 0;
            return score;
        }

        public static List<CustomProduct> GetCustomProductsBySwatchGroupID(string idToSearch)
        {
            ProductSearchManager searchProductManager = new ProductSearchManager();
            List<CustomProduct> products = new List<CustomProduct>();
            Dictionary<string, List<string>> filters = new Dictionary<string, List<string>>();
            List<string> toSearch = new List<string>();
            toSearch.Add(idToSearch);
            List<string> facets = new List<string>();
            filters.Add("MA.SwatchGroupId", toSearch);
            var searchResult = searchProductManager.GetAll("*", 0, 0, "", filters, facets);
            if (searchResult.TotalSearchResults != 0)
            {
                foreach (ProductSearchResultItem result in searchResult.Hits.Select(x => x.Document))
                {
                    CustomProduct product = result.GetItem().GlassCast<CustomProduct>();
                    if (!products.Exists(x => x.ExternalID == product.ExternalID))
                        products.Add(result.GetItem().GlassCast<CustomProduct>());
                }
            }

            return products;
        }

        public static List<ProductThumbnail> GetProductThumbnailsBySwatchGroupID(string idToSearch)
        {
            ProductSearchManager searchProductManager = new ProductSearchManager();
            List<ProductThumbnail> products = new List<ProductThumbnail>();
            Dictionary<string, List<string>> filters = new Dictionary<string, List<string>>();
            List<string> toSearch = new List<string>();
            toSearch.Add(idToSearch);
            List<string> facets = new List<string>();
            filters.Add("MA.SwatchGroupId", toSearch);
            var searchResult = searchProductManager.GetAll("*", 0, 0, "", filters, facets);
            if (searchResult.TotalSearchResults != 0)
            {
                foreach (ProductSearchResultItem result in searchResult.Hits.Select(x => x.Document))
                {
                    CustomProduct product = result.GetItem().GlassCast<CustomProduct>();
                    if (!products.Exists(x => x.ExternalId == product.ExternalID))
                        products.Add(ProductThumbnailFactory.Create(result));
                }
            }

            return products;
        }

        public static bool HasProductsVariance(List<ProductThumbnail> rawResults, string swatchId)
        {
            int colors = 0;
            bool hasMoreOptions = false;
            if (!string.IsNullOrEmpty(swatchId))
            {
                List<ProductThumbnail> productsGroup = rawResults.Where(x => !string.IsNullOrEmpty(x.SwatchGroupId) && x.SwatchGroupId.ToLower() == swatchId.ToLower()).ToList();
                SizeType sizeType = SizeType.noSizeDefined;
                if (productsGroup.Exists(x => x.IsDefaultProduct))
                    sizeType = SwatchGroupHelper.GetSizeType(productsGroup.FirstOrDefault(x => x.IsDefaultProduct));


                List<string> values = new List<string>();
                values.AddRange(productsGroup.Where(x => !string.IsNullOrEmpty(x.ColorDescription)).Select(x => x.ColorDescription).Distinct());
                values.Remove(null); values.Remove("");
                colors = values.Count;

                hasMoreOptions = ShouldProductShownMoreOptions(productsGroup, swatchId);
            }

            return (colors > 1 || hasMoreOptions);
        }

        public static bool ShouldProductShownMoreOptions(List<ProductThumbnail> rawResults, string swatchId)
        {
            int sizes = 0, options = 0;
            if (!string.IsNullOrEmpty(swatchId))
            {
                List<ProductThumbnail> productsGroup = rawResults.Where(x => !string.IsNullOrEmpty(x.SwatchGroupId) && x.SwatchGroupId.ToLower() == swatchId.ToLower()).ToList();
                SizeType sizeType = SizeType.noSizeDefined;
                if (productsGroup.Exists(x => x.IsDefaultProduct))
                    sizeType = SwatchGroupHelper.GetSizeType(productsGroup.FirstOrDefault(x => x.IsDefaultProduct));

                List<string> values = new List<string>();
                values.AddRange(productsGroup.Where(x => !string.IsNullOrEmpty(x.EcommAlsoAvailable)).Select(x => x.EcommAlsoAvailable).Distinct());
                values.Remove(null); values.Remove("");
                options = values.Count;

                values.Clear();
                values.AddRange(productsGroup.Where(x => !string.IsNullOrEmpty(SwatchGroupHelper.GetSize(x, sizeType))).Select(x => SwatchGroupHelper.GetSize(x, sizeType)).Distinct());
                values = values.Distinct().ToList();
                values.Remove(null); values.Remove("");
                sizes = values.Count;
            }

            return (options > 1 || sizes > 1);
        }
    }
}
