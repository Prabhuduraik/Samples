﻿using Afhs.Data.CustomClasses;
using Afhs.Infrastructure.Cache;
using Glass.Mapper.Sc;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace Afhs.Infrastructure.Helpers
{
    public class Scene7ImageSetParser
    {
        public static Scene7ImageSet GetImageSetForAsset(string assetName)
        {
            string serverName = ConfigurationManager.AppSettings["Scene7ServerName"].ToString();
            assetName = assetName.Trim();
            try
            {
                Scene7ImageSet imageSet = new Scene7ImageSet();
                imageSet = GlobalCachingProvider<Scene7ImageSet>.Instance.GetItem(assetName, false) as Scene7ImageSet;
     
                if (imageSet == null)
                {
                    /* //s7d3.scene7.com/is/image/AshleyFurniture/?imageset=3180135-IS&req=set,json,utf-8 */

                    StringBuilder sbUrl = new StringBuilder();
                    sbUrl.Append(serverName);
                    sbUrl.Append("AshleyFurniture/?imageset=");
                    sbUrl.Append(assetName);
                    sbUrl.Append("&req=set,json,utf-8");
                    Scene7RawImageSet rawImageSet = GetRawImageSet(sbUrl.ToString());
                    imageSet = new Scene7ImageSet(serverName, rawImageSet);
                    GlobalCachingProvider<Scene7ImageSet>.Instance.AddItem(assetName, imageSet);
                }

                return imageSet;
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Failed to retrieve an image set for asset {0}.", assetName), ex);
            }
        }

        public static Scene7Image GetPrimaryImage(Scene7ImageSet parentSet, string name)
        {
            return parentSet.Images.FirstOrDefault(x => x.Name == name.Trim());
        }

        private static Scene7RawImageSet GetRawImageSet(string urlString)
        {
            try
            {
                Scene7RawImageSet rawImageSet = null;
                string jsonString = RequestJsonStringResponse(urlString);
                if (jsonString.ToUpper().Contains("XML"))
                    jsonString = RequestJsonStringResponse(urlString + "&cache=update");
                Scene7RawImageSetWrapper rawImageSetWrapper = new Scene7RawImageSetWrapper();
                if (!jsonString.ToUpper().Contains("XML"))
                {
                    rawImageSetWrapper = JsonConvert.DeserializeObject<Scene7RawImageSetWrapper>(jsonString);
                }

                if (rawImageSetWrapper != null && rawImageSetWrapper.set != null)
                {
                    rawImageSet = rawImageSetWrapper.set;
                }

                return rawImageSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string RequestJsonStringResponse(string urlString)
        {
            try
            {
                string returnString = string.Empty;
                string responseString = string.Empty;

                WebRequest request = WebRequest.Create(urlString);
                using (HttpWebResponse twitpicResponse = (HttpWebResponse)request.GetResponse())
                {
                    using (var reader = new StreamReader(twitpicResponse.GetResponseStream()))
                    {
                        responseString = reader.ReadToEnd();
                    }
                }
                string pattern = @"s7jsonResponse\((.*),\""\""\);";

                Match m = Regex.Match(responseString, pattern);
                if (m != null && m.Groups.Count > 1)
                {
                    returnString = m.Groups[1].Value;
                }
                else
                {
                    returnString = responseString;
                }

                return returnString.Replace("$", "");
            }
            catch (Exception ex)
            {
                throw new Exception("Scene7ImageSetParser failed to retrieve a valid response from Scene7", ex);
            }

        }
        
        internal class Scene7RawImageSetWrapper
        {
            public Scene7RawImageSet set { get; set; }
        }

        internal class Scene7RawImageSet
        {
        [JsonConverter(typeof(ObjectToArrayConverter<Scene7RawImageMetadata>))]
            public Scene7RawImageMetadata[] item { get; set; }
            public string n { get; set; }
            public decimal pv { get; set; }
            public string type { get; set; }
        }

        internal class Scene7RawImageMetadata
        {
            public int dx { get; set; }
            public int dy { get; set; }
            public Scene7RawImage i { get; set; }
            public Scene7RawData userdata { get; set; }
            public Scene7Map map { get; set; }

        }

        internal class Scene7Map 
        {
            public Scene7Area area { get; set; }
        }
        internal class Scene7Area
        {
            public string rollover_key { get; set; }
        }

        internal class Scene7RawImage
        {
            public string n { get; set; }
        }

        internal class Scene7RawData
        {
            public string t { get; set; }
        }

        public class ObjectToArrayConverter<T> : CustomCreationConverter<T[]>
        {
            public override T[] Create(Type objectType)
            {
                return new T[0];
            }

            public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
            {
                if (reader.TokenType == JsonToken.StartArray)
                {
                    return serializer.Deserialize(reader, objectType);
                }
                else
                {
                    return new T[] { serializer.Deserialize<T>(reader) };
                }
            }
        }
    
    }

    public class Scene7ImageSet
    {
        public string Scene7Server { get; set; }
        public string Name { get; set; }
        public List<Scene7Image> Images { get; set; }

        public Scene7ImageSet()
        {
            this.Scene7Server = string.Empty;
            this.Images = new List<Scene7Image>();
        }

        internal Scene7ImageSet(string serverUrl, Scene7ImageSetParser.Scene7RawImageSet rawS7Set)
        {
            this.Scene7Server = serverUrl;
            if (rawS7Set != null)
            {
                this.Name = rawS7Set.n;
                this.Images = rawS7Set.item.AsQueryable().Select(i => new Scene7Image(this, i.i.n, i.dx, i.dy, i.userdata != null ? i.userdata.t : "", i.map != null ? i.map.area.rollover_key : "")).ToList();
            }
            else
            {
                this.Images = new List<Scene7Image>();
            }
        }
    }

    public class Scene7Image
    {
        public string Name { get; set; }
        public Scene7ImageSet ParentSet { get; set; }
        public System.Drawing.Size Size { get; set; }
        public string Description { get; set; }
        public string YoutubeId { get; set; }

        public Scene7Image(Scene7ImageSet parentSet, string name, int width, int height)
            : this(parentSet, name, width, height, null, null)
        {

        }

        public Scene7Image(Scene7ImageSet parentSet, string name, int width, int height, string description, string youtubeId)
        {
            this.ParentSet = parentSet;
            this.Name = name;
            this.Size = new System.Drawing.Size(width, height);
            this.Description = description;
            this.YoutubeId = youtubeId;
        }
    }
}