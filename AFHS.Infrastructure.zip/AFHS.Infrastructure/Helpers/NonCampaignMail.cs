﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.Modules.EmailCampaign;
using Sitecore.Modules.EmailCampaign.Messages;
using Sitecore.Data.Items;
using Sitecore.Modules.EmailCampaign.Core;
using SCModules=Sitecore.Modules;

namespace Afhs.Infrastructure.Helpers
{

    public class NonCampaignMail : WebPageMail, INonCampaignEmail
    {
        public NonCampaignMail(Item item)
            : base(item)
        {
        }

        public new static NonCampaignMail Create(string name, Item destination)
        {
            return FromItem(MessageItem.Create(name, destination, "{7B8A5AE9-149E-48B9-B597-E1A2A8D2CCCC}"));
        }

        public new static NonCampaignMail FromItem(Item item)
        {
            if (IsCorrectMessageItem(item))
            {
                return new NonCampaignMail(item);
            }
            return null;
        }

        public new static bool IsCorrectMessageItem(Item item)
        {
            return ItemUtilExt.IsTemplateDescendant(item, "{7B8A5AE9-149E-48B9-B597-E1A2A8D2CCCC}");
        }

        public bool SendAsCampaign { get; set; }

        public void Send(bool asCampaign)
        {
            Contact contact = Factory.GetContactFromName("user.Name");
            if ((contact != null) && !string.IsNullOrEmpty(contact.Profile.Email))
            {
                this.SendAsCampaign = asCampaign;
                new SendingManager(this).SendNonCampaignMessage(contact);
            }
        }
    }
}