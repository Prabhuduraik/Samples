﻿using Afhs.Data.Models.sitecore.templates.User_Defined;
using Glass.Mapper.Sc.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Data.CustomClasses
{
    [SitecoreType(AutoMap = true)]
    public class ProductWithPrice
    {
        private CustomProduct product;
        public CustomProduct Product
        {
            get
            {
                if (product == null)
                {
                    product = new Glass.Mapper.Sc.SitecoreService("web").GetItem<CustomProduct>(Afhs.Infrastructure.Helpers.SearchManager.GetItemIdBy(ExternalId));
                }
                return product;
            }
            set
            {
                product = value;
            }
        }
        public decimal RegularPrice { get; set; }
        public decimal SalePrice { get; set; }
        public string ExternalId { get; set; }
        public decimal BestPrice { get; set; }
        public decimal LowestPrice
        {
            get
            {
                decimal price = 0;

                if (RegularPrice <= 0)
                {
                    price = RegularPrice;
                }
                else
                {
                    price = SalePrice < RegularPrice ? SalePrice : RegularPrice;
                }

                return decimal.Round(price, 2);
            }
        }
        public bool IsOnSale
        {
            get
            {
                return SalePrice > 0 && SalePrice < RegularPrice;
            }
        }

    }
}
