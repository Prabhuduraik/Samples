﻿using Lucene.Net.Analysis;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SC = Sitecore;

namespace Afhs.Infrastructure.Helpers
{
    public static class SearchManager
    {
        private const string PRODUCT_TEMPLATE_ID = "944D9A1D-C88E-484A-92DF-F674BA9B4611";

        /*private static IProviderSearchContext _context;*/
        private static IProviderSearchContext GetProductIndex
        {
            get
            {
                string index = String.Empty;
                if (SC.Context.PageMode.IsNormal)
                    index = "commerce_products_web_index"; //change to web
                else
                    index = "commerce_products_master_index";

                /*_context = _context ?? ContentSearchManager.GetIndex(index).CreateSearchContext();
                return _context;*/

                return ContentSearchManager.GetIndex(index).CreateSearchContext();
            }
        }

        public static string GetProductsIndex()
        {
            if (SC.Context.Database == null || SC.Context.Database.Name.ToLower() == "core" || SC.Context.PageMode.IsNormal)
                return "commerce_products_web_index"; //change to web
            else
                return "commerce_products_master_index";
        }
        public static List<ProductSearchResultItem> SearchProducts(string term)
        {
            return GetProductIndex.GetQueryable<ProductSearchResultItem>()
                 .Where(x => x.TemplateId == ID.Parse(PRODUCT_TEMPLATE_ID)
                 && x.Content.Contains(term)).ToList();
        }
        public static IQueryable<ProductSearchResultItem> GetProducts()
        {
            return GetProductIndex.GetQueryable<ProductSearchResultItem>()
                 .Where(x => x.TemplateId == ID.Parse(PRODUCT_TEMPLATE_ID));
        }
        public static List<string> GetSearchPageFacets(List<ProductSearchResultItem> products)
        {
            List<string> facets = new List<string>();
            foreach (var a in products)
            {
                if (a.Classes == null) continue;
                foreach (var fc in a.Classes)
                {
                    if(!facets.Contains(fc))                    
                    {
                        facets.Add(fc);
                    }
                }
            }

            facets.Remove("All"); facets.Sort();

            return facets;
        }
        public static List<FacetItem> GetClassFacets(List<ProductSearchResultItem> products)
        {
            List<FacetItem> facets = new List<FacetItem>();
            foreach (var a in products)
            {
                if (a.Facets == null) continue;
                foreach (var fc in a.Facets)
                {
                    if (string.IsNullOrEmpty(fc)) continue;
                    FacetItem fi = new FacetItem(fc);
                    if (!string.IsNullOrEmpty(fi.FacetName) && facets.Find(nf => nf.FacetName.Equals(fi.FacetName)) == null)
                    {
                        facets.Add(fi);
                    }
                }
            }

            foreach (FacetItem f in facets)
            {
                var d = new List<string>();

                foreach (var prod in products)
                {
                    if (prod.Attributes != null)
                    {
             
                        var s = prod.GetAttributesDictionary().Where(pa => pa.Key == f.TargetAttribute).FirstOrDefault();
                        if (!string.IsNullOrEmpty(s.Value) && d.Contains(s.Value)==false)
                        {
                            d.Add(s.Value);
                        }
                    }
                }
                d.Sort();
                f.Values.AddRange(d);

                }
            var lst = facets.Where(f => f.Values.Count == 0).ToList();
            
            foreach (var l in lst) { facets.Remove(l); }

            return facets;
        }

        public static string GetItemIdBy(string externalId)
        {
            var result = SearchManager.GetProducts().Where(i => i.ExternalID == externalId).FirstOrDefault();
            var guid = result == null ? String.Empty : result.ItemId.ToGuid().ToString();
            return guid;
        }

        public static ProductSearchResultItem GetProductByProductNumber(string productNumber)
        {
            return GetProductIndex.GetQueryable<ProductSearchResultItem>()
                 .FirstOrDefault(x => x.TemplateId == ID.Parse(PRODUCT_TEMPLATE_ID)
                 && x.ExternalID == productNumber);
        }

        public static List<string> GetPhrasesToSearch(string query)
        {
            Regex quotedWordsPattern = new Regex("\".+?\"");
            List<string> quotedWords = quotedWordsPattern.Matches(query).Cast<Match>().Select(match => match.Value).ToList();

            string singleWords = quotedWordsPattern.Replace(query, string.Empty);
            var phrases = singleWords.Split(' ').Where(x => !StopAnalyzer.ENGLISH_STOP_WORDS_SET.AsQueryable().ToList().Contains(x, StringComparer.CurrentCultureIgnoreCase)).ToList();
            // "*" is used for subcategories
            if (singleWords != "*")
                phrases = phrases.Where(x => x.Length >= 3).ToList();

            phrases.AddRange(quotedWords);
            return phrases;
        }
    }
    public class ProductSearchResultItem : SearchResultItem
    {
        [IndexField("_name")]
        public string Name { get; set; }
        [IndexField("price")]
        public double Price { get; set; }
        [IndexField("new")]
        public bool IsNew { get; set; }
        [IndexField("isonsale")]
        public bool OnSale { get; set; }
        [IndexField("isecommowned")]
        public bool IsECommOwned { get; set; }
        [IndexField("bestseller")]
        public bool BestSeller { get; set; }
        [IndexField("facets")]
        public string[] Facets { get; set; }
        [IndexField("productattributes")]
        public string[] Attributes { get; set; }
        [IndexField("_displayname")]
        public string DisplayName { get; set; }
        [IndexField("ProductDisplayNameForSorting")]
        public string DisplayNameForSorting { get; set; }
        [IndexField("productclasses")]
        public string[] Classes { get; set; }
        [IndexField("pa.styledescription")]
        public string StyleDescription { get; set; }
        [IndexField("pa.numberofdrawers")]
        public string NumberOfDrawers { get; set; }
        [IndexField("pa.pattern")]
        public string Pattern { get; set; }
        [IndexField("pa.features")]
        public string Features { get; set; }
        [IndexField("pa.shade")]
        public string[] Shade { get; set; }
        [IndexField("pa.seriesname")]
        public string SeriesName { get; set; }
        [IndexField("pa.seriesnumber")]
        public string SeriesNumber { get; set; }
        [IndexField("pa.showroom")]
        public string Showroom { get; set; }
        [IndexField("pa.material")]
        public string[] Material { get; set; }
        [IndexField("ma.color2")]
        public string Color2 { get; set; }
        [IndexField("pa.manufacturingwarrantydays")]
        public string ManufacturingWarrantyDays { get; set; }
        [IndexField("pa.colordescription")]
        public string ColorDescription { get; set; }
        [IndexField("pa.itemcodedescription")]
        public string ItemCodeDescription { get; set; }
        [IndexField("pa.seriesfluff")]
        public string SeriesFluff { get; set; }
        [IndexField("pa.description")]
        public string Description { get; set; }
        [IndexField("pa.seriesfeatures")]
        public string SeriesFeatures { get; set; }
        [IndexField("ma.swatchgroupid")]
        public string SwatchGroupId { get; set; }
        [IndexField("ma.colorswatch")]
        public string ColorSwatch { get; set; }
        [IndexField("ma.rolloverimage")]
        public string RolloverImage { get; set; }
        [IndexField("externalid")]
        public string ExternalID { get; set; }
        [IndexField("imagesetid")]
        public string ImageSetID { get; set; }
        [IndexField("primaryimageid")]
        public string PrimaryImageID { get; set; }
        [IndexField("pa.displayrank")]
        public int DisplayRank { get; set; }
        [IndexField("pa.itemstatus")]
        public string ItemStatus { get; set; }
        [IndexField("pa.itemstatusactivationdate")]
        public DateTime ItemStatusActivationDate { get; set; } 
        public bool IsItemStatusNew { get; set; }
        public bool IsItemStatusCurrent { get; set; }
        public bool IsAvailableOnline { get; set; }
        [IndexField("pa.defaultproduct")]
        public string DefaultProduct { get; set; }
        public bool IsDefaultProduct { get; set; }
        [IndexField("synonyms")]
        public string Synonyms { get; set; }
        
        [IndexField("ma.size")]
        public string Size { get; set; }
        [IndexField("ma.size2")]
        public string Size2 { get; set; }
        [IndexField("ma.size3")]
        public string Size3 { get; set; }
        [IndexField("ma.size4")]
        public string Size4 { get; set; }
        [IndexField("ma.size5")]
        public string Size5 { get; set; }
        [IndexField("ma.ecommalsoavailable")]
        public string EcommAlsoAvailable { get; set; }
        
        public Dictionary<string, string> GetAttributesDictionary()
        {
            Dictionary<string, string> rv = new Dictionary<string, string>();
            if (this.Attributes == null) { return rv; }

            foreach (string s in this.Attributes)
            {
                string[] vals = s.Split(':');
                if (vals.Length == 2 && !string.IsNullOrEmpty(vals[1]))
                { rv.Add(vals[0], vals[1]); }
            }

            return rv;
        }

    }
    public class FacetItem
    {
        public FacetItem(string facet)
        {
            if (string.IsNullOrEmpty(facet)) return;

            if (facet.Contains(":"))
            {
                string[] s = facet.Split(':');
                if (s.Length == 2) { this.FacetName = s[0]; this.TargetAttribute = s[1]; }
            }
            else
            { this.FacetName = facet; }
        }

        public string FacetName { get; set; }
        public string TargetAttribute { get; set; }
        public List<string> Values = new List<string>();
    }
}
