﻿using Sitecore.Security.Accounts;
using Sitecore.Security.Authentication;
using Sitecore.Security.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Profile;
using System.Web.Security;

namespace Afhs.Infrastructure.Helpers
{
    public static class ValidationHelper
    {
        public static bool IsValidEmail(string email)
        {
            string pat = @"^(([^<>()[\]\\.,;:\s@\']+(\.[^<>()[\]\\.,;:\s@\']+)*)|(\'.+\'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$";
            Regex r = new Regex(pat, RegexOptions.IgnoreCase);

            return r.IsMatch(email);
        }

        public static bool IsValidMultipleEmails(string emails, char separator)
        {
            foreach (string email in emails.Split(separator))
            {
                string trimmedEmail = email.Trim();
                if (!IsValidEmail(trimmedEmail))
                    return false;
            }
            return true;
        }

        public static bool IsPasswordStrengthValid(string password)
        {
            if (String.IsNullOrEmpty(password))
            {
                return false;
            }
            var minAllowedLength = Membership.MinRequiredPasswordLength;
            var minSpecialCharacters = Membership.MinRequiredNonAlphanumericCharacters;

            if (password.Length < minAllowedLength)
            {
                return false;
            }

            if (minSpecialCharacters > 0)
            {
                Regex regex = new Regex("[^a-zA-Z0-9]");
                var specialCharactersInPassword = regex.Replace(password, "");

                if (specialCharactersInPassword.Length < minSpecialCharacters)
                {
                    return false;
                }
            }

            return true;
        }

        public static bool IsEmailBeingUsed(User currentUser, string newEmail)
        {
            var isUsed = false;

            if(currentUser.Profile.Email.ToLower() == newEmail.Trim().ToLower()){
                return false;
            }

            isUsed = Domain.GetDomain("extranet")
                .GetUsers()
                .Where(x => x.Profile.Email.ToLower() == newEmail.Trim().ToLower()
                && !string.IsNullOrEmpty(x.Profile.GetCustomProperty(Constants.AX_ACCOUNT_PROPERTY))).Count() > 0;

            return isUsed;
        }

        public static bool IsValidCustomerPassword(User currentUser, string password)
        {
            return AuthenticationManager.Login(currentUser.Profile.UserName, password);
        }
    }
}
