﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using Sitecore.ContentSearch.Linq.Utilities;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using Afhs.Data.CustomClasses;
using SC = Sitecore;
using Afhs.Infrastructure.Cache;
using AFM.Commerce.Services;
using System.Text.RegularExpressions;
using Lucene.Net.Analysis;
using Lucene.Net.Search;

namespace Afhs.Infrastructure.Helpers
{
    public class ProductSearchManager : IDisposable
    {       
        private const string PRODUCT_TEMPLATE_ID = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        private const string CLASSIFICATION_TEMPLATE_ID = "{DE2E1240-3B27-42AC-806F-6D1F16E6D656}";
    

        #region Index

        private IProviderSearchContext _context;
        private ISearchIndex _index;

        protected ISearchIndex Index
        {
            get
            {
                return _index ?? (_index = ContentSearchManager.GetIndex(SearchManager.GetProductsIndex()));
            }
        }
        protected IProviderSearchContext SearchContext
        {
            get
            {
                return this._context ?? (this._context = this.Index.CreateSearchContext());
            }
        }   
        
        #endregion

        #region SearchMethods


        public SearchResults<ProductSearchResultItem> GetAll(string query, int page, int count, string orderBy, Dictionary<string, List<string>> filters, List<string> facetList, List<string> classesList = null)
        {
            classesList = classesList ?? new List<string>();
            filters = filters ?? new Dictionary<string, List<string>>();
            facetList = facetList?? new List<string>();

            BooleanQuery.MaxClauseCount = 2048;//Increasing the result count to get more result counts
            
            var queryPredicate = PredicateBuilder.True<ProductSearchResultItem>();

            var phrases = SearchManager.GetPhrasesToSearch(query);

            foreach (var word in phrases)
            {
                var _word = word.ToLower();
                queryPredicate = queryPredicate.And(p => (p.Content.Contains(_word))
                                          || p.DisplayName.Contains(_word)
                                          || p.ItemCodeDescription.Contains(_word)
                                          || p.ColorDescription.Contains(_word)
                                          || p.Description.Contains(_word)
                                          || p.StyleDescription.Contains(_word)
                                          || p.Synonyms.Contains(_word)
                                    );  
            }
            queryPredicate = queryPredicate.And(p => p.ItemId != Constants.DELIVERY_CHARGE_ITEM);
            
            var filterPredicate = PredicateBuilder.True<ProductSearchResultItem>();
            foreach (var pair in filters)
            {
                var orPredicate = PredicateBuilder.True<ProductSearchResultItem>();
                foreach (var value in pair.Value)
                {
                    if (value != null)
                    {
                        var v = value.ToLower();
                        orPredicate = orPredicate.Or(p => (p[pair.Key].Contains("|") && p[pair.Key].Contains(v)) || (!p[pair.Key].Contains("|") && p[pair.Key].Equals(v)));
                    }
                }
                filterPredicate = filterPredicate.And(orPredicate);
            }

            var classesPredicate = PredicateBuilder.True<ProductSearchResultItem>();
            foreach (var classification in classesList)
            {
                classesPredicate = classesPredicate.Or(p => p.Classes.Contains(classification));
            }

            IQueryable<ProductSearchResultItem> searchItems = SearchContext.GetQueryable<ProductSearchResultItem>();

            if (phrases.Count > 0)
            {
                searchItems = searchItems.Where(x => x.TemplateId == ID.Parse(PRODUCT_TEMPLATE_ID))
                                            .Where(queryPredicate)
                                            .Where(filterPredicate)
                                            .Where(classesPredicate);         
            }
            else
            {
                List<SearchHit<ProductSearchResultItem>> temp = new List<SearchHit<ProductSearchResultItem>>();
                return new SearchResults<ProductSearchResultItem>(temp, 0);
            }

            foreach (var facet in facetList)
            {
                searchItems = searchItems.FacetOn(x=>x[facet]);
            }

            
            searchItems = OrderBy(searchItems, orderBy);

            if (count > 0 && orderBy != "default" && orderBy != "onsale")
                return searchItems.Page(page, count).GetResults();
            else
                return searchItems.GetResults();
                
            
        }

        public SearchResults<ProductSearchResultItem> GetByExternalIds(List<string> externalIds, List<string> facetList)
        {            
            IQueryable<ProductSearchResultItem> searchItems = SearchContext.GetQueryable<ProductSearchResultItem>();

            searchItems = searchItems.Where(x => externalIds.Contains(x.ExternalID));

            foreach (var facet in facetList)
            {
                searchItems = searchItems.FacetOn(x => x[facet]);
            }

            return searchItems.GetResults();
        }

        public SearchResults<SearchResultItem> GetDescendantsClassifications(ID id) 
        {
            
            IQueryable<SearchResultItem> searchItems = SearchContext.GetQueryable<SearchResultItem>();
            return searchItems.Where(x => x.TemplateId == ID.Parse(CLASSIFICATION_TEMPLATE_ID) && x.Paths.Contains(id)).GetResults();
        }

        public IEnumerable<ProductSearchResultItem> GetProductsBySwatchGroupId(string swatchGroupId)
        {
            var searchItems = SearchContext.GetQueryable<ProductSearchResultItem>().Filter(sgi => sgi.SwatchGroupId == swatchGroupId.ToLower());

            if (searchItems.Count() > 0)
            {
                return searchItems.GetResults().Hits.Where(r => !string.IsNullOrEmpty(r.Document.ColorSwatch)).Select(d => d.Document);
            }

            return new List<ProductSearchResultItem>();
        }

        private IQueryable<ProductSearchResultItem> OrderBy(IQueryable<ProductSearchResultItem> searchItems, string orderBy)
        {            
            switch (orderBy.ToLower())
            {
                case "lowtohigh":
                    searchItems = searchItems.OrderBy(x=>x.Price).ThenByDescending(x=>x.IsAvailableOnline);
                    break;
                case "hightolow":
                    searchItems = searchItems.OrderByDescending(x => x.Price);
                    break;
                case "az":
                    searchItems = searchItems.OrderBy(x => x.DisplayNameForSorting);
                    break;
                case "bestsellers":
                    searchItems = searchItems.OrderByDescending(x => x.BestSeller);
                    break;
                case "newest":
                    ///Order works different on Lucene Linq. Last ThenBy is the main sorting criteria.
                    searchItems = searchItems.OrderByDescending(x => x.ItemStatusActivationDate)
                                                .ThenByDescending(x => x.IsItemStatusCurrent)
                                                .ThenByDescending(x => x.IsNew);
                    break;
                case "onsale":
                    ///OnSale and DisplayRank sort is applied later as it is not possible with Lucene Linq beacuse of complexity.
                    searchItems = searchItems.OrderBy(x => x.DisplayNameForSorting)
                                                .ThenByDescending(x => x.Price);
                    break;
                case "default":
                    break;
                default:
                    break;
            }
            return searchItems;
        }
        

        #endregion

        public Dictionary<string, string> GetFormattedPriceRanges(ExtendedPriceFacet priceFacet)
        {
            Dictionary<string, string> ranges = new Dictionary<string, string>();
            ranges.Add("0", "In-Store Only");
            ranges.Add("1", string.Format("Under ${0}", priceFacet.Breakpoint1));
            ranges.Add("2", string.Format("${0}-${1}", priceFacet.Breakpoint1, priceFacet.Breakpoint2));
            ranges.Add("3", string.Format("${0}-${1}", priceFacet.Breakpoint2, priceFacet.Breakpoint3));
            ranges.Add("4", string.Format("${0}-${1}", priceFacet.Breakpoint3, priceFacet.Breakpoint4));
            ranges.Add("5", string.Format("${0}-${1}", priceFacet.Breakpoint4, priceFacet.Breakpoint5));
            ranges.Add("6", string.Format("${0}-${1}", priceFacet.Breakpoint5, priceFacet.Breakpoint6));
            ranges.Add("7", string.Format("Over ${0}", priceFacet.Breakpoint6));
            return ranges;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {            
            if (disposing)
            {
                if (_context != null)
                {                    
                    _context.Dispose();
                    _context = null;
                }
            }                            
        }
    }
}
