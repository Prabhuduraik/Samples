﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Afhs.Data.CustomClasses;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Afhs.Infrastructure.Helpers;
using Sitecore.Diagnostics;

namespace Afhs.Infrastructure
{
    public class ImageHelper
    {
        public static ImageData LoadProductImage(ExtendedProduct product)
        {
            ImageData imageData = ImageHelper.GetImageData(product);

            var color = String.IsNullOrEmpty(product.ProductAttributes["ColorDescription"]) ?
             String.Empty : product.ProductAttributes["ColorDescription"];

            if (!string.Equals(imageData.ImageAlt, "Image Not Found"))
            {
                imageData.ImageAlt = color + " " + imageData.ImageAlt ?? product.DisplayName;
            }
            else
            {            
                imageData.ImageAlt = color + " " + product.DisplayName;
            }
            return imageData;
        }

        public static string ImageNotFoundURL
        {
            get
            {
                var img = ConfigurationManager.AppSettings["ImageNotFoundURL"];
                return img;
            }
        }

        public static string SwatchImageNotFoundURL
        {
            get
            {
                var img = ConfigurationManager.AppSettings["SwatchImageNotFoundURL"];
                return img;
            }
        }

        public static List<ImageData> GetImageSetData(ExtendedProduct product)
        {
            using (new ProfileSection("Afhs.Web.Support.ImageHelper.GetImageSetData"))
            {
                var imageSetData = new List<ImageData>();
                ImageData imageData;

                try
                {
                    if (!String.IsNullOrEmpty(product.ImageSetID))
                    {
                        foreach (var imageUrl in Scene7ImageSetParser.GetImageSetForAsset(product.ImageSetID).Images)
                        {
                            imageData = new ImageData();
                            imageData.ImageID = imageUrl.Name;
                            imageData.ImageAlt = imageUrl.Description;
                            imageData.YoutubeId = imageUrl.YoutubeId != null ? imageUrl.YoutubeId.Replace("[yt]", "") : null;
                            imageSetData.Add(imageData);
                        }
                    }
                    else
                    {
                        imageSetData.Add(new ImageData() { ImageNotFound = true, ProductId = product.ExternalID });
                    }
                    return imageSetData;
                }
                catch (Exception ex)
                {
                    var errorMessage = new StringBuilder();
                    errorMessage.Append("Problem parsing Scene7 imageset =");
                    errorMessage.Append(product.ImageSetID);
                    errorMessage.Append(ex.Message);
                    errorMessage.Append(ex.StackTrace);
                    Log.Error(errorMessage.ToString(), typeof(ImageHelper));
                    imageSetData.Add(new ImageData() { ImageNotFound = true });
                    return imageSetData;
                }
            }
        }

        public static ImageData GetImageData(ExtendedProduct product)
        {
            if (product == null)
                return new ImageData { ImageNotFound = true };

            return GetImageData(product.DisplayName, product.PrimaryImageID, product.ImageSetID, product.ExternalID);
        }

        public static ImageData GetImageData(string displayName, string primaryImageId, string imageSetId, string externalId)
        {
            using (new ProfileSection("Afhs.Web.Support.ImageHelper.GetImageData"))
            {
                var imageData = new ImageData();

                try
                {


                    if (String.IsNullOrEmpty(primaryImageId))
                        return new ImageData { ProductId = externalId, ImageNotFound = true };

                    Scene7ImageSet set = null;
                    if (!String.IsNullOrEmpty(imageSetId))
                    {
                        try
                        {
                            set = Scene7ImageSetParser.GetImageSetForAsset(imageSetId);
                        }
                        catch
                        {
                            //Justification: The Scene7ImageSetParser.GetImageSetForAsset logs the error. The code following the catch block handles the error.
                        }
                    }

                    Scene7Image primaryImage = null;
                    if (set != null)
                    {
                        primaryImage = Scene7ImageSetParser.GetPrimaryImage(set, primaryImageId);
                    }

                    if (primaryImage != null)
                    {
                        imageData.ImageID = primaryImageId;
                        imageData.ImageAlt = primaryImage.Description;
                        imageData.YoutubeId = imageData.YoutubeId != null ? imageData.YoutubeId.Replace("[yt]", "") : null;
                    }
                    else
                    {
                        imageData.ImageID = primaryImageId;
                        imageData.ImageAlt = displayName;
                    }

                    return imageData;
                }
                catch (Exception ex)
                {
                    var errorMessage = new StringBuilder();
                    errorMessage.Append("Problem parsing Scene7 imageset =");
                    if (!String.IsNullOrEmpty(imageSetId))
                    {
                        errorMessage.Append(imageSetId);
                    }
                    else
                    {
                        errorMessage.Append("product-or-imagesetid-null");
                    }
                    errorMessage.Append(ex.Message);
                    errorMessage.Append(ex.StackTrace);
                    Log.Error(errorMessage.ToString(), typeof(ImageHelper));
                    return new ImageData() { ImageNotFound = true };
                }
            }
        }

        /// <summary>
        /// Gets ImageData for a color swatch
        /// </summary>
        /// <param name="colorSwatch">Color swatch to get image data for</param>
        public static ImageData GetColorSwatchImageData(string colorSwatch, string color)
        {
            if (String.IsNullOrEmpty(colorSwatch))
            {
                return new ImageData() { ImageNotFound = true };
            }

            try
            {
                ImageData imageData = new ImageData();
                imageData.ImageID = colorSwatch;

                if (!String.IsNullOrEmpty(color))
                {
                    imageData.ImageAlt = color;
                }
                else
                {
                    imageData.ImageAlt = String.Empty;
                }

                return imageData;
            }
            catch (Exception ex)
            {
                string errorMessage = String.Format("Error getting color swatch image data.\n\nMessage: {0}\n\nStackTrace: {1}", ex.Message, ex.StackTrace);
                Log.Error(errorMessage, typeof(ImageHelper));

                return new ImageData() { ImageNotFound = true };
            }

        }
    }
}