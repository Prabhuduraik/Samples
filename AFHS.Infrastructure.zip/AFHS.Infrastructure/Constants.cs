﻿using Sitecore.Data;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;

namespace Afhs.Infrastructure
{
    public static class Constants
    {
        public static string GetContentPath(string key)
        {
            return ((NameValueCollection)ConfigurationManager.GetSection("contentItemPaths"))[key];
        }


        #region "Sitecore"


        #region "Pages URL"

        public static string URL_PROFILE_PAGE = "/Profile";

        #endregion

        #region "Sublayouts path"

        public static string CONTROl_PRODUCT_ITEM_ALSOLIKEDRECOMMEND = "/sitecore/layout/Sublayouts/Common/ProductItemAlsoLikedRecommend";

        public static string RECENTLYVIEWED_SUBLAYOUT_PATH = "/sitecore/layout/Sublayouts/Common/RecentlyViewedProducts";
        public static string RECOMMENDED_SUBLAYOUT_PATH = "/sitecore/layout/Sublayouts/Common/RecommendedProducts";
        public static string RELATEDPRODUCTS_SUBLAYOUT_PATH = "/sitecore/layout/Sublayouts/Common/RelatedProducts";
        public static string PRODUCTSCARROUSEL_SUBLAYOUT_PATH = "/sitecore/layout/Sublayouts/Common/ProductsCarousel";
        public static string CONTROL_TOUTBLOCK = "/sitecore/layout/Sublayouts/ToutBlocks/ToutBlockPanel";
        public static string CONTROL_TOUTBLOCKSHORT = "/sitecore/layout/Sublayouts/ToutBlocks/ToutBlockShortPanel";
        public static string CONTROL_QATOUTBLOCK = "/sitecore/layout/Sublayouts/ToutBlocks/QandABlock";
        public static string CONTROL_PROMOTOUT = "/sitecore/layout/Sublayouts/PromoTouts/PromoToutControl";
        public static string CONTROL_PROMOTOUT_WITHHEADER = "/sitecore/layout/Sublayouts/PromoTouts/PromoToutWithHeader";
        public static string CONTROL_PROMOTOUT_WITHTEXTBOX = "/sitecore/layout/Sublayouts/PromoTouts/PromoToutWithTextBox";
        public static string CONTROL_TOUTBLOCK_LIST = "/sitecore/layout/Sublayouts/Common/ToutBlockListControl";
        public static string CONTROL_IMAGE_LANDING = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/LandingImage";
        public static string CONTROL_TEXT_LANDING = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/LandingText";
        public static string CONTROL_IMAGE_ONEFOURTH = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/ImageOneFourth";
        public static string CONTROL_IMAGE_ONETHIRD = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/ImageOneThird";
        public static string CONTROL_IMAGE_TWOTHIRDS = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/ImageTwoThirds";
        public static string CONTROL_SPLITIMAGE_ONETHIRD3070 = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/SplitImageModuleControls/SplitImageOneThird3070";
        public static string CONTROL_SPLITIMAGE_ONETHIRD5050 = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/SplitImageModuleControls/SplitImageOneThird5050";
        public static string CONTROL_TEXT_ONETHIRD = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/TextOneThirdControl";
        public static string CONTROL_TEXT_ONEFOURTH = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/TextOneFourthControl";
        public static string CONTROL_TEXT_ONETHIRD_MOBILE = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/TextOneThirdControlMobile";  
        public static string CONTROL_IMAGE_ONEHALF = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/ImageHeaderOneHalf";
        public static string CONTROL_STORE_ANNOUNCEMENT_LIST = "/sitecore/layout/Sublayouts/StoreUserControl/StoreAnnouncementListControl";
        public static string CONTROL_AVAILABLE_HOURS = "/sitecore/layout/Sublayouts/StoreUserControl/StoreAvailableHoursControl";
        public static string CONTROL_LIST_LANDING_PAGE = "/sitecore/layout/Sublayouts/ToutBlocks/LandingToutBlock";
        public static string CONTROL_NEW_OR_EVENT = "/sitecore/Layout/Sublayouts/StoreUserControl/NewOrEventControl";
        public static string CONTROL_JOB_OPENING = "/sitecore/Layout/Sublayouts/StoreUserControl/JobOpeningControl";
        public static string CONTROL_CHARITY = "/sitecore/Layout/Sublayouts/StoreUserControl/CharityControl";
        public static string CONTROL_ARTICLE = "/sitecore/Layout/Sublayouts/StoreUserControl/ArticleControl";

        public static string CONTROL_IMAGE_SMALL_CONTENT_DETAIL = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/ContentDetailSmallImage";
        public static string CONTROL_IMAGE_LARGE_CONTENT_DETAIL = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/ImageModule/ContentDetailLargeImage";
        public static string CONTROL_TEXT_CONTENT_DETAIL = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/ContentDetailText";
        public static string CONTROL_QATOUT = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/QandAText";
        public static string CONTROL_LINK_LIST = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/LinkList";
        public static string CONTROL_CONTACT_FORM_TOUT = "/sitecore/layout/Sublayouts/ToutBlocks/Touts/TextModuleControls/ContactFormTout";
        public static string CONTROL_CONTENT_DETAIL = "/sitecore/layout/Sublayouts/ToutBlocks/ContentDetailToutBlock";
        public static string CONTROl_SOCIAL_BAR = "/sitecore/layout/Sublayouts/SocialBar";
        public static string CONTROl_PRODUCT_ITEM = "/sitecore/layout/Sublayouts/ProductItem";
        public static string CONTROL_NAV_PRODUCT_GRID =  "/sitecore/layout/Sublayouts/NavigationProductGrid";
        public static string CONTROL_CATEGORY_GRID = "/sitecore/layout/Sublayouts/CategoryGrid";
        public static string CONTROL_CATEGORY_GRID_ITEM = "/sitecore/layout/Sublayouts/CategoryGridItem";
        public static string CONTROL_RAW_HTML = "/sitecore/layout/Sublayouts/Touts/RawHtmlLayout";
        public static string CONTROL_EMAIL_WEBSITE_OVERLAY = "/sitecore/layout/Sublayouts/Common/EmailWebSiteOverlayControl";
        
        public static string CONTROL_PRODUCT_IMAGE_NOTFOUND = "/sitecore/Media Library/Images/noImageFound";
        public static string CONTROL_PRODUCT_IMAGE_NOTFOUND_THUMB = "/sitecore/Media Library/Images/noImageFound_Thumb";
        public static string BASE_MEDIALIBRARY_PATH = "/sitecore/Media Library/Images/";
        public static string CONTROL_FACEBOOK_LOGIN = "/sitecore/layout/Sublayouts/Social/Connector/Login with Facebook";
        public static string CONTROL_HEADER = "/sitecore/layout/Sublayouts/Common/HeaderControl";
        public static string CONTROL_FOOTER = "/sitecore/layout/Sublayouts/Common/FooterControl";
        public static string CONTROL_TEXT_PARAGRAPH = "/sitecore/layout/Sublayouts/Common/Paragraphs/ParagraphOnlyTextControl";
        public static string CONTROL_IMAGE_TEXT_PARAGRAPH = "/sitecore/layout/Sublayouts/Common/Paragraphs/ParagraphWithImageControl";
        public static string CONTROL_VIDEO_TEXT_PARAGRAPH = "/sitecore/layout/Sublayouts/Common/Paragraphs/ParagraphWithVideoControl";
        public static string CONTROL_SEARCH_VIDEO_ITEM = "/sitecore/layout/Sublayouts/Common/SearchVideoItem";
        public static string CONTROL_EXPANSIVE_TOUTBLOCK = "/sitecore/layout/Sublayouts/ToutBlocks/ExpansiveToutBlockControl";
        public static string CONTROL_LANDING_NAVIGATION_LINKS = "/sitecore/layout/Sublayouts/LandingNavigationLinks";
        public static string CONTROL_CONTENTLANDING_NAVIGATION_LINKS = "/sitecore/layout/Sublayouts/ContentLandingNavegationLink";
        public static string CONTROL_ONE_IMAGE_CAROUSEL_NO_BUTTON = "/sitecore/layout/Sublayouts/OneImageCarouselNoButtonControl";
        public static string CONTROL_ONE_IMAGE_CAROUSEL_NO_CAPTION = "/sitecore/layout/Sublayouts/OneImageCarouselNoCaptionControl";
        public static string CONTROL_SWATCH_COLOR_PICKER = "/sitecore/layout/Sublayouts/Common/SwatchColorPicker";
        public static string CONTROL_SWATCH_DROP_DOWN_LIST = "/sitecore/layout/Sublayouts/Common/SwatchDropDownList";
        public static string CONTROL_ONE_IMAGE_CAROUSEL_HALF_CAPTION = "/sitecore/layout/Sublayouts/OneImageCarouselHalfCaptionControl";

        #endregion

        #region "Template names"

        public static string TEMPLATE_TOUTBLOCK = "ToutBlock";
        public static string TEMPLATE_TOUTBLOCKSHORT = "ToutBlockShort";
        public static string TEMPLATE_PROMOTOUT = "PromoTout";
        public static string TEMPLATE_PROMOTOUT_WITHHEADER = "PromoTout-WithHeader";
        public static string TEMPLATE_PROMOTOUT_WITHTEXTBOX = "PromoTout-WithTextBox";
        public static string TEMPLATE_IMAGE_LANDING = "LandingImage";
        public static string TEMPLATE_TEXT_LANDING = "LandingText";
        public static string TEMPLATE_IMAGE_ONEFOURTH = "Image-OneFourth";
        public static string TEMPLATE_IMAGE_ONETHIRD = "Image-OneThird";
        public static string TEMPLATE_IMAGE_TWOTHIRDS = "Image-TwoThirds";
        public static string TEMPLATE_SPLITIMAGE_ONETHIRD3070 = "SplitImage-OneThird-3070";
        public static string TEMPLATE_SPLITIMAGE_ONETHIRD5050 = "SplitImage-OneThird-5050";
        public static string TEMPLATE_TEXT_ONETHIRD = "Text-OneThird";
        public static string TEMPLATE_TEXT_ONEFOURTH = "Text-OneFourth";
        public static string TEMPLATE_TEXT_ONETHIRD_MOBILE = "Text-OneThirdControlMobile";
        public static string TEMPLATE_IMAGE_ONEHALF = "ImageHeader-OneHalf";
        public static string TEMPLATE_QATOUTBLOCK = "QandABlock";
        public static string TEMPLATE_QATOUT = "QandA";
        public static string TEMPLATE_CONTENT_DETAIL = "ContentDetailToutBlock";
        public static string TEMPLATE_LINK_LIST = "LinkList";
        public static string TEMPLATE_CONTACT_FORM_TOUT = "ContactFormTout";
        public static string TEMPLATE_RAW_HTML = "RawHtml";

        public static string TEMPLATE_IMAGE_SMALL_CONTENT_DETAIL = "ContentDetailSmallImage";
        public static string TEMPLATE_IMAGE_LARGE_CONTENT_DETAIL = "ContentDetailLargeImage";
        public static string TEMPLATE_TEXT_CONTENT_DETAIL = "ContentDetailText";
        public static string TEMPLATE_CITY = "City";
        public static string TEMPLATE_EXTENDED_PRODUCT = "ExtendedProduct";
        public static string TEMPLATE_EXTENDED_PRODUCT_CLASSIFICATION = "ExtendedProductClassification";
        public static string TEMPLATE_STORE = "Store";
        public static string TEMPLATE_COUNTRY = "Country";
        public static string TEMPLATE_STATE = "State";
        public static string TEMPLATE_TEXT_PARAGRAPH = "ParagraphWithOnlyText";
        public static string TEMPLATE_IMAGE_TEXT_PARAGRAPH = "ParagraphWithImage";
        public static string TEMPLATE_VIDEO_TEXT_PARAGRAPH = "ParagraphWithVideo";
        public static string TEMPLATE_EXPANSIVE_TOUTBLOCK = "ExpansiveToutBlock";
        public static string TEMPLATE_LEFT_NAVIGATION_SECTION = "LeftNavSection";
        public static string TEMPLATE_STORE_LOCATOR = "StoreLocator";
        public static string TEMPLATE_EMAIL_WEBSITE_OVERLAY = "EmailWebSiteOverlay";
        public static string TEMPLATE_YOUTUBE_THUMBANIL_ITEM = "YouTubeThumbnailItem";
        public static string TEMPLATE_LOGIN_PAGE = "Login";
        public static string TEMPLATE_GUEST_ORDER_DETAILS_PAGE = "OrderStatusDetail";


        #endregion

        #region "Template ID"

        public static string TEMPLATE_CALLTOACTION_ID = "{9801A7A0-4A5C-4C93-BA30-A8BDD1B5952A}";
        public static string ITEM_MAINMENUFOLDER_ID = "{770E4AFE-0410-49A7-B1B5-7BCE3979FDFA}";
        public static string TEMPLATE_COLUMNMENUFOLDER_ID = "{A87A00B1-E6DB-45AB-8B54-636FEC3B5523}";
        public static string TEMPLATE_MENUACTION_ID= "{0BE2838F-F485-4E61-AD94-E3BC78E73344}";
        public static string TEMPLATE_FOLDERCOLUM_ID = "{A87A00B1-E6DB-45AB-8B54-636FEC3B5523}";
        public static string TEMPLATE_HOME_ID = "{7653C1D3-C426-411B-B236-345E71D978DD}";

        #endregion

        #region "Web config"

        public static string WEBCONFIG_ASHLEY_MEDIA_KEY = "AshleyMediaBasePath";
        public static string WEBCONFIG_YOUTUBE_THUMBNAIL_KEY = "YoutubeThumbnailPath";
        public static string WEBCONFIG_YOUTUBE_VIDEO_KEY = "YoutubeVideoPath";
        public static string WEBCONFIG_AKAMI_BASE_URL = "AkamaiBaseUrl";
        public static string WEBCONFIG_AKAMI_PURGUE_REQUEST_URL = "AkamaiPurgueRequestUrl";
        public static string WEBCONFIG_AKAMI_USER = "AkamaiUser";
        public static string WEBCONFIG_AKAMI_PASSWORD = "AkamaiPassword";
        public static string WEBCONFIG_AKAMAI_ASHLEY_ENV_URL = "AkamaiAshleyBaseUrl";
        public static string WEBCONFIG_QPB_UPPERBOUND = "QuantityPerBoxUpperBound";
        public static string RECAPTCHA_SITE_KEY = "ReCaptchaSiteKey";
        public static string RESET_LINK_EXPIRATION_HOURS = "ResetLinExpirationHours";
        public static string CURRENT_HOST_URL = "CurrentHostUrl";


        #endregion

        #region "Facebook constants"

        public static string FACEBOOK_APP_PATH = "/sitecore/system/Social/Applications/Default/Facebook";

        #endregion

        #region "Pages"

        public static string PAGE_STORE_LOCATOR = "furniture-stores";

        #endregion

        #region "Store Synchornization"

        #region "Fields matching"

        // ...FIELDS_TO_MATCH_STRING Notes: 
        // 1) SitecoreFieldName + ':' + AshleyFieldName + ('|' if more fields must be specified, else empty '')
        //      the ':' is used to mark on left side, the sitecore field name, on right side the ashley field name related to.
        // 2) The dictionaries will have:
        //      Key: sitecore field name
        //      Value: ashley field name related to
        private static string STORESYNC_COUNTRY_FIELDS_TO_MATCH_STRING = "CountryCode:CountryCode|CountryDescription:CountryDescription|DisplayOrder:DisplayOrder"+
                            "|ISOCountryCode:ISOCountryCode";
        public static Dictionary<string, string> STORESYNC_COUNTRY_FIELDS_TO_MATCH
        {
            get
            {
                return ExtractKeyValueForString(STORESYNC_COUNTRY_FIELDS_TO_MATCH_STRING, '|', ':');
            }
        }

        private static string STORESYNC_STATE_FIELDS_TO_MATCH_STRING = "Code:StateCode|Name:StateName";
        public static Dictionary<string, string> STORESYNC_STATE_FIELDS_TO_MATCH
        {
            get
            {
                return ExtractKeyValueForString(STORESYNC_STATE_FIELDS_TO_MATCH_STRING, '|', ':');
            }
        }

        public static string STORESYNC_STORE_FIELDS_TO_MATCH_STRING = string.Format("{0}:{0}|{1}:{1}|{2}:{2}|{3}:{3}|{4}:{4}|{5}:{5}|{6}:{6}|{7}:{7}|{8}:{8}|{9}:{9}|"
            +"{10}:{10}|{11}:{11}|{12}:{12}|{13}:{13}|{14}:{14}|{15}:{15}|{16}:{16}|{17}:{17}|{18}:{18}|{19}:{19}|{20}:{20}|{21}:{21}|{22}:{22}|{23}:{23}|{24}:{24}|"
            + "{25}:{25}|{26}:{26}|{27}:{27}|{28}:{28}", 
            "Address", "CustomerServicePhone", "Email", "FaxPhone", "ScreenTitleLightPart", "ScreenTitleBoldPart", "StoreDescription", "StoreID", "StorePhone", "Alias",
            "StoreImage", "BannerImage", "CustomerNumber", "ShipTo", "WeeklyAdLink", "CouponLink", "ArticleTitle", "ArticleImage", "ArticleImageLink",
            "ArticleDescription", "RawAddress", "ZipCode", "StoreWorkingHours", "CustomerServiceHours", "AccountNumber", "IsRDC", "AddressCity", "AddressState", 
            "StreetNumberAndExtraInfo");
        public static Dictionary<string, string> STORESYNC_STORE_FIELDS_TO_MATCH
        {
            get
            {
                return ExtractKeyValueForString(STORESYNC_STORE_FIELDS_TO_MATCH_STRING, '|', ':');
            }
        }

        public static string STORESYNC_OPEN_HOUR_SUFFIX = "Open";
        public static string STORESYNC_CLOSE_HOUR_SUFFIX = "Close";

        #endregion

        #region "Template path"

        public static string TEMPLATE_PATH_COUNTRY = "User Defined/Country";
        public static string TEMPLATE_PATH_STATE = "User Defined/State";
        public static string TEMPLATE_PATH_CITY = "User Defined/City";
        public static string TEMPLATE_PATH_STORE = "User Defined/Store";
        public static string TEMPLATE_PATH_DAY_WORKING_HOUR = "User Defined/DayWorkingHour";
        public static string TEMPLATE_PATH_NEW_OR_EVENT = "User Defined/NewOrEvent";
        public static string TEMPLATE_PATH_JOB_OPENING = "User Defined/JobOpening";
        public static string TEMPLATE_PATH_CHARITY = "User Defined/Charity";
        public static string TEMPLATE_PATH_YOUTUBE_ITEM = "User Defined/Carousels/YouTubeThumbnailItem";

        #endregion

        public static string STORESYNC_DEFAULT_VALUE = "undefined";

        #endregion

        #region "Facets Item IDs"        
        public static string SITECORE_FACET_TEMPLATE_ID = "{5C125B6D-C481-4C24-B5B9-9A23FE396BF0}";

        public static string FACET_PRICE_01 = "{C15A59A3-9D9B-4285-B380-026C12196A69}";
        public static string FACET_PRICE_02 = "{1B535E56-0940-4440-A631-1C4A1BAD76D0}";
        public static string FACET_PRICE_03 = "{3C76C135-F449-44B2-A401-94664D59EC00}";
        public static string FACET_PRICE_04 = "{CAE9ED40-F6D3-4529-9C94-6D845602DA81}";
        public static string FACET_PRICE_05 = "{49522009-0DA5-4928-9E9A-915627E939F1}";
        public static string FACET_PRICE_06 = "{C0C783D9-15B9-420E-9FC8-D81C4F82BAC2}";
        public static string FACET_PRICE_07 = "{3ADE39DE-EF15-4445-BF67-6DA12B7BF354}";
        public static string FACET_PRICE_08 = "{7989180A-28EE-4E28-97C9-26504ABD3480}";
        public static string FACET_PRICE_09 = "{74448C96-09DD-4041-A031-A84D312A084C}";
        public static string FACET_PRICE_10 = "{34815D0B-C697-41A6-8D6D-79579E429E4E}";

        #endregion

        #region "Lucene"

        public static string LUCENE_SWATCH_GROUP_ID = "pa.swatchgroupid";

        #endregion

        #region "Profile"

        public static string AX_ACCOUNT_PROPERTY = "axAccountNumber";
        public static string EMAIL_CAMPAIGN_ONLY_PROPERTY = "isEmailCampaignOnly";
        public static string PROFILE_FIRST_NAME = "scAccountFirstName";
        public static string PROFILE_LAST_NAME = "scAccountLastName";

        #endregion

        #endregion


        #region "Store synchronization"

        public static string INSERTS_2_ONLINE = "inserts2online";
        public static string ASHLEY_CAREERWEBSITE_URI = "http://ashleyfurniture-fo.luceosolutions.com/";

        #endregion


        public static string PHONE_ICON_SRC = "/img/storeDetails/cel-icon.png";
        public static string HEAD_ICON_SRC = "/img/storeDetails/animal-icon.png";
        public static int LIMIT = 10;
        public static string RecentlyViewedProductsCookie = "RecentlyViewedProducts";
        public static string PRODUCTS_NOT_AVAILABLE_COOKIE = "ProductsNotAvailable";
        public static string ANONYMOUS_USER_NAME = "Anonymous";
        public static string ADMINISTRATOR_USER_NAME = "Admin";
        public static string SWATCH_FIELD_NAME = ConfigurationManager.AppSettings["SwatchFieldName"];
        public static string ECOMM_ALSO_AVAILABLE_FIELD_NAME = ConfigurationManager.AppSettings["ProductOptionAttribute"];
        public static string GUESTCHECKOUT_COOKIE_NAME = "IsGuestCheckout";
        public static string CID_COOKIE_NAME = "CID";
        public static string DISABLE_ADDTOCART_BUTTON = "DisableAddToCart";
        public static string ADOBE_DTM_KEY = "AdobeDTMKey";
        public static ID DELIVERY_CHARGE_ITEM { get { return new ID("BB1503F5-C6F0-3D08-C38F-0374E2C7E9BD"); } }  

        private static Dictionary<string, string> ExtractKeyValueForString(string value, char pairSeparator, char keyValueSeparator)
        {
            return value.Split(pairSeparator).ToList().Select(fieldPair => fieldPair.Split(keyValueSeparator).ToList()).ToDictionary(data => data[0], data => data[1]);
        }        
    }
}