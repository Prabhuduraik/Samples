﻿using Afhs.Data.Models.sitecore.templates.User_Defined;
using BingMapsRESTService.Common.JSON;
using Glass.Mapper.Sc;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Web;
using System.Web.Script.Serialization;

namespace Afhs.Infrastructure.BingMaps
{
    public class BingMapsHelper
    {
        public static Tuple<double, double> GetLocation(string zipCode, string country)
        {
            var apiKeyItem = new SitecoreContext().GetItem<SingleText>(Constants.GetContentPath("BING_MAPS_API_KEY_ITEM"));
            string url = string.Format("//dev.virtualearth.net/REST/v1/Locations?CountryRegion={0}&postalCode={1}&maxResults=1&key={2}", country, zipCode, apiKeyItem.Description);
            Response bingMapResponse = GetResponse(url);
            Tuple<double, double> point = null;

            if (bingMapResponse.ResourceSets.Length > 0 && bingMapResponse.ResourceSets[0].Resources.Length > 0)
            {
                var location = bingMapResponse.ResourceSets[0].Resources[0] as Location;
                var latitude = location.Point.Coordinates[0];
                var longitude = location.Point.Coordinates[1];
                point = new Tuple<double, double>(latitude, longitude);
            }

            return point;
        }

        private static Response GetResponse(string url)
        {
            if (HttpContext.Current.Request.IsSecureConnection)
            {
                url = "https:" + url;
            }
            else
            {
                url = "http:" + url;
            }

            var webRequest = HttpWebRequest.Create(url);
            IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);
            // Block the thread until the web request is finished.
            asyncResult.AsyncWaitHandle.WaitOne();
            WebResponse webResponse = webRequest.EndGetResponse(asyncResult);
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(Response));
            Response bingMapResponse = serializer.ReadObject(webResponse.GetResponseStream()) as Response;
            return bingMapResponse;
        }
    }
}
