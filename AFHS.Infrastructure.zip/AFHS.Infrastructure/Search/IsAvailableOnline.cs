﻿using Afhs.Data.CustomClasses;
using Afhs.Infrastructure.Cache;
using Afhs.Infrastructure.Helpers;
using AFM.Commerce.Services;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    public class IsAvailableOnline : IComputedIndexField
    {
        const string EXTENDED_PRODUCT_TEMPLATE = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        public string FieldName { get; set; }
        public string ReturnType { get; set; }

        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            if (item != null && item.TemplateID.Equals(ID.Parse(EXTENDED_PRODUCT_TEMPLATE)))
            {
                if (!item["IsECommOwned"].Equals("1"))
                    return 0;

                var externalId = item["ExternalID"];
                var price = PricingHelper.GetProductWithPrice(externalId);

                if (price.LowestPrice > 0)
                    return 1;
                else
                    return 0;
            }

            return null;
        }
    }
}
