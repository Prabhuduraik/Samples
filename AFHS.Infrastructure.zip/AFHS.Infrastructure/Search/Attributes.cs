﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    public class Attributes : IComputedIndexField
    {
        public string FieldName { get; set; }

        public string ReturnType { get; set; }

        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            List<string> att = new List<string>();
            if (item != null && item.TemplateID.Equals(ID.Parse("{944D9A1D-C88E-484A-92DF-F674BA9B4611}")))
            {
                NameValueListField mf = item.Fields[ID.Parse("{5DEFCD33-47A9-4807-B191-C3613977DBED}")];
                if (mf != null && mf.NameValues.Count > 0)
                {
                    System.Collections.Specialized.NameValueCollection nvc = WebUtil.ParseUrlParameters(mf.Value);                   
                    foreach (string key in nvc.AllKeys)
                    {
                        if (INDEXED_PRODUCTS_ATTRIBUTES.Contains(key) && !string.IsNullOrEmpty(nvc[key]))
                        { att.Add(string.Format("{0}:{1}", key, nvc[key])); }
                    }
                }
            }
            return att.ToArray();
        }

        private const string INDEXED_PRODUCTS_ATTRIBUTES = "Material|Fabric|StyleDescription|SeriesNumber|Pattern|Cartonheight(inches)|" +
            "Cartonwidth(inches)|Cartondepth(inches)|ProductWidth(inches)|ProductHeight(inches)|Quantityperbox|BestSelling|Features|" +
            "Shade|Showroom|ColorID|ItemCodeDescription|SeriesFluff|ProductName|Description|Brand";

    }
}
