﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Search
{
    public abstract class ProductMultiValueAttributes : IComputedIndexField
    {
        const string EXTENDED_PRODUCT_TEMPLATE = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        const string MULTI_VALUE_ATTRIBUTTES_FIELD = "{48CC8FB8-E715-47AC-B73F-EB571148EC2A}";
        protected string Param { get; set; }
        protected bool PreventLowerCasing { get; set; }
        public object ComputeFieldValue(IIndexable indexable)
        {            
            Item item = indexable as SitecoreIndexableItem;
            var values = new List<string>();

            if (item != null && item.TemplateID.Equals(ID.Parse(EXTENDED_PRODUCT_TEMPLATE)) && !string.IsNullOrWhiteSpace(Param))
            {
                NameValueListField multiValueAttributes = item.Fields[ID.Parse(MULTI_VALUE_ATTRIBUTTES_FIELD)];
                if (multiValueAttributes != null && multiValueAttributes.NameValues.Count > 0)
                {
                    NameValueCollection productsAttributesCollection = HttpUtility.ParseQueryString(multiValueAttributes.Value);

                    if (productsAttributesCollection.AllKeys.Contains(Param))
                    {
                        var value = productsAttributesCollection[Param];
                        foreach (var val in value.Split('~'))
                        {
                            if (!string.IsNullOrWhiteSpace(val))
                            {
                                if (PreventLowerCasing)
                                {
                                    values.Add(val);
                                }
                                else
                                {
                                    values.Add(val.ToLower());
                                }
                            }
                        }
                    }

                }
            }

            return values.Count > 0 ? values : null;
        }

        public string FieldName { get; set; }

        public string ReturnType { get; set; }
    }

    public class Backing : ProductMultiValueAttributes
    {
        public Backing()
            : base()
        {
            Param = "Backing";
            PreventLowerCasing = false;
        }
    }
    public class BarstoolHeight : ProductMultiValueAttributes
    {
        public BarstoolHeight()
            : base()
        {
            Param = "BarstoolHeight";
            PreventLowerCasing = false;
        }
    }
    public class DiningSeating : ProductMultiValueAttributes
    {
        public DiningSeating()
            : base()
        {
            Param = "DiningSeating";
            PreventLowerCasing = false;
        }
    }
    public class Color2 : ProductMultiValueAttributes
    {
        public Color2()
            : base()
        {
            Param = "Color2";
            PreventLowerCasing = false;
        }
    }
    public class Fabric : ProductMultiValueAttributes
    {
        public Fabric()
            : base()
        {
            Param = "Fabric";
            PreventLowerCasing = false;
        }
    }
    public class WebItemFeature : ProductMultiValueAttributes
    {
        public WebItemFeature()
            : base()
        {
            Param = "WebItemFeature";
            PreventLowerCasing = false;
        }
    }
    public class Type4 : ProductMultiValueAttributes
    {
        public Type4()
            : base()
        {
            Param = "Type4";
            PreventLowerCasing = false;
        }
    }
    public class Material : ProductMultiValueAttributes
    {
        public Material()
            : base()
        {
            Param = "Material";
            PreventLowerCasing = false;
        }
    }
    public class NumberOfDrawers : ProductMultiValueAttributes
    {
        public NumberOfDrawers()
            : base()
        {
            Param = "NumberofDrawers";
            PreventLowerCasing = false;
        }
    }
    public class NumberofPieces : ProductMultiValueAttributes
    {
        public NumberofPieces()
            : base()
        {
            Param = "NumberofPieces";
            PreventLowerCasing = false;
        }
    }
    public class NumberofShelves : ProductMultiValueAttributes
    {
        public NumberofShelves()
            : base()
        {
            Param = "NumberofShelves";
            PreventLowerCasing = false;
        }
    }
    public class Pattern : ProductMultiValueAttributes
    {
        public Pattern()
            : base()
        {
            Param = "Pattern";
            PreventLowerCasing = false;
        }
    }
    public class RoomType : ProductMultiValueAttributes
    {
        public RoomType()
            : base()
        {
            Param = "RoomType";
            PreventLowerCasing = false;
        }
    }   
    public class Shade : ProductMultiValueAttributes
    {
        public Shade()
            : base()
        {
            Param = "Shade";
            PreventLowerCasing = false;
        }
    }    
    public class TableShape : ProductMultiValueAttributes
    {
        public TableShape()
            : base()
        {
            Param = "TableShape";
            PreventLowerCasing = false;
        }
    }
    public class TableTop : ProductMultiValueAttributes
    {
        public TableTop()
            : base()
        {
            Param = "TableTop";
            PreventLowerCasing = false;
        }
    }
    public class ThrowFabric : ProductMultiValueAttributes
    {
        public ThrowFabric()
            : base()
        {
            Param = "ThrowFabric";
            PreventLowerCasing = false;
        }
    }
    public class ThrowPillowFabricType : ProductMultiValueAttributes
    {
        public ThrowPillowFabricType()
            : base()
        {
            Param = "ThrowPillowFabricType";
            PreventLowerCasing = false;
        }
    }
    public class Size : ProductMultiValueAttributes
    {
        public Size()
            : base()
        {
            Param = "Size";
            PreventLowerCasing = false;
        }
    }
    public class Size2 : ProductMultiValueAttributes
    {
        public Size2()
            : base()
        {
            Param = "Size2";
            PreventLowerCasing = false;
        }
    }
    public class Size3 : ProductMultiValueAttributes
    {
        public Size3()
            : base()
        {
            Param = "Size3";
            PreventLowerCasing = false;
        }
    }
    public class Size4 : ProductMultiValueAttributes
    {
        public Size4()
            : base()
        {
            Param = "Size4";
            PreventLowerCasing = false;
        }
    }
    public class Size5 : ProductMultiValueAttributes
    {
        public Size5()
            : base()
        {
            Param = "Size5";
            PreventLowerCasing = false;
        }
    }
    public class Features : ProductMultiValueAttributes
    {
        public Features()
            : base()
        {
            Param = "Features";
            PreventLowerCasing = false;
        }
    }
    public class Features2 : ProductMultiValueAttributes
    {
        public Features2()
            : base()
        {
            Param = "Features2";
            PreventLowerCasing = false;
        }
    }
    public class Features3 : ProductMultiValueAttributes
    {
        public Features3()
            : base()
        {
            Param = "Features3";
            PreventLowerCasing = false;
        }
    }
    public class Features4 : ProductMultiValueAttributes
    {
        public Features4()
            : base()
        {
            Param = "Features4";
            PreventLowerCasing = false;
        }
    }
    public class Features5 : ProductMultiValueAttributes
    {
        public Features5()
            : base()
        {
            Param = "Features5";
            PreventLowerCasing = false;
        }
    }
    public class Features6 : ProductMultiValueAttributes
    {
        public Features6()
            : base()
        {
            Param = "Features6";
            PreventLowerCasing = false;
        }
    }
    public class Features7 : ProductMultiValueAttributes
    {
        public Features7()
            : base()
        {
            Param = "Features7";
            PreventLowerCasing = false;
        }
    }
    public class BedFeature : ProductMultiValueAttributes
    {
        public BedFeature()
            : base()
        {
            Param = "BedFeature";
            PreventLowerCasing = false;
        }
    }
    public class Brand2 : ProductMultiValueAttributes
    {
        public Brand2()
            : base()
        {
            Param = "Brand2";
            PreventLowerCasing = false;
        }
    }
    public class FoundationFeatures : ProductMultiValueAttributes
    {
        public FoundationFeatures()
            : base()
        {
            Param = "FoundationFeatures";
            PreventLowerCasing = false;
        }
    }
    public class LeafType : ProductMultiValueAttributes
    {
        public LeafType()
            : base()
        {
            Param = "LeafType";
            PreventLowerCasing = false;
        }
    }
    public class PillowMaterial : ProductMultiValueAttributes
    {
        public PillowMaterial()
            : base()
        {
            Param = "PillowMaterial";
            PreventLowerCasing = false;
        }
    }
    public class PlatformFeatures : ProductMultiValueAttributes
    {
        public PlatformFeatures()
            : base()
        {
            Param = "PlatformFeatures";
            PreventLowerCasing = false;
        }
    }
    public class Shape : ProductMultiValueAttributes
    {
        public Shape()
            : base()
        {
            Param = "Shape";
            PreventLowerCasing = false;
        }
    }
    public class BedStyle : ProductMultiValueAttributes
    {
        public BedStyle()
            : base()
        {
            Param = "BedStyle";
            PreventLowerCasing = false;
        }
    }
    public class Style2 : ProductMultiValueAttributes
    {
        public Style2()
            : base()
        {
            Param = "Style2";
            PreventLowerCasing = false;
        }
    }
    public class SleepPosition : ProductMultiValueAttributes
    {
        public SleepPosition()
            : base()
        {
            Param = "SleepPosition";
            PreventLowerCasing = false;
        }
    }
    public class SleeperSize : ProductMultiValueAttributes
    {
        public SleeperSize()
            : base()
        {
            Param = "SleeperSize";
            PreventLowerCasing = false;
        }
    }
    public class SpecialFeatures : ProductMultiValueAttributes
    {
        public SpecialFeatures()
            : base()
        {
            Param = "SpecialFeatures";
            PreventLowerCasing = false;
        }
    }
    public class Support : ProductMultiValueAttributes
    {
        public Support()
            : base()
        {
            Param = "Support";
            PreventLowerCasing = false;
        }
    }
    public class TableHeight : ProductMultiValueAttributes
    {
        public TableHeight()
            : base()
        {
            Param = "TableHeight";
            PreventLowerCasing = false;
        }
    }
    public class ThreadCount : ProductMultiValueAttributes
    {
        public ThreadCount()
            : base()
        {
            Param = "ThreadCount";
            PreventLowerCasing = false;
        }
    }
    public class Type : ProductMultiValueAttributes
    {
        public Type()
            : base()
        {
            Param = "Type";
            PreventLowerCasing = false;
        }
    }
    public class Type2 : ProductMultiValueAttributes
    {
        public Type2()
            : base()
        {
            Param = "Type2";
            PreventLowerCasing = false;
        }
    }
    public class Type3 : ProductMultiValueAttributes
    {
        public Type3()
            : base()
        {
            Param = "Type3";
            PreventLowerCasing = false;
        }
    }
    public class Type5 : ProductMultiValueAttributes
    {
        public Type5()
            : base()
        {
            Param = "Type5";
            PreventLowerCasing = false;
        }
    }
    public class Type6 : ProductMultiValueAttributes
    {
        public Type6()
            : base()
        {
            Param = "Type6";
            PreventLowerCasing = false;
        }
    }
    public class Type7 : ProductMultiValueAttributes
    {
        public Type7()
            : base()
        {
            Param = "Type7";
            PreventLowerCasing = false;
        }
    }
    public class Type8 : ProductMultiValueAttributes
    {
        public Type8()
            : base()
        {
            Param = "Type8";
            PreventLowerCasing = false;
        }
    }
    public class Type9 : ProductMultiValueAttributes
    {
        public Type9()
            : base()
        {
            Param = "Type9";
            PreventLowerCasing = false;
        }
    }
    public class NumberOfDoors : ProductMultiValueAttributes
    {
        public NumberOfDoors()
            : base()
        {
            Param = "NumberofDoors";
            PreventLowerCasing = false;
        }
    }
    public class BaseType : ProductMultiValueAttributes
    {
        public BaseType()
            : base()
        {
            Param = "BaseType";
            PreventLowerCasing = false;
        }
    }
    public class SwatchGroupId : ProductMultiValueAttributes
    {
        public SwatchGroupId()
            : base()
        {
            Param = Constants.SWATCH_FIELD_NAME;
            PreventLowerCasing = false;
        }
    }
    public class EcommAlsoAvailable : ProductMultiValueAttributes
    {
        public EcommAlsoAvailable()
            : base()
        {
            Param = Constants.ECOMM_ALSO_AVAILABLE_FIELD_NAME;
            PreventLowerCasing = false;
        }
    }
    public class ColorSwatch : ProductMultiValueAttributes
    {
        public ColorSwatch()
            : base()
        {
            Param = "ColorSwatch";
            PreventLowerCasing = true;
        }
    }
    public class RolloverImage : ProductMultiValueAttributes
    {
        public RolloverImage()
            : base()
        {
            Param = "RolloverImage";
            PreventLowerCasing = true;
        }
    }
}
