﻿using Afhs.Data.CustomClasses;
using Afhs.Infrastructure.Helpers;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Items;
using Glass.Mapper.Sc;

namespace Afhs.Infrastructure.Search
{
    public class OnSale : IComputedIndexField
    {
        const string EXTENDED_PRODUCT_TEMPLATE = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        public string FieldName { get; set; }

        public string ReturnType { get; set; }

        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            
            if (item != null && item.TemplateID.Equals(ID.Parse(EXTENDED_PRODUCT_TEMPLATE)))
            {
                bool onSale = false;

                if (item["IsECommOwned"].Equals("1"))
                {
                    var productWithPrice = PricingHelper.GetProductWithPrice(item["ExternalID"]);
                    if (productWithPrice != null && productWithPrice.IsOnSale)
                        onSale = true;
                }

                if (onSale)
                    return onSale;             
            }

            return null;
        }
    }
}
