﻿using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Standard;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    public class StemmingAnalyzer : Analyzer
    {

        private ISet<string> stopSet;

        /// <summary>
        /// Creates an analyzer with the default stop word list.
        /// </summary>
        public StemmingAnalyzer() : this(StopAnalyzer.ENGLISH_STOP_WORDS_SET) { }

        /// <summary>
        /// Creates an analyzer with the passed in stop words list.
        /// </summary>
        public StemmingAnalyzer(ISet<string> stopWords)
        {
            stopSet = stopWords;
        }

        public override TokenStream TokenStream(string fieldName, System.IO.TextReader reader)
        {
            TokenStream tokenStream = new StandardTokenizer(Lucene.Net.Util.Version.LUCENE_30, reader);
            tokenStream = new StandardFilter(tokenStream);
            tokenStream = new LowerCaseFilter(tokenStream);
            tokenStream = new StopFilter(true, tokenStream, stopSet);
            tokenStream = new PorterStemFilter(tokenStream);

            return tokenStream;
        }
    }
}
