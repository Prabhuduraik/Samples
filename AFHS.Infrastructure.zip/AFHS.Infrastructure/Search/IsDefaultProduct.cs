﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    class IsDefaultProduct : IComputedIndexField
    {
        const string EXTENDED_PRODUCT_TEMPLATE = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        const string PRODUCT_ATTRIBUTES_FIELD = "{5DEFCD33-47A9-4807-B191-C3613977DBED}";
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            if (item != null && item.TemplateID.Equals(ID.Parse(EXTENDED_PRODUCT_TEMPLATE)))
            {
                NameValueListField productAttributes = item.Fields[ID.Parse(PRODUCT_ATTRIBUTES_FIELD)];
                if (productAttributes != null && productAttributes.NameValues.Count > 0)
                {
                    if (productAttributes.NameValues.AllKeys.Contains("DefaultProduct"))
                    {
                        if (productAttributes.NameValues["DefaultProduct"].ToLower().Equals("1"))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }

            return null;
        }

        public string FieldName
        {
            get;
            set;
        }

        public string ReturnType
        {
            get;
            set;
        }
    }
}
