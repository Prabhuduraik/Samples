﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Search
{
    public abstract class ProductAttributes : IComputedIndexField
    {
        const string EXTENDED_PRODUCT_TEMPLATE = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        const string PRODUCT_ATTRIBUTES_FIELD = "{5DEFCD33-47A9-4807-B191-C3613977DBED}";
        protected string Param { get; set; }
        protected SearchReturnType Type { get; set; }
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            var value = string.Empty;

            if (item != null && item.TemplateID.Equals(ID.Parse(EXTENDED_PRODUCT_TEMPLATE)) && !string.IsNullOrWhiteSpace(Param))
            {
                NameValueListField productsAttributesField = item.Fields[ID.Parse(PRODUCT_ATTRIBUTES_FIELD)];                
                
                if (productsAttributesField != null && productsAttributesField.NameValues.Count > 0)
                {
                    NameValueCollection productsAttributesCollection = HttpUtility.ParseQueryString(productsAttributesField.Value);

                    switch (Type)
                    {
                        case SearchReturnType.Int:
                            int number = 0;
                            
                            if (productsAttributesCollection.AllKeys.Contains(Param))
                            {
                                value = productsAttributesCollection[Param].ToLower();
                                int.TryParse(value, out number);
                            }

                            return number;

                        case SearchReturnType.DateTime:
                            DateTime date = new DateTime();

                            if (productsAttributesCollection.AllKeys.Contains(Param))
                            {
                                value = productsAttributesCollection[Param];
                               if(DateTime.TryParseExact(value, "M/d/yyyy hh:mm:ss tt zzzz", null, System.Globalization.DateTimeStyles.None, out date))
                                    return date;
                            }

                            return null;
                            
                        default:
                            if (productsAttributesCollection.AllKeys.Contains(Param))
                            {
                                value = productsAttributesCollection[Param].ToLower();
                            }

                            break;
                    }
                }
            }

            return !string.IsNullOrWhiteSpace(value) ? value : null;
        }

        public string FieldName { get; set; }

        public string ReturnType { get; set; }

        
    }

    public class ColorDescription : ProductAttributes
    {
        public ColorDescription():base()
        {
            Param = "ColorDescription";

        }
    }
    public class StyleDescription : ProductAttributes
    {
        public StyleDescription()
            : base()
        {
            Param = "StyleDescription";
        }
    }
  
    public class Description : ProductAttributes
    {
        public Description()
            : base()
        {
            Param = "Description";
        }
    }
    public class ItemCodeDescription : ProductAttributes
    {
        public ItemCodeDescription()
            : base()
        {
            Param = "ItemCodeDescription";
        }
    }
    public class SeriesFluff : ProductAttributes
    {
        public SeriesFluff()
            : base()
        {
            Param = "SeriesFluff";
        }
    }
    public class SeriesName : ProductAttributes
    {
        public SeriesName()
            : base()
        {
            Param = "SeriesName";
        }
    }
    public class DirectShip : ProductAttributes
    {
        public DirectShip()
            : base()
        {
            Param = "DirectShip";
        }
    }    
    public class ManufacturingWarrantyDays : ProductAttributes
    {
        public ManufacturingWarrantyDays()
            : base()
        {
            Param = "ManufacturingWarrantyDays";
        }
    }    
    public class SeriesFeatures : ProductAttributes
    {
        public SeriesFeatures()
            : base()
        {
            Param = "SeriesFeatures";
        }
    }
   
    public class SeriesNumber : ProductAttributes
    {
        public SeriesNumber()
            : base()
        {
            Param = "SeriesNumber";
        }
    }
    public class Cartonheight : ProductAttributes
    {
        public Cartonheight()
            : base()
        {
            Param = "Cartonheight(inches)";
        }
    }
    public class Cartonwidth : ProductAttributes
    {
        public Cartonwidth()
            : base()
        {
            Param = "Cartonwidth(inches)";
        }
    }
    public class Cartondepth : ProductAttributes
    {
        public Cartondepth()
            : base()
        {
            Param = "Cartondepth(inches)";
        }
    }
    public class ProductWidth : ProductAttributes
    {
        public ProductWidth()
            : base()
        {
            Param = "ProductWidth(inches)";
        }
    }
    public class ProductHeight : ProductAttributes
    {
        public ProductHeight()
            : base()
        {
            Param = "ProductHeight(inches)";
        }
    }
    public class Quantityperbox : ProductAttributes
    {
        public Quantityperbox()
            : base()
        {
            Param = "Quantityperbox";
        }
    }
    public class BestSelling : ProductAttributes
    {
        public BestSelling()
            : base()
        {
            Param = "BestSelling";
        }
    }
    public class Showroom : ProductAttributes
    {
        public Showroom()
            : base()
        {
            Param = "Showroom";
        }
    }
    public class ColorId : ProductAttributes
    {
        public ColorId()
            : base()
        {
            Param = "ColorId";
        }
    }
    public class ProductName : ProductAttributes
    {
        public ProductName()
            : base()
        {
            Param = "ProductName";
        }
    }
    public class Brand : ProductAttributes
    {
        public Brand()
            : base()
        {
            Param = "Brand";
        }
    }
    public class DisplayRank : ProductAttributes
    {
        public DisplayRank()
            : base()
        {
            Param = "DisplayRank";
            Type = SearchReturnType.Int;
        }
    }
    public class ItemStatusActivationDate : ProductAttributes
    {
        public ItemStatusActivationDate()
            : base()
        {
            Param = "ItemStatusActivationDate";
            Type = SearchReturnType.DateTime;
        }
    }
    public class ItemStatus : ProductAttributes
    {
        public ItemStatus()
            : base()
        {
            Param = "ItemStatus";

        }
    }
    public class SwatchGroupIdPa : ProductAttributes
    {
        public SwatchGroupIdPa()
            : base()
        {
            Param = Constants.SWATCH_FIELD_NAME;
        }
    }
    public class DefaultProduct : ProductAttributes
    {
        public DefaultProduct()
            : base()
        {
            Param = "DefaultProduct";

        }
    }

    public enum SearchReturnType
    {
        Default=0,
        Int,
        DateTime,
        
    }
}
