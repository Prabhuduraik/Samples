﻿using Sitecore.ContentSearch;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Data.Search
{
    public class Facets : Sitecore.ContentSearch.ComputedFields.IComputedIndexField
    {
        public string FieldName { get; set; }

        public string ReturnType { get; set; }

        public object ComputeFieldValue(Sitecore.ContentSearch.IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            List<string> dic = new List<string>();
            if (item != null && item.TemplateID.Equals(Sitecore.Data.ID.Parse("{944D9A1D-C88E-484A-92DF-F674BA9B4611}")))
            {
                Sitecore.Data.Fields.MultilistField mf = item.Fields[Sitecore.Data.ID.Parse("{891039C9-FE24-46B6-A5DE-BA958A6925CF}")];
                if (mf != null && mf.Count > 0)
                {
                    var classes = mf.GetItems();

                    foreach (var p in classes)
                    {
                        Sitecore.Data.Fields.MultilistField facetField = p.Fields[Sitecore.Data.ID.Parse("{49F0CDB7-F5E8-40FF-9131-BC24B94A06E6}")];
                        if (facetField != null && facetField.Count > 0)
                        {
                            foreach (var i in facetField.GetItems())
                            {
                                if (i.TemplateName == "Price Facet") { dic.Add(i["Facet Name"]); }
                                else { dic.Add(i["Facet Name"] + ":" + i["Target Product Attribute"]); }
                            }
                        }
                    }
                }
            }
            return dic.ToArray();
        }
    }
}
