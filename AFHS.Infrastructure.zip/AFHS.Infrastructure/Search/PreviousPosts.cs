﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    public class PreviousPosts : IComputedIndexField
    {
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            var dimension = new List<string>();

            if (item != null)
            {
                DateField dateField=null;
                
                if(item.TemplateID.Equals(ID.Parse("{58FBCAC1-2D09-467A-B4CB-9BD5F12D82C7}"))
                    || item.Template.BaseTemplates.Where(x => x.ID == ID.Parse("{58FBCAC1-2D09-467A-B4CB-9BD5F12D82C7}")).FirstOrDefault() != null)
                {
                    dateField = item.Fields["Date"];
                }
                else if (item.TemplateID.Equals(ID.Parse("{5C63BDCB-2AC7-44A5-BA8D-2B9F425FEB6A}")))
                {
                    dateField = item.Fields["PublishDate"];
                }
                else
                {
                    return dimension;
                }

                if (dateField != null && !string.IsNullOrEmpty(dateField.Value))
                {
                    if (DateTime.Now.AddMonths(-3).Date.CompareTo(dateField.DateTime) < 0) 
                    {
                        dimension.Add("Past 3 Months");
                    }
                    if (DateTime.Now.AddMonths(-6).Date.CompareTo(dateField.DateTime) < 0) 
                    {
                        dimension.Add("Past 6 Months");
                    }
                    if (DateTime.Now.AddMonths(-9).Date.CompareTo(dateField.DateTime) < 0)
                    {
                        dimension.Add("Past 9 Months");
                    }
                }
            }

            return dimension;
        }

        public string FieldName { get;set; }

        public string ReturnType { get; set; }

    }
}
