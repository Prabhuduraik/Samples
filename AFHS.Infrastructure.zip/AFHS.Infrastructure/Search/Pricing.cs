﻿using Afhs.Data.CustomClasses;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Afhs.Data.Models.sitecore.templates.User_Defined.Custom_Facets;
using Afhs.Infrastructure.Cache;
using Afhs.Infrastructure.Helpers;
using AFM.Commerce.Entities;
using AFM.Commerce.Services;
using Glass.Mapper.Sc;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    public abstract class Pricing : IComputedIndexField
    {
        const string EXTENDED_PRODUCT_TEMPLATE_ID = "{944D9A1D-C88E-484A-92DF-F674BA9B4611}";
        const string EXTERNAL_ID = "{F2F908F1-806E-4706-911B-6794B73576D0}";
        protected string PriceFacetID { get; set; }

        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;          
            int range=-1;

            if (item != null && item.TemplateID.Equals(ID.Parse(EXTENDED_PRODUCT_TEMPLATE_ID)) && !string.IsNullOrWhiteSpace(PriceFacetID))
            {
                if (!item["IsECommOwned"].Equals("1"))
                    return null;

                PriceFacet facet = item.Database.GetItem(new ID(PriceFacetID)).GlassCast<PriceFacet>();

                if (facet.Breakpoint1 > 0 && facet.Breakpoint2 > facet.Breakpoint1 && facet.Breakpoint3 > facet.Breakpoint2 && facet.Breakpoint4 > facet.Breakpoint3 && facet.Breakpoint5 > facet.Breakpoint4 && facet.Breakpoint6 > facet.Breakpoint5)
                {

                    var externalId = item[EXTERNAL_ID];
                    //var bestPrice = PricingHelper.GetBestPrice(externalId);
                    var price = PricingHelper.GetProductWithPrice(externalId).LowestPrice;

                    if (price <= 0)
                        return null;

                    if (price < facet.Breakpoint1)
                    {
                        range = 1;
                    }
                    else if (price <facet.Breakpoint2)
                    {
                        range = 2;
                    }
                    else if (price < facet.Breakpoint3)
                    {
                        range = 3;
                    }
                    else if (price < facet.Breakpoint4)
                    {
                        range = 4;
                    }
                    else if (price < facet.Breakpoint5)
                    {
                        range = 5;
                    }
                    else if (price < facet.Breakpoint6)
                    {
                        range = 6;
                    }
                    else
                    {
                        range = 7;
                    }
                }
            }

            if (range != -1)
                return range;
            return null;
        }

        public string FieldName { get; set; }

        public string ReturnType { get; set; }        
    }

    public class PriceRange01 : Pricing 
    {
        public PriceRange01()
            : base() 
        {
            PriceFacetID = Constants.FACET_PRICE_01;
        }
    }
    public class PriceRange02 : Pricing 
    {
        public PriceRange02()
            : base() 
        {
            PriceFacetID = Constants.FACET_PRICE_02;
        }
    }
    public class PriceRange03 : Pricing
    {
        public PriceRange03()
            : base()
        {
            PriceFacetID = Constants.FACET_PRICE_03;
        }
    }
    public class PriceRange04 : Pricing
    {
        public PriceRange04()
            : base()
        {
            PriceFacetID = Constants.FACET_PRICE_04;
        }
    }
    public class PriceRange05 : Pricing
    {
        public PriceRange05()
            : base()
        {
            PriceFacetID = Constants.FACET_PRICE_05;
        }
    }
    public class PriceRange06 : Pricing 
    {
        public PriceRange06()
            : base() 
        {
            PriceFacetID = Constants.FACET_PRICE_06;
        }
    }
    public class PriceRange07 : Pricing
    {
        public PriceRange07()
            : base()
        {
            PriceFacetID = Constants.FACET_PRICE_07;
        }
    }
    public class PriceRange08 : Pricing
    {
        public PriceRange08()
            : base()
        {
            PriceFacetID = Constants.FACET_PRICE_08;
        }
    }
    public class PriceRange09 : Pricing
    {
        public PriceRange09()
            : base()
        {
            PriceFacetID = Constants.FACET_PRICE_09;
        }
    }
    public class PriceRange10 : Pricing 
    {
        public PriceRange10()
            : base() 
        {
            PriceFacetID = Constants.FACET_PRICE_10;
        }
    }
}
