﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    class IsVideo : IComputedIndexField
    {
        const string YOUTUBE_THUMBNAIL_ITEM_TEMPLATE_ID = "{58FBCAC1-2D09-467A-B4CB-9BD5F12D82C7}";
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            if (item != null
                && (item.TemplateID.Equals(ID.Parse(YOUTUBE_THUMBNAIL_ITEM_TEMPLATE_ID))
                    || item.Template.BaseTemplates.Where(x=>x.ID.Equals(ID.Parse(YOUTUBE_THUMBNAIL_ITEM_TEMPLATE_ID))).FirstOrDefault()!=null)
                && !string.IsNullOrWhiteSpace(item["VideoID"]) && item.Name != "__Standard Values")
            {
                return true;
            }
            
            return null;
        }

        public string FieldName
        {
            get;
            set;
        }

        public string ReturnType
        {
            get;
            set;
        }
    }
}
