﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Search
{
    public class Classes : IComputedIndexField
    {
        public string FieldName { get; set; }

        public string ReturnType { get; set; }

        public object ComputeFieldValue(IIndexable indexable)
        {
            List<string> retval=new List<string>();
            Item item = indexable as SitecoreIndexableItem;

            if (item != null && item.TemplateID.Equals(ID.Parse("{944D9A1D-C88E-484A-92DF-F674BA9B4611}")))
            {
                MultilistField lf = item.Fields[ID.Parse("{891039C9-FE24-46B6-A5DE-BA958A6925CF}")];

                if (lf != null && lf.Count > 0)
                {
                    retval= lf.GetItems().Select(i => i.Name).ToList();
                }
            }
            return retval;
        }
    }
}
