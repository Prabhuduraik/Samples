﻿using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Links;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.UrlWriter
{
    public class CustomLinkProvider : LinkProvider
    {
        public override string GetItemUrl(Item item, UrlOptions options)
        {
            //Todo: Make this work.
            if (item == null)
                return string.Empty;

            string baseUrl = String.Empty;

            if (options.AlwaysIncludeServerUrl == true 
                && HttpContext.Current != null 
                && HttpContext.Current.Request != null 
                && HttpContext.Current.Request.Url != null 
                && HttpContext.Current.Request.Url.Host != null)
            {
                baseUrl = "//{0}";
                baseUrl = String.Format(baseUrl, HttpContext.Current.Request.Url.Host);
            }

            if (item.TemplateID == new ID("DE2E1240-3B27-42AC-806F-6D1F16E6D656"))
            {
                //The item content path is like "/ProductRepository/Product Classifications/Ashley Classifications/all/bedding"
                var url = String.Empty;
                string categorypath = item.Paths.ContentPath.ToLowerInvariant();
                if (categorypath.Contains("/all"))
                {
                    //The URL will look like "/all/category-name/category-name"
                    url = categorypath.Substring(categorypath.IndexOf("/all")).ToLower();

                    //Finally, the URL will be "/categories/bedding"
                    url = url.Replace("/all", "/c");
                    url += "/";
                }
                else
                {
                    throw new Exception("The category item path does not appear to follow the standard product repository pattern.");
                }

                if (options.AlwaysIncludeServerUrl == true)
                {
                    url = baseUrl + url;
                }

                return url;
            }
            else if (item.TemplateID == new ID("944D9A1D-C88E-484A-92DF-F674BA9B4611"))
            {

                StringBuilder url = new StringBuilder();
                if (options.AlwaysIncludeServerUrl == true)
                {
                    url.Append(baseUrl);
                }

                url.Append("/p/");
                url.Append(item.Name);
                url.Append("/");
                url.Append(item["ExternalID"]);
                url.Append("/");

                return url.ToString().ToLower();
            }
            else if (item.TemplateID == new ID("AB86861A-6030-46C5-B394-E8F99E8B87DB"))
            {
                string url = "/furniture-stores/" + item.Name;

                if (options.AlwaysIncludeServerUrl == true)
                {
                    url = baseUrl + url;
                }

                return url;
            }

            return base.GetItemUrl(item, options);
        }
    }
}
