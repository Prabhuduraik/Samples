﻿using Sitecore.Data.Items;
using Sitecore.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Sitecore.UrlWriter
{
    public class ItemNameFriendlyURLHandler
    {
        /// <summary>
        /// This class sets a content item's name field to all lower case characters and replaces the space character with a dash. This makes
        /// the URL changes an edit-time activity rather than a run-time activity.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        protected void HandleItemName(object sender, EventArgs args)
        {
            var item = (Item)Event.ExtractParameter(args, 0);
            string processedName;

            if (item.Database.Name != "master"
                || !item.Paths.Path.StartsWith("/sitecore/content/Home/")
                || item.Name == (processedName = item.Name.ToLower().Replace(' ', '-')))
            {
                return;
            }

            item.Editing.BeginEdit();
            try
            {
                item.Appearance.DisplayName = item.Name;
                item.Name = processedName;
            }
            finally
            {
                item.Editing.EndEdit();
            }
        }
    }
}
