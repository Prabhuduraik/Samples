﻿using System.Linq;
using Afhs.Infrastructure.Helpers;
using Afhs.Infrastructure.Sitecore.Cache;
using Sitecore;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Data;
using Sitecore.Pipelines.HttpRequest;

namespace Afhs.Infrastructure.UrlWriter
{
    public class CustomItemResolver : HttpRequestProcessor
    {
        public override void Process(HttpRequestArgs args)
        {
            if (Context.Item == null)
            {
                var requestUrl = args.Url.ItemPath.TrimEnd('/');

                /*  Todo: Move these hard-coded URL rewrite keys (ie products, categories, furniture-stores) into configuration.
                 *        Specify the index and field name for the searches. Iterate through these rules in this class. 
                 * 
                 *  Something like this, when this is finalized:
                 *      <config>
                 *          <rewrites>
                 *              <r1 key="/products/" index="commerce_products_master_index" field="ProductID" /> 
                 *              <r2 key="/categories/" index="commerce_products_master_index" field="externalId" />
                 *          </rewrites>
                 *      </config>
                 *      
                 *  Move the index names into configuration
                 */

                if (requestUrl.Contains("/p/"))
                {
                    //Locate the correct Product item in the Product Repository using the URL in this pattern:
                    //          afhs.com/products/some-product-name/product-id
                    //          Use the product ID to do the lookup

                    var identifier = requestUrl.Substring(requestUrl.LastIndexOf('/') + 1).ToLower();

                    var cache = UrlCacheManager.GetCache(identifier);
                    ID productId;
                    if (cache != null && ID.TryParse(cache, out productId))
                    {
                        Context.Item = args.GetItem(productId);
                    }
                    else
                    {
                        using (var searchContext = ContentSearchManager.GetIndex(SearchManager.GetProductsIndex()).CreateSearchContext())
                        {
                            var result = searchContext.GetQueryable<SearchResultItem>().FirstOrDefault(x => x["externalid"] == identifier);
                            if (result != null)
                            {
                                UrlCacheManager.SetCache(identifier, result.ItemId.ToString());
                                Context.Item = args.GetItem(result.ItemId);
                            }
                        }
                    }
                }
                else if (requestUrl.Contains("/c/"))
                {
                    //Locate the correct Category item in the Product Repository Classifications.
                    //      URL pattern: afhs.com/categories/top-level-category/second-level-category/target-category

                    //The identifier will be a string like this "/top-level-category/next-level-category"
                    var identifier = requestUrl.Substring(requestUrl.IndexOf("/c/") + 3);

                    //This changes the identifier to the full Sitecore item path
                    //Todo: move this string into configuration
                    identifier = "/sitecore/content/ProductRepository/Product Classifications/Ashley Classifications/all/" + identifier;

                    Context.Item = args.GetItem(identifier);
                }
                else if (requestUrl.EndsWith("/c"))
                {
                    const string identifier = "/sitecore/content/ProductRepository/Product Classifications/Ashley Classifications/all";
                    Context.Item = args.GetItem(identifier);
                }
            }
        }
    }
}
