﻿using System.Collections.Generic;
using System.Configuration;
using System.Web.Security;
using Afhs.Data.Models.sitecore.templates.User_Defined.Mailings;
using Glass.Mapper.Sc;
using Sitecore.Data;
using Sitecore.Modules.EmailCampaign;
using Sitecore.Shell.Applications.Security.SetPassword;
using Sitecore.Web;
using SC = Sitecore;

namespace Afhs.Infrastructure.Sitecore.Security
{
    public class SetPassword : SetPasswordPage
    {
        protected new void Generate_Click()
        {
            base.Generate_Click();
            var user = Membership.GetUser(WebUtil.GetQueryString("us"));
            var tokens = new Dictionary<string, object> { { "html", EmailManager.GetResetHtml() } };
            var config = EmailManager.GetEmailConfiguration();
            if (user != null)
                EmailManager.SendEmailToUser(new ID(config.PasswordResetEmail), tokens, user.UserName, "Your HomeStore Password Has Been Changed");
        }
    }

    class EmailManager
    {
        public static void SendEmailToUser(ID messageID, Dictionary<string, object> tokens, string username, string subject)
        {
            var message = Factory.GetMessage(messageID);
            message.CustomPersonTokens = tokens;
            Contact contact = Contact.FromName(username);
            message.Subject = subject;
            if (contact != null)
            {
                new SendingManager(message).SendStandardMessage(contact);
            }
        }

        public static string GetResetHtml()
        {
            string html = null;
            html += "<h1 style=\"text-transform:uppercase;color:#666666;font-family:Arial;font-weight:normal;text-align:left;line-height:1.3;font-size:1.375em;font-style:normal;margin-top:10px;margin-bottom:5px;padding:0;\" align=\"left\">";
            html += "YOUR PASSWORD <em style=\"color:#f48120 ;font-style:normal;\"> HAS BEEN RESET</em></h1>";

            html += "<p>Thank you for visiting ";
            html += "<a style=\"color: #2ba6cb; text-decoration: none;\" href=\"" + ConfigurationManager.AppSettings[Constants.CURRENT_HOST_URL] + "\">ashleyfurniturehomestore.com</a>. We have successfully changed your password</p>";
            html += "<BR/>";
            html += "<p>If you did not make this request, please call Customer Service at</p><p> 1-866-436-3393</p>";
            html += "<BR/>";
            html += "<p>Thank You,</p>";
            html += "<p>Ashley Furniture Customer Service</p>";
            html += "<p><a style=\"color: #2ba6cb; text-decoration: none;\" href=\"" + ConfigurationManager.AppSettings[Constants.CURRENT_HOST_URL] + "\">" + ConfigurationManager.AppSettings[Constants.CURRENT_HOST_URL] + "</a></p>";
            return html;
        }

        public static MailingConfiguration GetEmailConfiguration()
        {
            return new SitecoreService("master").GetItem<MailingConfiguration>("/sitecore/content/Repository/Mailing/Configuration");
        }
    }
}
