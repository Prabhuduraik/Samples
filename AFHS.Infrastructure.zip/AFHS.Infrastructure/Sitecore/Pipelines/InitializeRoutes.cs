﻿using Afhs.Infrastructure.Sitecore.Formatters;
using Microsoft.Data.Edm;
using Newtonsoft.Json.Serialization;
using Sitecore.Diagnostics;
using Sitecore.Pipelines;
using System.Web.Http;
using System.Web.Http.OData.Builder;
using System.Web.Routing;

namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    public class InitializeRoutes
    {
        public void Process(PipelineArgs args)
        {
            Log.Info("Initializing WebApi Pipeline", this);

            ODataModelBuilder modelBuilder = new ODataConventionModelBuilder();
            //modelBuilder.EntitySet<AshleyPoc.Data.Model.ProductSearchResult>("Products");
            //modelBuilder.EntitySet<AshleyPoc.Data.Model.Facet>("Facets");
            IEdmModel model = modelBuilder.GetEdmModel();
            GlobalConfiguration.Configuration.Routes.MapODataRoute("ODataRoute", "odata", model);
            GlobalConfiguration.Configuration.MapHttpAttributeRoutes();
            RouteTable.Routes.MapHttpRoute(
                name: "DefaultActionApi",
                routeTemplate: "api/{controller}/{action}/{id}",
                defaults: new { action = RouteParameter.Optional, id = RouteParameter.Optional }
                );
            RouteTable.Routes.MapHttpRoute(
                name: "ProductSearchApi",
                routeTemplate: "api/{controller}/{action}/{searchString}",
                defaults: new { searchStringid = RouteParameter.Optional }
                );
            RouteTable.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
            GlobalConfiguration.Configuration.Formatters.Insert(0, new TextMediaTypeFormatter());
            var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            json.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            GlobalConfiguration.Configuration.EnsureInitialized();
            Log.Info("Finished WebApi Pipeline", this);
        }
    }
}
