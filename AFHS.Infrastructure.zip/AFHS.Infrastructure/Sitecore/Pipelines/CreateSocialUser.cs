﻿using sc=Sitecore;
using Sitecore.Diagnostics;
using Sitecore.Events;
using Sitecore.Security.Accounts;
using Sitecore.SecurityModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Security;
using Sitecore.Social.BusinessLogic.Connector.Pipelines.MatchUser;
using System.Text.RegularExpressions;


namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    class CreateSocialUser
    {
        // Methods
        private User CreateSitecoreUser(string domainUser, string email, string fullName)
        {
            MembershipUser user = Membership.CreateUser(domainUser, this.GenerateRandomPassword(), email);
            user.IsApproved = true;
            Membership.UpdateUser(user);
            User user2 = User.FromName(user.UserName, false);
            try
            {
                string str;
                using (new SecurityDisabler())
                {
                    str = sc.Client.CoreDatabase.GetItem("/sitecore/system/Settings/Security/Profiles/User").ID.ToString();
                }
                user2.Profile.Initialize(user2.Name, true);
                user2.Profile.ProfileItemId = str;
                user2.Profile.FullName = fullName;
                user2.Profile.Email = email;
                user2.Profile.Save();
            }
            catch (Exception exception)
            {
                Log.Error(exception.Message, exception, this);
            }
            Event.RaiseEvent("social:connector:user:created", new object[] { user2 });
            return user2;
        }

        private string GenerateRandomPassword()
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random(DateTime.Now.Millisecond);
            int lenght = 10;
            if (Membership.MinRequiredPasswordLength > 0)
                lenght = Membership.MinRequiredPasswordLength;
            for (int i = 0; i < lenght * 2; i++)
            {
                char ch = Convert.ToChar(Convert.ToInt32(Math.Floor((double)((26.0 * random.NextDouble()) + 65.0))));
                builder.Append(ch);
            }
            if (Membership.MinRequiredNonAlphanumericCharacters > 0)
            {
                while (GetSpecialCharsAmount(builder) < Membership.MinRequiredNonAlphanumericCharacters)
                {
                    char ch = Convert.ToChar(Convert.ToInt32(random.Next()%256));
                    if (!Char.IsLetterOrDigit(ch))
                        builder.Insert((random.Next()%builder.Length), ch); 
                }
            }
            string pass = builder.ToString();
            return pass;
        }

        public void Process(SelectUserPipelineArgs args)
        {
            Assert.IsNotNull(args, "The pipeline args is null");
            Assert.IsNotNull(args.Username, "The Username property in pipeline args must be filled");
            Assert.IsNotNull(args.Email, "The Email property in pipeline args must be filled");
            if (args.Result == null)
            {
                string fullName = sc.Context.Domain.GetFullName(args.Username);
                args.Result = this.CreateSitecoreUser(fullName, args.Email, args.AccountBasicData.FullName);
            }
        }

        private int GetSpecialCharsAmount(StringBuilder source)
        {
            string pattern = "[a-zA-Z0-9]";
            string result = Regex.Replace(source.ToString(), pattern, "");
            return result.Length;
        }
    }
}
