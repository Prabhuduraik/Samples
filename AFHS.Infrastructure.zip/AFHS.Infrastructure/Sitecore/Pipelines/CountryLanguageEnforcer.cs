﻿using sc = Sitecore;
using Sitecore.Pipelines.HttpRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.Web;
using System;
using Sitecore.Sites;
using Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core;
using System.Web.UI;




namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    public class CountryLanguageEnforcer : HttpRequestProcessor
    {
        public override void Process(HttpRequestArgs args)
        {

            if (sc.Context.Site == null || sc.Context.Language == null)
            {
                return;
            }

            if (!sc.Context.PageMode.IsNormal)
            {
                return;
            }

            var enabledLanguages = sc.Context.Site.GetEnabledLanguages();
            if (enabledLanguages.Length == 0)
            {
                return;
            }

            if (!enabledLanguages.Contains(sc.Context.Language.Name))
            {
                Page p = new Page();
                 var errorPagePath = sc.Context.Data.Site.StartPath + "/errors";

                //don’t process URL. could also directly force 404 here
              //  args.AbortPipeline();
                //string requestedUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace("/" + sc.Context.Language.Name, "/");
                //WebUtil.Redirect(requestedUrl, false);

                if (errorPagePath.Equals(Constants.GetContentPath("CUSTOM_ERRORS_FOLDER")))
                {
                    int code;

                    p.Response.TrySkipIisCustomErrors = true;
                    p.Response.StatusCode = int.TryParse(sc.Context.Item.Name, out code) ? code : 500;
                }
               

            }

           
        }
    }


    public static class SiteExtensions
    {
        private const string _enabledLanguagesAttributeName = "enabledLanguages";

        public static string[] GetEnabledLanguages(this SiteContext siteContext)
        {
            if (siteContext == null ||
            string.IsNullOrEmpty(siteContext.Properties[_enabledLanguagesAttributeName]))
            {
                return new string[0];
            }
            return siteContext.Properties[_enabledLanguagesAttributeName].Split('|');
        }
    }
}
