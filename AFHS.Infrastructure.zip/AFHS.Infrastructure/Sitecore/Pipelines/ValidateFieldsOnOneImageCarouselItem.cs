﻿using Sitecore.Pipelines.Save;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.Diagnostics;
using sc = Sitecore;
using Sitecore.Links;
using Glass.Mapper.Sc;
using Sitecore.Configuration;

namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    public class ValidateFieldsOnOneImageCarouselItem
    {
        sc.Data.ID OneImageCarouselTemplateID = new sc.Data.ID("{870722BB-6554-4976-931B-816393F7840C}");

        public void Process(SaveArgs args)
        {
            sc.Diagnostics.Assert.ArgumentNotNull(args, "args");
            if (args.Items == null)
                return;
            sc.Pipelines.Save.SaveArgs.SaveItem[] itemSave = args.Items;
            string message = string.Empty;
            var database = Factory.GetDatabase("master");

            foreach (sc.Pipelines.Save.SaveArgs.SaveItem item in itemSave)
            {
                sc.Data.Items.Item itemSaved = sc.Client.ContentDatabase.GetItem(item.ID);

                if (itemSaved == null) //new item not saved before
                    continue;

                if (itemSaved.TemplateID.Equals(OneImageCarouselTemplateID))
                {
                    string conditionalFieldValue = string.Empty;
                    string requiredLinkFieldURL = null;

                    foreach (sc.Pipelines.Save.SaveArgs.SaveField field in item.Fields)
                    {
                        if (field.ID.Equals(itemSaved.Fields["ButtonTitle"].ID))
                        {
                            conditionalFieldValue = field.Value;
                        }
                        else if (field.ID.Equals(itemSaved.Fields["ButtonLink"].ID))
                        {
                            var testField = new sc.Data.Fields.Field(field.ID, itemSaved);
                                itemSaved.Editing.BeginEdit();
                                testField.SetValue(field.Value, false);
                                
                            requiredLinkFieldURL = new sc.Data.Fields.LinkField(testField).GetFriendlyUrl();

                            itemSaved.Editing.CancelEdit();
                        }
                    }
                    if (!string.IsNullOrEmpty(conditionalFieldValue) && string.IsNullOrEmpty(requiredLinkFieldURL))
                    {
                        message += string.Format(sc.Globalization.Translate.Text(
                            "As you completed the \"ButtonTitle\" field, \"ButtonLink\" must contain a value."
                            + Environment.NewLine));
                        sc.Web.UI.Sheer.SheerResponse.Alert(message, new string[0]);
                        args.SaveAnimation = false;
                        args.AbortPipeline();
                        return;
                    }
                }
            }
        }
    }
}
