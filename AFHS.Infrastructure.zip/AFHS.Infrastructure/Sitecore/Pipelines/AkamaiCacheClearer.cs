﻿using Afhs.Infrastructure.Helpers;
using Sitecore;
using Sitecore.Data;
using Sitecore.Data.Engines;
using Sitecore.Data.Managers;
using Sitecore.Diagnostics;
using Sitecore.Publishing.Pipelines.Publish;
using Sitecore.Resources.Media;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    class AkamaiCacheClearer : PublishProcessor
    {
        private readonly List<ID> _cacheQueue = new List<ID>();
        private string _akamaiAshleyRootWebsite = ConfigurationManager.AppSettings[Constants.WEBCONFIG_AKAMAI_ASHLEY_ENV_URL];

        public override void Process(PublishContext context)
        {
            Assert.ArgumentNotNull(context, "context");
            Log.Info("Start publish time", this);
            ProcessPublishedItems(context);
            Log.Info("End publish time", this);
        }

        protected virtual void ProcessPublishedItems(PublishContext context)
        {
            if (context == null || context.PublishOptions == null || context.PublishOptions.TargetDatabase == null)
            {
                Log.Error("Context and/or publish settings are null", this);
                return;
            }

            ProcessHistoryStorage(context.PublishOptions.TargetDatabase); //this updates the housekeeping fields
            var mediaRelativeUrls = (from id in _cacheQueue where context.PublishOptions.TargetDatabase.Items.GetItem(id) != null select context.PublishOptions.TargetDatabase.Items[id] into item where item.Paths.IsMediaItem select MediaManager.GetMediaUrl(item)).ToList();

            if(mediaRelativeUrls.Count>0)
            {
                var debugMessage = new StringBuilder();                
                var absoluteUrls = new List<string>();

                debugMessage.AppendLine("Akamai Cache Clearer Media Urls");  

                //must prepend environment specific url from web.config for Akamai request
                //as the path is sent to akamai it must be the absolute path
                foreach (var url in mediaRelativeUrls)
                {
                    var absolutePath = String.Format("{0}{1}", _akamaiAshleyRootWebsite, url);
                    absoluteUrls.Add(absolutePath);
                    debugMessage.AppendFormat("{0}", absolutePath);
                    debugMessage.AppendLine();
                }                                                                       
                Log.Debug(debugMessage.ToString());

       AkamaiCacheClearerManager.RefreshMediaUrls(absoluteUrls);
            }
                
        }

        private void ProcessHistoryStorage(Database database)
        {
            _cacheQueue.Clear();
            var utcNow = DateTime.UtcNow;
            var from = LastUpdateTime(database);
            Log.Debug("Last Update Time: " + from);
            Log.Debug("Database: " + database.Name);
            var entrys = HistoryManager.GetHistory(database, from, utcNow.ToUniversalTime());
            Log.Debug("entry count: " + entrys.Count);

            if (entrys.Count > 0)
            {
                foreach (var entry in
                    entrys.Where(entry => !_cacheQueue.Contains(entry.ItemId) && entry.Category == HistoryCategory.Item))
                {
                    _cacheQueue.Add(entry.ItemId);
                    database.Properties["LastUpdate"] = DateUtil.ToIsoDate(entry.Created, true);
                }
            }

            database.Properties["LastUpdate"] = DateUtil.ToIsoDate(utcNow, true);
        }

        protected DateTime LastUpdateTime(Database database)
        {
            var lastUpdate = database.Properties["LastUpdate"];

            if (lastUpdate.Length > 0)
            {
                return DateUtil.ParseDateTime(lastUpdate, DateTime.MinValue);
            }

            return DateTime.MinValue;
        }
    }
}
