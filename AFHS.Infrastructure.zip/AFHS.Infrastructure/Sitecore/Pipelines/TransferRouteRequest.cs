﻿using System.Web;
using System.Web.Routing;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.HttpRequest;

namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    public class TransferRouteRequest : HttpRequestProcessor
    {
        public override void Process(HttpRequestArgs args)
        {
            Assert.ArgumentNotNull(args, "args");
            var httpContext = new HttpContextWrapper(HttpContext.Current);
            var routeData = RouteTable.Routes.GetRouteData(httpContext);
            if (routeData != null)
            {
                var dictionary = (routeData.Route as Route).Defaults;
                if ((dictionary == null) || !dictionary.ContainsKey("scIsFallThrough"))
                {
                    args.AbortPipeline();
                }
            }
        }
    }
}
