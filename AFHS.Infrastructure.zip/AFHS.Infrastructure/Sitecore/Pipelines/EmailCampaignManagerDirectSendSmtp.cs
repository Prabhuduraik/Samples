﻿using System;
using System.Net.Mail;
using Sitecore.Diagnostics;
using Sitecore.Modules.EmailCampaign.Core.Pipelines;
using Sitecore.Modules.EmailCampaign.Messages;
using Cfg = Sitecore.Configuration;

namespace Afhs.Infrastructure.Sitecore.Pipelines
{
    class EmailCampaignManagerDirectSendSmtp
    {
        public void Process(SendMessageArgs args)
        {
            Assert.ArgumentNotNull(args, "args");
            MailMessageItem message = args.EcmMessage as MailMessageItem;
            if (message != null)
            {
                if (!String.IsNullOrEmpty(message.Body))
                {
                    var mail = new MailMessage(message.FromAddress, message.To, message.Subject, message.Body)
                    {
                        IsBodyHtml = true
                    };
                    var server = Cfg.Settings.GetSetting("SMTP.Server");
                    var port = Cfg.Settings.GetSetting("SMTP.Port");

                    var client = new SmtpClient { Host = server, Port = int.Parse(port) };
                    using (client)
                    {
                        client.Send(mail);
                    }
                    args.AbortPipeline();
                }
            }
        }
    }
}
