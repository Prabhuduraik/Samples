﻿using Glass.Mapper.Sc;
using Sitecore.Data.Items;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Sitecore.Rules.Actions;
using Sitecore.Diagnostics;
using Afhs.Infrastructure.Sitecore.Rules.CustomConditions;

namespace Afhs.Infrastructure.Sitecore.Rules.CustomActions
{
    public class SetOverlayCookie<T> : RuleAction<T> where T : RuleContext
    {
        public string ConfigItemPath { get; set; }

        public override void Apply(T ruleContext)
        {
            if (String.IsNullOrEmpty(ConfigItemPath))
                return;
            SitecoreContext context = new SitecoreContext();
            Item configItem = context.GetItem<Item>(ConfigItemPath);
            if (configItem == null || configItem.TemplateName != Constants.TEMPLATE_EMAIL_WEBSITE_OVERLAY)
                return;

            if (string.IsNullOrEmpty(configItem["CookieName"]))
                return;

            AfhsOverlayCookie cookie = new AfhsOverlayCookie(HttpContext.Current.Request, HttpContext.Current.Response, configItem["CookieName"]);
            cookie.SetCookieAsToday(OverlayCookieStates.Empty, 0);
        }
    }
}
