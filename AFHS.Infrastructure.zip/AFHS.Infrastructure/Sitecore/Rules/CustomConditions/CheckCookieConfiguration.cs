﻿using Glass.Mapper.Sc;
using Sitecore.Data.Items;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Sitecore.Rules.CustomConditions
{
    public class CheckCookieConfiguration<T> : StringOperatorCondition<T> where T : RuleContext
    {
        public string ConfigItemPath { get; set; }

        protected override bool Execute(T ruleContext)
        {
            if (String.IsNullOrEmpty(ConfigItemPath))
                return false;

            SitecoreContext context = new SitecoreContext();
            Item configItem = context.GetItem<Item>(ConfigItemPath);
            if (configItem == null || configItem.TemplateName != Constants.TEMPLATE_EMAIL_WEBSITE_OVERLAY || string.IsNullOrEmpty(configItem["CookieName"]))
                return false;

            AfhsOverlayCookie cookie = new AfhsOverlayCookie(HttpContext.Current.Request, HttpContext.Current.Response, configItem["CookieName"]);
            if (cookie.Cookie == null)
                return true;

            if (cookie.ValueState == OverlayCookieStates.Closed)
                return ProcessClosedCookie(configItem, cookie);
            else if (cookie.ValueState == OverlayCookieStates.Rejected)
                return ProcessRejectedCookie(configItem, cookie);
            else if (cookie.ValueState == OverlayCookieStates.Ignored)
                return false;
            else if (cookie.ValueState == OverlayCookieStates.InvalidState)
                return true;
            return false;
        }

        private bool ProcessClosedCookie(Item configItem, AfhsOverlayCookie cookie) 
        {
            string date = cookie.Cookie.Value.Split('|')[1];
            DateTime closedDate;
            if (!DateTime.TryParse(date, out closedDate))
                return true;

            if (string.IsNullOrEmpty(configItem["DaysToWaitWhenClosed"]))
                return false;

            int daysToWait = Convert.ToInt32(configItem["DaysToWaitWhenClosed"]);
            if (((int)(DateTime.Now.Date - closedDate.Date).TotalDays) >= daysToWait)
                return true;
            else
                return false;
        }

        private bool ProcessRejectedCookie(Item configItem, AfhsOverlayCookie cookie)
        {
            string date = cookie.Cookie.Value.Split('|')[1];
            DateTime closedDate;
            if (!DateTime.TryParse(date, out closedDate))
                return true;

            if (string.IsNullOrEmpty(configItem["DaysToWaitWhenRejected"]))
                return false;
            int daysToWait = Convert.ToInt32(configItem["DaysToWaitWhenRejected"]);
            if (daysToWait < 0)
                return false;
            if (((int)(DateTime.Now.Date - closedDate.Date).TotalDays) >= daysToWait)
                return true;
            else
                return false;
        }
    }

    public class AfhsOverlayCookie
    {

        private HttpResponse Response;
        private HttpRequest Request;
        private string CookieName;
        public HttpCookie Cookie { get; set; }
        public OverlayCookieStates ValueState 
        {
            get 
            {
                if (Cookie == null || string.IsNullOrEmpty(Cookie.Value) || !Cookie.Value.Contains("|"))
                    return OverlayCookieStates.InvalidState;
                return AfhsOverlayCookie.GetStateFor(Cookie.Value.Split('|')[0]);
            }
        }
        public DateTime ValueDate
        {
            get 
            {
                if (Cookie == null || string.IsNullOrEmpty(Cookie.Value) || !Cookie.Value.Contains("|"))
                    return DateTime.MinValue;
                string value = Cookie.Value.Split('|')[1];
                DateTime date;
                if (!DateTime.TryParse(value, out date))
                    date = DateTime.MinValue;
                return date;
            }
        }


        #region "Methods"

        /// <summary>
        /// Builds the 'AfhsDateCookie' object by setting the 'Cookie'.
        /// </summary>
        /// <param name="request">The current 'HttpRequest' object</param>
        /// <param name="response">The current 'HttpResponse' object</param>
        /// <param name="cookieName">The name of the date cookie</param>
        public AfhsOverlayCookie(HttpRequest request, HttpResponse response, string cookieName)
        {
            Request = request;
            Response = response;
            CookieName = cookieName;
            //if (Request.Cookies.Get(CookieName) != null && Response.Cookies.Get(CookieName) != null)
            //{
            //    // Since cookie may be updated on request, the code checks that
            //    if ((Response.Cookies.Get(CookieName).Expires > Request.Cookies.Get(CookieName).Expires) && !string.IsNullOrEmpty(Response.Cookies.Get(CookieName).Value))
            //        Cookie = Response.Cookies.Get(CookieName);
            //    else
            //        Cookie = Request.Cookies.Get(CookieName);
            //}
            //else
            Cookie = Request.Cookies.Get(CookieName);
        }

        /// <summary>
        /// Set the cookie's value as the actual date.
        /// </summary>
        /// <param name="state">The state to be added on cookie's value</param>
        /// <param name="expirationDays">The amount of days to expire</param>
        public void SetCookieAsToday(OverlayCookieStates state, int expirationDays)
        {
            if (Cookie == null)
                Cookie = new HttpCookie(CookieName);

            if (expirationDays > 0)
                Cookie.Expires = DateTime.Now.Date.AddDays(expirationDays);

            string value = string.Format("{0}|{1}", state.ToString(), DateTime.Today.Date.ToString("MMM dd, yyyy"));
            Cookie.Value = value;
            if (Response.Cookies.Get(CookieName) != null)
                Response.Cookies.Set(Cookie);
            else
                Response.Cookies.Add(Cookie);
        }

        /// <summary>
        /// Set the cookie's value as the provided state and date
        /// </summary>
        /// <param name="state">The state to be added on cookie's value</param>
        /// <param name="date">The date to be added on cookie's value</param>
        /// <param name="expirationDays">The amount of days to expire</param>
        public void SetCookieAs(OverlayCookieStates state, DateTime date, int expirationDays)
        {
            if (Cookie == null)
                Cookie = new HttpCookie(CookieName);
            if (expirationDays > 0)
                Cookie.Expires = DateTime.Now.Date.AddDays(expirationDays);

            string value = string.Format("{0}|{1}", state.ToString(), date.Date.ToString("MMM dd, yyyy"));
            Cookie.Value = value;
            if (Response.Cookies.Get(CookieName) != null)
                Response.Cookies.Set(Cookie);
            else
                Response.Cookies.Add(Cookie);
        }

        public static bool IsValidState(string state)
        {
            return (AfhsOverlayCookie.GetStateFor(state) != OverlayCookieStates.InvalidState);
        }

        public static OverlayCookieStates GetStateFor(string state)
        {
            OverlayCookieStates result;
            if (!Enum.TryParse<OverlayCookieStates>(state, out result))
                result = OverlayCookieStates.InvalidState;
            return result;
        }

        #endregion

    }

    public enum OverlayCookieStates
    {
        InvalidState = 0,
        Empty = 1,
        Closed = 2,
        Rejected = 3,
        Completed = 4,
        Ignored = 5
    }
}
