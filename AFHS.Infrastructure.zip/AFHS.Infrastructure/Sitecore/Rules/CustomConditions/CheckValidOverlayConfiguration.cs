﻿using Glass.Mapper.Sc;
using Sitecore.Data.Items;
using Sitecore.Data.Templates;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Sitecore.Rules.CustomConditions
{
    class CheckValidOverlayConfiguration<T> : StringOperatorCondition<T> where T : RuleContext
    {
        public string ConfigItemPath { get; set; }

        protected override bool Execute(T ruleContext)
        {
            if (String.IsNullOrEmpty(ConfigItemPath))
                return false;

            SitecoreContext context = new SitecoreContext();
            Item configItem = context.GetItem<Item>(ConfigItemPath);
            if (configItem == null || configItem.TemplateName != Constants.TEMPLATE_EMAIL_WEBSITE_OVERLAY || string.IsNullOrEmpty(configItem["ShowOverlay"]))
                return false;

            Item currentItem = context.GetCurrentItem<Item>();
            if (currentItem == null)
                return false;
            return configItem["TemplatesWhereShowOverlay"].Contains(currentItem.TemplateID.ToString().ToUpper());
        }
    }
}
