﻿using Sitecore.Caching;

namespace Afhs.Infrastructure.Sitecore.Cache
{
    public class UrlCustomCache : CustomCache
    {
        public UrlCustomCache(string name, long maxSize)
            : base(name, maxSize)
        {

        }

        new public void SetString(string key, string value)
        {
            base.SetString(key, value);
        }

        new public string GetString(string key)
        {
            return base.GetString(key);
        }
    }
}