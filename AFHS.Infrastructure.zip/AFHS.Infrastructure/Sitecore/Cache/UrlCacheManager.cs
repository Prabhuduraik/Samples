﻿using Sitecore;

namespace Afhs.Infrastructure.Sitecore.Cache
{
    public static class UrlCacheManager
    {
        private static readonly UrlCustomCache Cache;

        static UrlCacheManager()
        {
            Cache = new UrlCustomCache("UrlCustomCache",
                     StringUtil.ParseSizeString("10MB"));
        }

        public static string GetCache(string key)
        {
            return Cache.GetString(key);
        }

        public static void SetCache(string key,string value)
        {
            Cache.SetString(key, value);
        }
    }
}