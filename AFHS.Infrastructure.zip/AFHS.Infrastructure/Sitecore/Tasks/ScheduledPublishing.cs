﻿using Sitecore;
using Sitecore.Configuration;
using Sitecore.Diagnostics;
using Sitecore.Diagnostics.PerformanceCounters;
using Sitecore.Globalization;
using Sitecore.Publishing;
using Sitecore.StringExtensions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Afhs.Infrastructure.Sitecore.Tasks
{
    public class ScheduledPublishing
    {
        private readonly List<Language> _languages;
        private readonly PublishMode _mode;
        private readonly string _sourceDatabase;
        private readonly string _targetDatabase;
        private bool _hasTaskExecuted;
        private readonly TimeSpan _publishingTime;
        public List<Language> Languages
        {
            get
            {
                return _languages;
            }
        }

        public PublishMode Mode
        {
            get
            {
                return _mode;
            }
        }

        public string SourceDatabase
        {
            get
            {
                return _sourceDatabase;
            }
        }

        public string TargetDatabase
        {
            get
            {
                return _targetDatabase;
            }
        }

        public TimeSpan PublishingTime
        {
            get { return _publishingTime; }
        }

        public bool HasTaskExecuted
        {
            get { return _hasTaskExecuted; }
            set { _hasTaskExecuted = value; }
        }

        // Methods
        public ScheduledPublishing(string sourceDatabase, string targetDatabase, string mode, string languages, string publishingTime)
        {
            Assert.ArgumentNotNullOrEmpty(sourceDatabase, "sourceDatabase");
            Assert.ArgumentNotNullOrEmpty(targetDatabase, "targetDatabase");
            Assert.ArgumentNotNullOrEmpty(mode, "mode");
            Assert.ArgumentNotNullOrEmpty(languages, "languages");
            Assert.ArgumentNotNullOrEmpty(publishingTime, "publishing time");
            HasTaskExecuted = false;
            _sourceDatabase = sourceDatabase;
            _targetDatabase = targetDatabase;
            _languages = ParseLanguages(languages);
            _mode = ParseMode(mode);
            _publishingTime = DateUtil.ParseTimeSpan(publishingTime, TimeSpan.MaxValue);
            Assert.IsTrue(_languages.Any(), "No languages specified in PublishAgent constructor.");
        }

        private static List<Language> ParseLanguages(string languages)
        {
            return (from str in languages.Split(new[] {','}, StringSplitOptions.RemoveEmptyEntries) where str.Any() select Language.Parse(str.Trim())).ToList();
        }

        private static PublishMode ParseMode(string mode)
        {
            if (mode.Equals("Full", StringComparison.InvariantCultureIgnoreCase))
                return PublishMode.Full;
            if (mode.Equals("Incremental", StringComparison.InvariantCultureIgnoreCase))
                return PublishMode.Incremental;
            if (mode.Equals("Smart", StringComparison.InvariantCultureIgnoreCase))
                return PublishMode.Smart;
            return PublishMode.Unknown;
        }

        public void Run()
        {
            if (IsPublishingTime())
            {
                foreach (var language in _languages)
                {
                    StartPublish(language);
                }
                HasTaskExecuted = true;
            }
        }

        private bool IsPublishingTime()
        {
            // this.HasTaskExecuted prevents publishing more than once.
            var isTime = !HasTaskExecuted;
            var timeDiff = DateTime.Now.TimeOfDay.Subtract(PublishingTime);
            // only return true if the time diff is less than 30 minutes
            if (isTime)
                isTime = timeDiff.Hours == 0 && timeDiff.Minutes >= 0 && timeDiff.Minutes <= 30;
            // reset the setting to false after 30 minutes
            else
            {
                HasTaskExecuted = timeDiff.Minutes < 30;
            }
            return isTime;
        }
        private void StartPublish(Language language)
        {
            Assert.ArgumentNotNull(language, "language");
            Log.Info("PublishAgent started (source: {0}, target: {1}, mode: {2})".FormatWith(new object[] { _sourceDatabase, _targetDatabase, _mode }), this);
            var database = Factory.GetDatabase(_sourceDatabase);
            var database2 = Factory.GetDatabase(_targetDatabase);
            Assert.IsNotNull(database, "Unknown database: {0}", new object[] { _sourceDatabase });
            Assert.IsNotNull(database2, "Unknown database: {0}", new object[] { _targetDatabase });

            var options = new PublishOptions(database, database2, Mode, language, DateTime.Now)
            {
                Deep = true
            };
            var publisher = new Publisher(options);
            var willBeQueued = publisher.WillBeQueued;
            publisher.PublishAsync();
            Log.Info("Asynchronous publishing {0}. Job name: {1}".FormatWith(new object[] { willBeQueued ? "queued" : "started", publisher.GetJobName() }), this);
            TaskCounters.Publishings.Increment();
        }
    }
}
