﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using Afhs.Infrastructure.Cache;
using Sitecore.Diagnostics;
using sc = Afhs.Data.Models.sitecore.templates.User_Defined;

namespace Afhs.Infrastructure.Sitecore.StoreSync
{
    public class WebServiceManager
    {
        public List<AfhsState> GetStates(string countryCode)
        {
            var stateList = new List<AfhsState>();
            try
            {
                XmlNode xmlNode =
                    new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetStates(countryCode);                
                var serializer = new XmlSerializer(typeof(AfhsState));
                const string header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

                foreach (XmlNode node in xmlNode.ChildNodes[0].ChildNodes[0].ChildNodes[0].ChildNodes)
                {
                    var xml = node.InnerXml;
                    xml = xml.Replace("xmlns=\"http://awsm.ashleyfurniture.com/AshleyStoreLocator/\"", "");
                    var reader = XmlReader.Create(new StringReader(header + "<State>" + xml + "</State>"));
                    var state = (AfhsState)serializer.Deserialize(reader);
                    if (!string.IsNullOrEmpty(state.StateCode) && !string.IsNullOrEmpty(state.StateName))
                        stateList.Add(state);
                    reader.Close();

                }
            }
            catch (Exception ex)
            {
                Log.Warn("Get States Error", ex);
            }

            return stateList;
        }

        public List<AfhsCountry> GetCountries()
        {
            var countryList = new List<AfhsCountry>();
            try
            {
                XmlNode xmlNode = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetCountries();                
                var serializer = new XmlSerializer(typeof(AfhsCountry));
                const string header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

                foreach (XmlNode node in xmlNode.ChildNodes[0].ChildNodes[0].ChildNodes[0].ChildNodes)
                {
                    var xml = node.InnerXml;
                    xml = xml.Replace("xmlns=\"http://awsm.ashleyfurniture.com/AshleyStoreLocator/\"", "");
                    var reader = XmlReader.Create(new StringReader(header + "<Country>" + xml + "</Country>"));
                    var country = (AfhsCountry)serializer.Deserialize(reader);
                    if (!string.IsNullOrEmpty(country.CountryCode) && !string.IsNullOrEmpty(country.CountryDescription))
                        countryList.Add(country);
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Log.Warn("Get Countries", ex);
            }

            return countryList;
        }

        public List<AfhsStoreDetail> GetAllHomeStores()
        {
            var homeStoreList = new List<AfhsStoreDetail>();
            try
            {
                XmlNode xmlNode = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetAllHomeStores();
                var allStoreInfo = new List<AfhsHomeStore>();                                
                using (var reader = new StringReader(xmlNode.InnerXml))
                {
                    var serializer = new XmlSerializer(typeof(AfhsGetAllStoresBody));
                    var allStores = serializer.Deserialize(reader) as AfhsGetAllStoresBody;
                    if (allStores != null)
                    {
                        allStoreInfo = allStores.AfhsAllStoreResponse.Homestores;
                    }
                }                
                foreach (var homeStoreInfo in allStoreInfo)
                {
                    homeStoreList.Add(GetStoreDetails(homeStoreInfo.CustomerNumber, homeStoreInfo.ShipTo));                    
                }
            }
            catch (Exception ex)
            {
                Log.Warn("Get Stores", ex);
            }

            return homeStoreList;
        }

        public AfhsStoreDetail GetStoreDetails(string customerNumber, string shipTo)
        {
            XmlNode xmlNode = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetStoreDetails(customerNumber, shipTo);            
            var serializer = new XmlSerializer(typeof(AfhsStoreDetail));            
            const string header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            var node = xmlNode.ChildNodes[0].ChildNodes[0].ChildNodes[0].ChildNodes[0];
            var xml = node.OuterXml;
            xml = xml.Replace("xmlns=\"http://awsm.ashleyfurniture.com/AshleyStoreLocator/\"", "");
            using (var reader = XmlReader.Create(new StringReader(header + xml)))
            {
                var homeStoreDetail = (AfhsStoreDetail)serializer.Deserialize(reader);
                homeStoreDetail = RemovesCDataFrom(homeStoreDetail);
                return homeStoreDetail;
            }
 
        }

        public IEnumerable<AfhsStoreDetail> GetStoreListLocation(double latitude, double Longitude, int radius)
        {
            var storeListLocation = new List<AfhsStoreDetail>();
            using (var soapClient = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap"))
            {
                XmlNode xmlNode = soapClient.GetStoreList(latitude, Longitude, radius);
                var serializer = new XmlSerializer(typeof(AfhsStoreDetail));
                const string header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
                foreach (XmlNode node in xmlNode.ChildNodes[0].ChildNodes[0].ChildNodes[0].ChildNodes)
                {
                    var xml = node.InnerXml;
                    xml = xml.Replace("xmlns=\"http://awsm.ashleyfurniture.com/AshleyStoreLocator/\"", "");
                    var reader = XmlReader.Create(new StringReader(header + "<StoreDetail>" + xml + "</StoreDetail>"));
                    storeListLocation.Add((AfhsStoreDetail)serializer.Deserialize(reader));
                    reader.Close();
                }
                return storeListLocation;
            }
        }


        public AfhsParticipatingStores GetParticipatingStoresList(int eventId)
        {
            var participatingStores = GlobalCachingProvider<AfhsParticipatingStores>.Instance.GetItem(eventId.ToString(), false) as AfhsParticipatingStores;

            if (participatingStores == null)
            {
                XmlNode xmlNode = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetParticipatingStores(eventId);                
                var serializer = new XmlSerializer(typeof(AfhsParticipatingStores));
                const string header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
                var node = xmlNode.ChildNodes[0].ChildNodes[0].ChildNodes[0].ChildNodes[0];
                var xml = node.InnerXml;
                xml = xml.Replace("xmlns=\"http://awsm.ashleyfurniture.com/AshleyStoreLocator/\"", "");
                var reader = XmlReader.Create(new StringReader(header + "<ParticipatingStores>" + xml + "</ParticipatingStores>"));
                participatingStores = (AfhsParticipatingStores)serializer.Deserialize(reader);
                GlobalCachingProvider<AfhsParticipatingStores>.Instance.AddItem(eventId.ToString(), participatingStores);
            }

            return participatingStores;
        }

        public AfhsNearestStoreIdentifier GetNearestStore(string zipCode, string countryCode = "USA")
        {
            var nearestStoreInfo = new AfhsNearestStoreIdentifier();
            var xmlNode = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetHomeStoreByZip(countryCode, zipCode);
            var xml = xmlNode.InnerXml;
            using (var xmlReader = new StringReader(xml))
            {
                var serializer = new XmlSerializer(typeof(AfhsNearestStoreBody));
                var responseBody = serializer.Deserialize(xmlReader) as AfhsNearestStoreBody;
                if (responseBody != null)
                {
                    var info = responseBody.Response.AfhsNearestStore.FirstOrDefault();
                    if (info != null)
                        nearestStoreInfo = info;
                }
            }
            return nearestStoreInfo;
        }

        public List<HopeStore> GetHopeToDreamStores()
        {
            var homeStoreList = new List<HopeStore>();
            try
            {
                var xmlNode = new StoreLocatorWebServiceSoapClient("StoreLocatorWebServiceSoap").GetAH2DStores();
                var xml = xmlNode.InnerXml;
                using (var reader = new StringReader(xml))
                {
                    var serializer = new XmlSerializer(typeof(AH2DBody));
                    var result = serializer.Deserialize(reader) as AH2DBody;
                    if (result != null)
                    {
                        homeStoreList = result.Ah2DStores.HopeStores;
                    }
                }
            }
            catch (Exception exp)
            {
                Log.Warn("Failed to retrieve service response " + exp.Message, exp, this);
            }
            return homeStoreList;
        }

        private string RemovesCData(string value)
        {
            value = value.Replace("<![CDATA[", "");
            return value.Replace("]]>", "");
        }

        private AfhsStoreDetail RemovesCDataFrom(AfhsStoreDetail store)
        {
            foreach (var job in store.JobOpenings)
            {
                job.JobTitle = RemovesCData(job.JobTitle);
                job.JobLinkText = RemovesCData(job.JobLinkText);
                job.JobDesc = RemovesCData(job.JobDesc);
            }

            foreach (var anEvent in store.StoreEvents)
            {
                anEvent.EventTitle = RemovesCData(anEvent.EventTitle);
                anEvent.EventLocation = RemovesCData(anEvent.EventLocation);
            }

            foreach (var support in store.Supports)
            {
                support.SupportDesc = RemovesCData(support.SupportDesc);
                support.SupportLinkText = RemovesCData(support.SupportLinkText);
                support.SupportTitle = RemovesCData(support.SupportTitle);
            }

            store.AboutUsCopy = RemovesCData(store.AboutUsCopy);
            store.FeatureTitle = RemovesCData(store.FeatureTitle);
            store.FeatureCopy = RemovesCData(store.FeatureCopy);
            store.JobOpenings = store.JobOpenings.Where(x => !string.IsNullOrWhiteSpace(x.JobTitle) && !string.IsNullOrWhiteSpace(x.JobDesc)).ToList();
            store.StoreEvents = store.StoreEvents.Where(x => !string.IsNullOrWhiteSpace(x.EventTitle) && !string.IsNullOrWhiteSpace(x.EventInformation)).ToList();
            store.Supports = store.Supports.Where(x => !string.IsNullOrWhiteSpace(x.SupportTitle)).ToList();

            return store;
        }
    }

    #region "Auxiliar classes"
    [XmlRoot("State", IsNullable=true)]
    public class AfhsState
    {
        public virtual string StateCode { get; set; }
        public virtual string StateName { get; set; }
    }

    [XmlRoot("Body", Namespace = "http://www.w3.org/2003/05/soap-envelope")]
    public class AfhsGetAllStoresBody
    {
        [XmlElement("GetStoreDetailResponse", Namespace = "http://awsm.ashleyfurniture.com/AshleyStoreLocator/")]
        public virtual AfhsAllStoreResponse AfhsAllStoreResponse { get; set; }
    }

    public class AfhsAllStoreResponse
    {
        [XmlArray("ArrayOfHomestores")]
        [XmlArrayItem(ElementName = "Homestores")]
        public virtual List<AfhsHomeStore> Homestores { get; set; }
    }
    
    public class AfhsHomeStore
    {
        public virtual string CustomerNumber { get; set; }
        public virtual string ShipTo { get; set; }
        public virtual string DateLastModified { get; set; }
    }

    [XmlRoot("Body", Namespace = "http://www.w3.org/2003/05/soap-envelope")]
    public class AH2DBody
    {
        [XmlElement("GetAH2DStores", Namespace = "http://awsm.ashleyfurniture.com/AshleyStoreLocator/")]
        public AH2DStores Ah2DStores { get; set; }
    }

    public class AH2DStores
    {
        [XmlArray("ArrayOfAH2DStores")]
        [XmlArrayItem(ElementName = "AH2DStores")]
        public List<HopeStore> HopeStores { get; set; }
    }

    public class HopeStore
    {
        public virtual string CustomerNumber { get; set; }
        public virtual string ShipTo { get; set; }
        public virtual string StoreFrontID { get; set; }
        public virtual string StoreAlias { get; set; }
        public virtual string City { get; set; }
        public virtual string StateName { get; set; }
        public virtual string Country { get; set; }
    }

    [XmlRoot("ParticipatingStores", IsNullable = true)]
    public class AfhsParticipatingStores
    {
        [XmlElement("EventName")]
        public virtual string EventName { get; set; }
        [XmlElement("EventDates")]
        public virtual string EventDates { get; set; }
        [XmlArray("StoreDetails")]
        [XmlArrayItem(ElementName = "StoreDetail")]
        public virtual List<AfhsParticipatingStoreDetail> StoreDetails { get; set; }
    }

    [XmlRoot]
    public class AfhsParticipatingStoreDetail
    {
        [XmlElement("CustomerNumber")]
        public virtual string CustomerNumber { get; set; }
        [XmlElement("ShipTo")]
        public virtual string ShipTo { get; set; }
        [XmlElement("StoreFrontID")]
        public virtual string StoreFrontID { get; set; }
        [XmlElement("StoreAlias")]
        public virtual string StoreAlias { get; set; }
        [XmlElement("StoreFrontName")]
        public virtual string StoreFrontName { get; set; }
        [XmlElement("Address1")]
        public virtual string Address1 { get; set; }
        [XmlElement("Address2")]
        public virtual string Address2 { get; set; }
        [XmlElement("City")]
        public virtual string City { get; set; }
        [XmlElement("StateCode")]
        public virtual string StateCode { get; set; }
        [XmlElement("ZipCode")]
        public virtual string ZipCode { get; set; }
        [XmlElement("StorePhone")]
        public virtual string StorePhone { get; set; }
        [XmlElement("StateName")]
        public virtual string StateName { get; set; }
    }

    [XmlRoot("StoreDetail")]    
    public class AfhsStoreDetail
    {
        [XmlElement("CustomerNumber")]
        public virtual string CustomerNumber { get; set; }
        [XmlElement("ShipTo")]
        public virtual string ShipTo { get; set; }
        [XmlElement("StoreFrontID")]
        public virtual string StoreFrontID { get; set; }
        [XmlElement("StoreAlias")]
        public virtual string StoreAlias { get; set; }
        [XmlElement("StoreFrontName")]
        public virtual string StoreFrontName { get; set; }
        [XmlElement("Address1")]
        public virtual string Address1 { get; set; }
        [XmlElement("Address2")]
        public virtual string Address2 { get; set; }
        [XmlElement("City")]
        public virtual string City { get; set; }
        [XmlElement("StateCode")]
        public virtual string StateCode { get; set; }
        [XmlElement("ZipCode")]
        public virtual string ZipCode { get; set; }
        [XmlElement("Country")]
        public virtual string Country { get; set; }
        [XmlElement("StoreSundayOpen")]
        public virtual string StoreSundayOpen { get; set; }
        [XmlElement("StoreSundayClose")]
        public virtual string StoreSundayClose { get; set; }
        [XmlElement("StoreMondayOpen")]
        public virtual string StoreMondayOpen { get; set; }
        [XmlElement("StoreMondayClose")]
        public virtual string StoreMondayClose { get; set; }
        [XmlElement("StoreTuesdayOpen")]
        public virtual string StoreTuesdayOpen { get; set; }
        [XmlElement("StoreTuesdayClose")]
        public virtual string StoreTuesdayClose { get; set; }
        [XmlElement("StoreWednesdayOpen")]
        public virtual string StoreWednesdayOpen { get; set; }
        [XmlElement("StoreWednesdayClose")]
        public virtual string StoreWednesdayClose { get; set; }
        [XmlElement("StoreThursdayOpen")]
        public virtual string StoreThursdayOpen { get; set; }
        [XmlElement("StoreThursdayClose")]
        public virtual string StoreThursdayClose { get; set; }
        [XmlElement("StoreFridayOpen")]
        public virtual string StoreFridayOpen { get; set; }
        [XmlElement("StoreFridayClose")]
        public virtual string StoreFridayClose { get; set; }
        [XmlElement("StoreSaturdayOpen")]
        public virtual string StoreSaturdayOpen { get; set; }
        [XmlElement("StoreSaturdayClose")]
        public virtual string StoreSaturdayClose { get; set; }
        [XmlElement("StorePhone")]
        public virtual string StorePhone { get; set; }
        [XmlElement("StoreFax")]
        public virtual string StoreFax { get; set; }
        [XmlElement("StoreEmail")]
        public virtual string StoreEmail { get; set; }
        [XmlElement("CSSundayOpen")]
        public virtual string CSSundayOpen { get; set; }
        [XmlElement("CSSundayClose")]
        public virtual string CSSundayClose { get; set; }
        [XmlElement("CSMondayOpen")]
        public virtual string CSMondayOpen { get; set; }
        [XmlElement("CSMondayClose")]
        public virtual string CSMondayClose { get; set; }
        [XmlElement("CSTuesdayOpen")]
        public virtual string CSTuesdayOpen { get; set; }
        [XmlElement("CSTuesdayClose")]
        public virtual string CSTuesdayClose { get; set; }
        [XmlElement("CSWednesdayOpen")]
        public virtual string CSWednesdayOpen { get; set; }
        [XmlElement("CSWednesdayClose")]
        public virtual string CSWednesdayClose { get; set; }
        [XmlElement("CSThursdayOpen")]
        public virtual string CSThursdayOpen { get; set; }
        [XmlElement("CSThursdayClose")]
        public virtual string CSThursdayClose { get; set; }
        [XmlElement("CSFridayOpen")]
        public virtual string CSFridayOpen { get; set; }
        [XmlElement("CSFridayClose")]
        public virtual string CSFridayClose { get; set; }
        [XmlElement("CSSaturdayOpen")]
        public virtual string CSSaturdayOpen { get; set; }
        [XmlElement("CSSaturdayClose")]
        public virtual string CSSaturdayClose { get; set; }
        [XmlElement("CustomerServicePhone")]
        public virtual string CustomerServicePhone { get; set; }
        [XmlElement("CustomerServiceFax")]
        public virtual string CustomerServiceFax { get; set; }
        [XmlElement("CustomerServiceEmail")]
        public virtual string CustomerServiceEmail { get; set; }
        [XmlElement("CouponLink")]
        public virtual string CouponLink { get; set; }
        [XmlElement("WeeklyAdLink")]
        public virtual string WeeklyAdLink { get; set; }
        [XmlElement("DistanceFromSearchLoc")]
        public virtual string DistanceFromSearchLoc { get; set; }
        [XmlElement("StoreFrontImageURL")]
        public virtual string StoreFrontImageURL { get; set; }
        [XmlElement("AboutUsCopy")]
        public virtual string AboutUsCopy { get; set; }
        [XmlElement("FacebookURL")]
        public virtual string FacebookURL { get; set; }
        [XmlElement("FlickrURL")]
        public virtual string FlickrURL { get; set; }
        [XmlElement("TwitterURL")]
        public virtual string TwitterURL { get; set; }
        [XmlElement("YouTubeURL")]
        public virtual string YouTubeURL { get; set; }
        [XmlElement("VideoID_1")]
        public virtual string VideoID_1 { get; set; }
        [XmlElement("VideoName_1")]
        public virtual string VideoName_1 { get; set; }
        [XmlElement("VideoID_2")]
        public virtual string VideoID_2 { get; set; }
        [XmlElement("VideoName_2")]
        public virtual string VideoName_2 { get; set; }
        [XmlElement("VideoID_3")]
        public virtual string VideoID_3 { get; set; }
        [XmlElement("VideoName_3")]
        public virtual string VideoName_3 { get; set; }
        [XmlElement("VideoID_4")]
        public virtual string VideoID_4 { get; set; }
        [XmlElement("VideoName_4")]
        public virtual string VideoName_4 { get; set; }
        [XmlElement("VideoID_5")]
        public virtual string VideoID_5 { get; set; }
        [XmlElement("VideoName_5")]
        public virtual string VideoName_5 { get; set; }
        [XmlElement("FeatureTitle")]
        public virtual string FeatureTitle { get; set; }
        [XmlElement("FeatureImageURL")]
        public virtual string FeatureImageURL { get; set; }
        [XmlElement("FeatureImageLink")]
        public virtual string FeatureImageLink { get; set; }
        [XmlElement("FeatureCopy")]
        public virtual string FeatureCopy { get; set; }
        [XmlElement("BannerImageURL")]
        public virtual string BannerImageURL { get; set; }
        [XmlArray("Supports")]
        [XmlArrayItem(ElementName = "Support")]
        public virtual List<AfhsSupportInfo> Supports { get; set; }
        [XmlArray("JobOpenings")]
        [XmlArrayItem(ElementName = "JobOpening")]
        public virtual List<AfhsJobInfo> JobOpenings { get; set; }
        [XmlArray("StoreEvents")]
        [XmlArrayItem(ElementName = "StoreEvent")]
        public virtual List<AfhsStoreEvent> StoreEvents { get; set; }
    }

    public class AfhsSupportInfo
    {
        [XmlElement("SupportLogoURL")]
        public virtual string SupportLogoURL { get; set; }
        [XmlElement("SupportLogoLink")]
        public virtual string SupportLogoLink { get; set; }
        [XmlElement("SupportTitle")]
        public virtual string SupportTitle { get; set; }
        [XmlElement("SupportDesc")]
        public virtual string SupportDesc { get; set; }
        [XmlElement("SupportLink")]
        public virtual string SupportLink { get; set; }
        [XmlElement("SupportLinkText")]
        public virtual string SupportLinkText { get; set; }
    }

    public class AfhsJobInfo
    {
        [XmlElement("JobImageURL")]
        public virtual string JobImageURL { get; set; }
        [XmlElement("JobImageLink")]
        public virtual string JobImageLink { get; set; }
        [XmlElement("JobTitle")]
        public virtual string JobTitle { get; set; }
        [XmlElement("JobDesc")]
        public virtual string JobDesc { get; set; }
        [XmlElement("JobLink")]
        public virtual string JobLink { get; set; }
        [XmlElement("JobLinkText")]
        public virtual string JobLinkText { get; set; }
    }

    public class AfhsStoreEvent
    {
        [XmlElement("EventTitle")]
        public virtual string EventTitle { get; set; }
        [XmlElement("EventLocation")]
        public virtual string EventLocation { get; set; }
        [XmlElement("EventInformation")]
        public virtual string EventInformation { get; set; }
        [XmlElement("EventStartDate")]
        public virtual string EventStartDate { get; set; }
        [XmlElement("EventEndDate")]
        public virtual string EventEndDate { get; set; }
    }

    [XmlRoot("Country")]
    public class AfhsCountry
    {

        public virtual string CountryCode { get; set; }
        public virtual string CountryDescription { get; set; }
        public virtual int DisplayOrder { get; set; }
        public virtual string ISOCountryCode { get; set; }

    }

    [XmlRoot("Body", Namespace = "http://www.w3.org/2003/05/soap-envelope")]
    public class AfhsNearestStoreBody
    {
        [XmlElement("GetHomeStoreResponse", Namespace = "http://awsm.ashleyfurniture.com/AshleyStoreLocator/")]        
        public virtual AfhsNearestStoreResponse Response { get; set; }
    }

    public class AfhsNearestStoreResponse
    {
        [XmlArray("ArrayOfHomestores")]
        [XmlArrayItem(ElementName = "Homestores")]
        public virtual List<AfhsNearestStoreIdentifier> AfhsNearestStore { get; set; }
    }

    public class AfhsNearestStoreIdentifier
    {
        public virtual string CustomerNumber { get; set; }
        public virtual string ShipTo { get; set; }
    }
    #endregion
}
