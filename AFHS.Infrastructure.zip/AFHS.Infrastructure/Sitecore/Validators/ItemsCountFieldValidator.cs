﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using System.Collections.Generic;
using System.Linq;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    

    [Serializable]
    public class ItemsCountFieldValidator : StandardValidator
    {
        public ItemsCountFieldValidator()
        {
        }

        public ItemsCountFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Item Count";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            List<string> list = new List<string>();
            list.AddRange(this.ControlValidationValue.Split('|').Where(x => !string.IsNullOrEmpty(x)));

            int count = 5;
            if (this.Parameters.ContainsKey("Count"))
                int.TryParse(this.Parameters["Count"], out count);
            if (list.Count == count)
                return ValidatorResult.Valid;

            string text = "The field \"{0}\" must contain {1} items.";
            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName(), count.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName(), count.ToString());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}