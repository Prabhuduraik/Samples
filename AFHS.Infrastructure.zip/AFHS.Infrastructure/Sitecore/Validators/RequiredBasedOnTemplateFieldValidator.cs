﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;

namespace Afhs.Infrastructure.Sitecore.Validators
{


    // TODO: Automatically created Item in Master database "/sitecore/system/Settings/Validation Rules/Item Rules/RequiredBasedOnTemplateFieldValidator" when creating RequiredBasedOnTemplateFieldValidator class. 

    [Serializable]
    public class RequiredBasedOnTemplateFieldValidator : StandardValidator
    {
        public RequiredBasedOnTemplateFieldValidator()
        {
        }

        public RequiredBasedOnTemplateFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Required Based on Template";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            var item = this.GetItem();
            if (item == null || this.GetField() == null || !string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            Guid _templateid;
            if (!this.Parameters.ContainsKey("TemplateID") || !Guid.TryParse(this.Parameters["TemplateID"], out _templateid) || item.TemplateID.ToGuid()!=_templateid || !string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            string text = "The field \"{0}\" must have a value.";
            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}