﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using Sitecore.Data;

namespace Afhs.Infrastructure.Sitecore.Validators
{


    // TODO: Automatically created Item in Master database "/sitecore/system/Settings/Validation Rules/Item Rules/MaxLengthBasedOnTemplateFieldValidator" when creating MaxLengthBasedOnTemplateFieldValidator class. 

    [Serializable]
    public class ImageModuleMaxLengthFieldValidator : StandardValidator
    {
        public ImageModuleMaxLengthFieldValidator()
        {
        }

        public ImageModuleMaxLengthFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Image Module Max Length";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            var item = this.GetItem();
            if (item == null || this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            int max = 0;
            //ImageHeader-OneHalf
            if(item.TemplateID== new ID("{42ED60B5-4BF2-4650-B019-487157BDA43D}"))
            {
                max = 30;
                if (this.ControlValidationValue.Trim().Length <= max)
                    return ValidatorResult.Valid;
            }
            else
            {
                max = 26;
                if (this.ControlValidationValue.Trim().Length <= max)
                    return ValidatorResult.Valid;
            }

            string text = "The field \"{0}\" must contain maximum {1} character.";
            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName(), max.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName(), max.ToString());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}