﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using Sitecore.Data.Items;
using Sitecore;
using Sitecore.Data;


namespace Afhs.Infrastructure.Sitecore.Validators
{ 

    [Serializable]
    public class CheckItemTreelistEx : StandardValidator
    {
        public CheckItemTreelistEx()
        {
        }

        public CheckItemTreelistEx(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Check item TreelistEx";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            var item = this.GetItem();
            if (item == null || this.GetField() == null )
                return ValidatorResult.Valid;

            if (!string.IsNullOrWhiteSpace(this.ControlValidationValue))
            {
                string[] IDItems = this.ControlValidationValue.Split('|');
                foreach (string id in IDItems)
                {
                    if (Context.ContentDatabase.GetItem(new ID(id)).TemplateID.ToString() != this.Parameters["TemplateID"].ToString())
                    {
                        string text = "Some field \"{0}\" is not the type  \"{1}\" ";
                        try
                        {
                            this.Text = this.GetText(text, this.GetFieldDisplayName(), Context.ContentDatabase.GetItem(new ID(this.Parameters["TemplateID"])).Name);
                        }
                        catch (System.FormatException)
                        {
                            this.Text = string.Format(text, this.GetFieldDisplayName(), Context.ContentDatabase.GetItem(new ID(this.Parameters["TemplateID"])).Name);
                        }

                        return this.GetFailedResult(ValidatorResult.Error);
                    }
                }
            }
            return ValidatorResult.Valid;
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}
