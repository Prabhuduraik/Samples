﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using Sitecore.Data;
using Sitecore.Data.Items;


namespace Afhs.Infrastructure.Sitecore.Validators
{

    [Serializable]
    public class CallToActionConditionalUrlRequiredFieldValidator : StandardValidator
    {
        public CallToActionConditionalUrlRequiredFieldValidator()
        {
        }

        public CallToActionConditionalUrlRequiredFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            var item = this.GetItem();
            if (item == null || item.TemplateID != new ID(Afhs.Infrastructure.Constants.TEMPLATE_CALLTOACTION_ID) || this.GetField() == null || !string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            ID mainMenuFolderID = new ID(Afhs.Infrastructure.Constants.ITEM_MAINMENUFOLDER_ID);

            //Navigation Panel -> Link Group Header -> Header href is optional
            //Hierarchy: /Main Menu/[Global Navigation Link<CallToAction>]/[Column<Folder>]/[Link Group Header<CallToAction>]  
            if (item.Paths.LongID.Split('/').Length >= 4 && item.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_COLUMNMENUFOLDER_ID) && item.Parent.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_MENUACTION_ID) && item.Parent.Parent.ParentID == mainMenuFolderID)
                //non required for Link Group header
                return ValidatorResult.Valid;

            string text = "The field \"{0}\" must have a value.";
            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}