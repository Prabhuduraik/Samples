﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using System.Collections.Generic;
using System.Linq;

using Sitecore;
using Sitecore.Data;
using Sitecore.Data.Items;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    [Serializable]
    public class ItemsLengthFieldValidator: StandardValidator
    {
        public ItemsLengthFieldValidator()
        {
        }

        public ItemsLengthFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        protected override ValidatorResult Evaluate()
        {
            ValidatorResult result = ValidatorResult.Valid;

            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            List<string> list = new List<string>();
            list.AddRange(this.ControlValidationValue.Split('|').Where(x => !string.IsNullOrEmpty(x)));

            Guid fieldID;
            if (!this.Parameters.ContainsKey("FieldID") || !Guid.TryParse(this.Parameters["FieldID"], out fieldID))
                return ValidatorResult.Valid;
            
            if(!Context.ContentDatabase.Items.Exists(new ID(fieldID)))
                return ValidatorResult.Valid;
            string fieldName = Context.ContentDatabase.GetItem(new ID(fieldID)).DisplayName;

            int maxLength = 20;
            if (this.Parameters.ContainsKey("MaxLength"))
                int.TryParse(this.Parameters["MaxLength"], out maxLength);

            List<string> invalidItems = new List<string>();
            foreach (string id in list)
            {
                Guid guid;
                if (Guid.TryParse(id, out guid)) 
                {
                    Item item = Context.ContentDatabase.GetItem(new ID(guid));
                    if(item.Fields.Contains(new ID(fieldID)) && item.Fields[new ID(fieldID)].Value.Length>maxLength)
                    {
                        invalidItems.Add(string.Format("{0} ID:{1}",item.Name,item.ID.ToString().ToLower()));
                        result = this.GetFailedResult(ValidatorResult.Error);
                    }
                }
            }

            if (result != ValidatorResult.Valid)
            {
                string text = "Following items must contain maximum {0} characters on field \"{1}\": ";
                //string text = "The \"{0}\" field's items must contain maximum {1} characters on field \"{2}\".";
                try
                {
                    this.Text = this.GetText(text, maxLength.ToString(), fieldName);
                }
                catch (System.FormatException)
                {
                    this.Text = string.Format(text, maxLength.ToString(), fieldName);
                }

                //string i = string.Join("\n",invalidItem);
                //this.Text = string.Format("{0}\n Following fields does not pass validation: \n", this.Text,string.Join("\n", invalidItem));
                //this.Text = string.Format("{0}<br/> Items with errors: <br/> {1}", this.Text, string.Join("<br/>", invalidItems));
                this.Text += string.Join(" | ", invalidItems);
            }

            return result;

        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }

        public override string Name
        {
            get { return "Items Length"; }
        }
    }
}
