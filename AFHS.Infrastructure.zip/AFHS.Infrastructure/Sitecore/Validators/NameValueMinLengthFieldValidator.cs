﻿using Sitecore.Data.Validators;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    [Serializable]
    public class NameValueMinLengthFieldValidator : StandardValidator
    {
        public NameValueMinLengthFieldValidator()
        {
        }

        public NameValueMinLengthFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            NameValueCollection coll = HttpUtility.ParseQueryString(this.ControlValidationValue);

            if (!this.Parameters.ContainsKey("Key")
                || string.IsNullOrWhiteSpace(this.Parameters["Key"])
                || !coll.AllKeys.Contains(this.Parameters["Key"])
                || string.IsNullOrEmpty(coll.Get(this.Parameters["Key"])))
                return ValidatorResult.Valid;

            int minLength = 50;
            if (this.Parameters.ContainsKey("MinLength"))
                int.TryParse(this.Parameters["MinLength"], out minLength);

            string value = coll.Get(this.Parameters["Key"]);
            if (value.Length >= minLength)
                return ValidatorResult.Valid;

            string text = "Parameter \"{0}\" must contain {1} characters minimum.";
            try
            {
                this.Text = this.GetText(text, this.Parameters["Key"], minLength.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.Parameters["Key"], minLength.ToString());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }

}
