﻿using System;
using Glass.Mapper.Sc.Configuration.Attributes;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using Sitecore.Data;
using System.Collections.Generic;
using Sitecore.Data.Items;
using System.Linq;
using Sitecore;
using Glass.Mapper.Sc;
using Afhs.Data.Models.sitecore.templates.User_Defined.Carousels;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    [Serializable]
    class UniqueCarouselHtmlIdsItemSelected : StandardValidator
    {
        public UniqueCarouselHtmlIdsItemSelected()
        {
        }
        public UniqueCarouselHtmlIdsItemSelected(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (string.IsNullOrEmpty(this.ControlValidationValue))
                 return ValidatorResult.Valid;

            SitecoreContext sc = new SitecoreContext();

            Item item = Context.ContentDatabase.GetItem(this.ControlValidationValue);

            List<Item> ImageItemsList = Context.ContentDatabase.SelectItems("fast:/sitecore/content/Repository/Carousel/*//*[@@templatename='OneImageCarouselNoButton' or @@templatename='OneImageCarouselItem' or @@templatename='ThumbnailWithProducts']").ToList();

            if (ImageItemsList.Exists(x => x.ID != this.ItemUri.ItemID && !string.IsNullOrEmpty(x.Fields["ItemID"].Value) &&
            !string.IsNullOrEmpty(Context.ContentDatabase.GetItem(x.Fields["ItemID"].Value).GlassCast<CarouselImageHtmlIDItem>().ImageHtmlID) && ( x.Fields["ItemID"].Value.Equals(this.ControlValidationValue) || 
                Context.ContentDatabase.GetItem(x.Fields["ItemID"].Value).GlassCast<CarouselImageHtmlIDItem>().ImageHtmlID.Equals(item.GlassCast<CarouselImageHtmlIDItem>().ImageHtmlID))))
            {
                string text = "The value selected is being used for other Carousel Image Item";
                try
                {
                    this.Text = this.GetText(text);
                }
                catch (System.FormatException)
                {
                    this.Text = string.Format(text);
                }
                return this.GetFailedResult(ValidatorResult.FatalError);
            }

            return ValidatorResult.Valid;           
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.FatalError);
        }
    }
}
