﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using Sitecore.Data;

namespace Afhs.Infrastructure.Sitecore.Validators
{

    [Serializable]
    public class CallToActionConditionalMaxLengthFieldValidator : StandardValidator
    {
        public CallToActionConditionalMaxLengthFieldValidator()
        {
        }

        public CallToActionConditionalMaxLengthFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            var item = this.GetItem();
            if (item == null || item.TemplateID != new ID(Afhs.Infrastructure.Constants.TEMPLATE_CALLTOACTION_ID) || this.GetField() == null || this.ControlValidationValue == null)
                return ValidatorResult.Valid;

            ID crossSiteNavFolderID = new ID("{4DA3D917-AF07-41DB-8AAE-588076D2687F}");
            ID lifeStylesFolderID = new ID("{D8BC606C-19AC-4F78-BCFE-941637BBCD24}");
            ID mainMenuFolderID = new ID(Afhs.Infrastructure.Constants.ITEM_MAINMENUFOLDER_ID);
            string text = string.Empty;

            if (item.ParentID == crossSiteNavFolderID || item.ParentID == lifeStylesFolderID)
            {
                if (this.ControlValidationValue.Length <= 20)
                {
                    return ValidatorResult.Valid;
                }
                text = "The field \"{0}\" must contain maximum 20 characters length when the item is under \"" + item.Parent.Paths.ContentPath + "\".";
            }
            else if (item.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_CALLTOACTION_ID)
               && item.Parent.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_FOLDERCOLUM_ID)
               && item.Parent.Parent.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_MENUACTION_ID))
            {
                if (this.ControlValidationValue.Length <= 100)
                {
                    return ValidatorResult.Valid;
                }
                text = "The field \"{0}\" must contain maximum 100 characters length when the item is part of the Navigation Panel component.";

            }
            else if (item.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_FOLDERCOLUM_ID)
           && item.Parent.Parent.TemplateID == new ID(Afhs.Infrastructure.Constants.TEMPLATE_MENUACTION_ID))
            {
                if (this.ControlValidationValue.Length <= 100)
                {
                    return ValidatorResult.Valid;
                }
                text = "The field \"{0}\" must contain maximum 100 characters length when the item is part of the Navigation Panel component.";

            }
            else
                return ValidatorResult.Valid;


            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}