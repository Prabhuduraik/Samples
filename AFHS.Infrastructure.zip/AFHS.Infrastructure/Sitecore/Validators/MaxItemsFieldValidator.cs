﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using Sitecore.Data.Fields;
using System.Collections.Generic;
using System.Linq;

namespace Afhs.Infrastructure.Sitecore.Validators
{


    [Serializable]
    public class MaxItemsFieldValidator : StandardValidator
    {
        public MaxItemsFieldValidator()
        {
        }

        public MaxItemsFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Maximum Item Count";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            List<string> list = new List<string>();
            list.AddRange(this.ControlValidationValue.Split('|').Where(x=> !string.IsNullOrEmpty(x)));

            int maxCount = 5;
            if (this.Parameters.ContainsKey("MaxCount"))
                int.TryParse(this.Parameters["MaxCount"], out maxCount);
            if (list.Count <= maxCount)
                return ValidatorResult.Valid;
            
            string text = "The field \"{0}\" must contain minimum {1} items.";
            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName(), maxCount.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName(), maxCount.ToString());
            }
            if (list.Count <= maxCount)
                return ValidatorResult.Valid;


            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}