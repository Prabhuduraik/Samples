﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using System.Collections.Generic;
using System.Linq;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    
    [Serializable]
    public class MinItemsFieldValidator : StandardValidator
    {
        public MinItemsFieldValidator()
        {
        }

        public MinItemsFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Minimum Item Count";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            List<string> list = new List<string>();
            list.AddRange(this.ControlValidationValue.Split('|').Where(x=>!string.IsNullOrEmpty(x)));

            int minCount = 5;
            if (this.Parameters.ContainsKey("MinCount"))
                int.TryParse(this.Parameters["MinCount"], out minCount);
            if (list.Count >= minCount)
                return ValidatorResult.Valid;

            if (this.Parameters.ContainsKey("IgnoreIfEmpty") && this.Parameters["IgnoreIfEmpty"]!="0")
                if(list.Count == 0)
                    return ValidatorResult.Valid;
            
            string text ="The field \"{0}\" must contain minimum {1} items.";
            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName(), minCount.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName(), minCount.ToString());
            }            
            
            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}