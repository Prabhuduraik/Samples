﻿using Glass.Mapper.Sc;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Data.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    [Serializable]
    class UniqueKeyFieldDictionaryEntry : StandardValidator
    {
        public UniqueKeyFieldDictionaryEntry() {
        }

        public UniqueKeyFieldDictionaryEntry(SerializationInfo info, StreamingContext context)
            : base(info, context) { 
        }

        public override string Name
        {
            get { return "Validator Name";  }
        }

        protected override ValidatorResult Evaluate()
        {
            if (string.IsNullOrEmpty(this.ControlValidationValue))
                return ValidatorResult.Valid;

            SitecoreContext sc = new SitecoreContext();

            Item item = this.GetItem();

            string validPath = "/sitecore/content/Repository/PagesCommonValues/Cart Labels";

            if (!item.Paths.FullPath.StartsWith(validPath))
                return ValidatorResult.Valid;

            List<Item> DictionaryEntryItemsList = Context.ContentDatabase.SelectItems("fast:/sitecore/content/Repository/PagesCommonValues/Cart Labels/*//*[@@templateid='{6D1CD897-1936-4A3A-A511-289A94C2A7B1}']").ToList();

            if (DictionaryEntryItemsList.Any(x => x.ID != item.ID && 
                !string.IsNullOrEmpty(x.Fields["Key"].Value) && 
                x.Fields["Key"].Value == this.ControlValidationValue))
            {
                string text = "The value is already used in other item";
                try
                {
                    this.Text = this.GetText(text);
                }
                catch (System.FormatException)
                {
                    this.Text = string.Format(text);
                }
                return this.GetFailedResult(ValidatorResult.FatalError);
            }

            return ValidatorResult.Valid;  
        }
        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.FatalError);
        }
    }
}
