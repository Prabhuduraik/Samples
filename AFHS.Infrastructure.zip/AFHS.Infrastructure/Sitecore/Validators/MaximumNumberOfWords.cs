﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using System.Collections.Specialized;
using System.Web;
using System.Linq;

namespace Afhs.Infrastructure.Sitecore.Validators
{
    [Serializable]
    public class MaximumNumberOfWords : StandardValidator
    {
                public MaximumNumberOfWords()
        {
        }

        public MaximumNumberOfWords(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            if (string.IsNullOrWhiteSpace(this.Parameters["MaxWords"]))
                return ValidatorResult.Valid;

            int coutWorks;
            int maxWord = Convert.ToInt32(this.Parameters["MaxWords"]);
            coutWorks = this.GetField().ToString().Split(',').Count()-1 + this.GetField().ToString().Split(' ').Count();


            if (maxWord >= coutWorks)
                return ValidatorResult.Valid;


            string text = "Parameter \"{0}\" must contain {1} Words maximum.";
            try
            {
                this.Text = this.GetText(text, this.Parameters["MaxWords"], maxWord.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.Parameters["MaxWords"], maxWord.ToString());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}
