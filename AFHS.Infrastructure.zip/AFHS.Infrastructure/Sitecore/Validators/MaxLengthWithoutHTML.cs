﻿using Sitecore.Data.Validators;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace Afhs.Infrastructure.Sitecore.Validators
{

    [Serializable]
    public class MaxLengthWithoutHTML : StandardValidator
    {
        public MaxLengthWithoutHTML()
        {
        }

        public MaxLengthWithoutHTML(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            string strTexto = this.ControlValidationValue;
            strTexto = Regex.Replace(strTexto, "<((.|\n)*?)>", "");
            strTexto = Regex.Replace(strTexto, "\r|\n|\t", "");
            int maxLength = 300;
            if (this.Parameters.ContainsKey("MaxLength"))
                int.TryParse(this.Parameters["MaxLength"], out maxLength);

            if (strTexto.Length <= maxLength)
                return ValidatorResult.Valid;

            string text = "The field \"{0}\" must contain maximum {1} character.";

            try
            {
                this.Text = this.GetText(text, this.GetFieldDisplayName(), maxLength.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.GetFieldDisplayName(), maxLength.ToString());
            }
            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}
