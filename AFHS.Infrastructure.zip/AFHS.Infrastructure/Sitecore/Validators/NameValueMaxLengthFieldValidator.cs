﻿using System;
using System.Runtime.Serialization;
using Sitecore.Data.Validators;
using System.Collections.Specialized;
using System.Web;
using System.Linq;

namespace Afhs.Infrastructure.Sitecore.Validators
{

    [Serializable]
    public class NameValueMaxLengthFieldValidator : StandardValidator
    {
        public NameValueMaxLengthFieldValidator()
        {
        }

        public NameValueMaxLengthFieldValidator(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public override string Name
        {
            get
            {
                return "Validator Name";
            }
        }

        protected override ValidatorResult Evaluate()
        {
            if (this.GetField() == null || string.IsNullOrWhiteSpace(this.ControlValidationValue))
                return ValidatorResult.Valid;

            NameValueCollection coll = HttpUtility.ParseQueryString(this.ControlValidationValue);
            
            if (!this.Parameters.ContainsKey("Key") 
                || string.IsNullOrWhiteSpace(this.Parameters["Key"]) 
                || !coll.AllKeys.Contains(this.Parameters["Key"])
                || string.IsNullOrEmpty(coll.Get(this.Parameters["Key"])))
                return ValidatorResult.Valid;            

            int maxLength = 200;
            if (this.Parameters.ContainsKey("MaxLength"))
                int.TryParse(this.Parameters["MaxLength"], out maxLength);

            string value = coll.Get(this.Parameters["Key"]);
            if (value.Length <= maxLength)
                return ValidatorResult.Valid;

            string text = "Parameter \"{0}\" must contain {1} characters maximum.";
            try
            {
                this.Text = this.GetText(text, this.Parameters["Key"] ,maxLength.ToString());
            }
            catch (System.FormatException)
            {
                this.Text = string.Format(text, this.Parameters["Key"], maxLength.ToString());
            }

            return this.GetFailedResult(ValidatorResult.Error);
        }

        protected override ValidatorResult GetMaxValidatorResult()
        {
            return this.GetFailedResult(ValidatorResult.Error);
        }
    }
}