﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Afhs.Infrastructure.Sitecore.Extensions;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Events;

namespace Afhs.Infrastructure.Sitecore.Events
{
    public class RemoveOrphanedRenderingItem
    {
        public const string DYNAMIC_KEY_REGEX = @"(.+){[\d\w]{8}\-([\d\w]{4}\-){3}[\d\w]{12}}";
        public const int GUID_LENGTH = 32;

        public void OnItemSaved(object sender, EventArgs args)
        {
            Item item = Event.ExtractParameter(args, 0) as Item;

            if (item != null)
            {
                //if the rendering reference points to a dynamic placeholder then ensure that that placeholder exists
                //if not then remove the reference. This takes care of the scenario where a scaffolding   
                //component has been removed without first removing the Sub-Layouts that may by bound to it.
                var device = Context.Device;
                if (device != null)
                {
                    var renderingReferences = item.Visualization.GetRenderings(device, false);

                    foreach (var renderingReference in renderingReferences)
                    {
                        var key = renderingReference.Placeholder;
                        var regex = new Regex(DYNAMIC_KEY_REGEX);
                        var match = regex.Match(renderingReference.Placeholder);

                        if (match.Success && match.Groups.Count > 0)
                        {
                            //get the rendering reference unique id that we are contained in
                            var parentRenderingId = key.Substring(key.Length - GUID_LENGTH, GUID_LENGTH).ToUpper();

                            //if this parent renderingReference is not in the current list of rendering references
                            //then the current rendering reference should be removed as it means that the parent
                            //rendering reference has been removed by the user without first removing the children
                            if (renderingReferences.All(r => r.UniqueId.ToUpper() != parentRenderingId))
                            {
                                //use an extension method to remove the orphaned rendering reference
                                //from the item's layout definition item.
                                item.RemoveRenderingReference(renderingReference.UniqueId);
                            }
                        }
                    }
                }
            }
        }
    }
}
