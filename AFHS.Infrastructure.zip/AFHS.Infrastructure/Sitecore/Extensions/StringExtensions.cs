﻿using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace Afhs.Infrastructure.Sitecore.Extensions
{
    public static class StringExtensions
    {
        public static string GetSEOFriendlyName(this string seoString)
        {
            var normalized = seoString.Normalize(NormalizationForm.FormD);


            var resultBuilder = new StringBuilder();
            foreach (var character in normalized)
            {
                var category = CharUnicodeInfo.GetUnicodeCategory(character);
                if (category == UnicodeCategory.LowercaseLetter
                    || category == UnicodeCategory.UppercaseLetter
                    || category == UnicodeCategory.SpaceSeparator
                    || character.Equals('-'))
                    resultBuilder.Append(character);
            }
            var result = Regex.Replace(resultBuilder.ToString(), @"\s+", "-").ToLowerInvariant();
            return result;
        }
    }
}
