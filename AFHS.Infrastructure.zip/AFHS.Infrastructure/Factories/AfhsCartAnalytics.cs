﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sitecore.Commerce.Data.Products;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models;
using Sitecore.Commerce.Services.Carts;
using Sitecore.Commerce.Entities.Carts;
using Sitecore.Commerce.Entities.Products;
using Sitecore.Commerce.Entities.Prices;
using Sitecore.Commerce.Entities.Customers;

namespace Afhs.Infrastructure.Factories
{
    public static class AfhsCartAnalytics
    {
        //TODO: A way to pass Error Information to a process with Sitecore context
        public static void AddItems(IEnumerable<Listing> listings, ShoppingCart shoppingCart)
        {
            try
            {
                var cartServiceProvider = new CartServiceProvider();
                var cartRequest = new CreateOrResumeCartRequest("Afhs", "guest-7250");
                var sitecoreResponse = cartServiceProvider.CreateOrResumeCart(cartRequest);
                var commerceCart = sitecoreResponse.Cart;
                if (!sitecoreResponse.Success)
                {
                    throw new InvalidOperationException("Could not get Cart from Commerce Connect");
                }

                var cartLines = new List<CartLine>();
                var axCartItems = new List<TransactionItem>(shoppingCart.Items);

                foreach (var listing in listings)
                {
                    var axCartItem = axCartItems.Find(i => i.ItemId == listing.ItemId);
                    var price = axCartItem.PriceWithCurrency.Replace("$", "");
                    if (axCartItem == null)
                    {
                        var msg = String.Format("Could not find item with Id {0}", listing.ItemId);
                        //Sitecore.Diagnostics.Log.Error(msg, this);
                        throw new NullReferenceException(msg);
                    }
                    cartLines.Add(
                        new CartLine
                        {
                            Product = new CartProduct
                            {
                                ProductId = listing.ItemId,
                                Price = new Price(decimal.Parse(price), "USD")
                            },
                            Quantity = (uint)listing.Quantity,
                            ExternalCartLineId = axCartItem.LineId
                        }
                    );
                }

                commerceCart.ExternalId = shoppingCart.CartId;
                commerceCart.Lines = cartLines;
                //commerceCart.Total.TaxTotal.Amount = decimal.Parse(shoppingCart.Tax.Replace("$", ""));
                //commerceCart.Total.Amount = decimal.Parse(shoppingCart.GrandTotal.Replace("$", ""));
            }
            catch (Exception)
            {                
                //Handle Logging Information Here
            }
        }

        public static void UpdateItems() { }

        public static void RemoveItems() { }
        
    }
}
