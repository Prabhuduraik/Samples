﻿using Afhs.Data.Obec;
using AFM.Commerce.Framework.Core.Models;

namespace Afhs.Infrastructure.Factories
{
    public static class AfhsProductAdditionalDimension
    {
        public static AdditionalDimension Create(AFMAdditionalDimensions source)
        {
            var item = new AdditionalDimension
            {
                AlternativeDimensionCM = source.AlternativeDimensionCM,
                AlternativeDimensionInch = source.AlternativeDimensionInch,
                DepthCM = source.DepthCM,
                DepthInch = source.DepthInch,
                DimensionDescription = source.DimensionDescription,
                HeightCM = source.HeightCM,
                HeightInch = source.HeightInch,
                ProductRecordId = source.ProductRecordId,
                WidthCM = source.WidthCM,
                WidthInch = source.WidthInch,
                //AdditionalDimension.ExternalId can't be the same value as the Product.ExternalId, needs to be something 
                //unique to the combination of Product.ExternalId & some other key; in this case chose DimensionDescription
                //if these two ids are the same only one item will save as a child item of the product.
                ExternalId = source.DimensionDescription
            };

            return item;
        }
    }
}
