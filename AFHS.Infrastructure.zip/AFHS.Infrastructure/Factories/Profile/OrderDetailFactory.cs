﻿using Afhs.Data.CustomClasses.Profile;
using Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Factories.Profile
{
    public class OrderDetailFactory
    {
        public static OrderDetail Create(Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models.SalesOrder salesOrder){
            return MapSalesOrderToOrderDetail(salesOrder);
        }

        private static OrderDetail MapSalesOrderToOrderDetail(Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models.SalesOrder salesOrder)
        {
            try
            {
                var orderDetail = new OrderDetail();            
            
                orderDetail.BillingAddress = salesOrder.BillingAddress ?? new Address();
                orderDetail.ShippingAddress = salesOrder.ShippingAddress ?? new Address();
                orderDetail.FormattedBillingAddress = CreateFormattedAddress(orderDetail.BillingAddress);
                orderDetail.FormattedShippingAddress = CreateFormattedAddress(orderDetail.ShippingAddress);

                    orderDetail.RecipientName = salesOrder.ShippingAddress != null && !String.IsNullOrEmpty(salesOrder.ShippingAddress.Name) ?
                        salesOrder.ShippingAddress.Name : salesOrder.BillingAddress != null && !String.IsNullOrEmpty(salesOrder.BillingAddress.Name) ?
                    salesOrder.BillingAddress.Name : String.Empty;
            
                orderDetail.OrderPlacedDate = DateTime.Parse(salesOrder.OrderPlacedDate);
            
                orderDetail.Items = GetOrderDetailItems(salesOrder.Items);
                orderDetail.ItemCount = orderDetail.Items.Count();

                orderDetail.OrderConfirmationId = salesOrder.ConfirmationId;
                orderDetail.OrderStatus = salesOrder.Status;
                orderDetail.DeliveryMethod = GetDeliveryMethod(salesOrder);

                orderDetail.PaymentInfo = CreatePaymentInfo(salesOrder.TenderLines.FirstOrDefault());

                orderDetail.ShippingCharge = salesOrder.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "DS") != null ?
                    salesOrder.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "DS").AFMShippingCost : 0M;
                
                    orderDetail.HomeDeliveryCharge = salesOrder.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "HD") != null ?
                        salesOrder.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "HD").AFMShippingCost : 0M;
                
                orderDetail.Subtotal =
                    CalculateSubTotal(decimal.Parse(salesOrder.SubtotalWithCurrency.Replace("$", "")),
                        orderDetail.ShippingCharge, orderDetail.HomeDeliveryCharge);
   
                orderDetail.SalesTax = decimal.Parse(salesOrder.TaxAmountWithCurrency.Replace("$", ""));
                orderDetail.OrderTotal = salesOrder.TotalAmount;
                orderDetail.OrderTotalDiscount = decimal.Parse(salesOrder.DiscountAmountWithCurrency.Replace("$", ""));

                return orderDetail;
            }
            catch (Exception)
            {
                return null;
            }            
        }

        private static IEnumerable<OrderDetailProductItem> GetOrderDetailItems(ICollection<TransactionItem> salesOrderItems)
        {            
            var orderDetailItems = new List<OrderDetailProductItem>();

            orderDetailItems.AddRange(OrderDetailItemFactory.Create(salesOrderItems));

            return orderDetailItems;
        }

        private static decimal CalculateSubTotal(decimal subtotalPlusShippingCharge, decimal shippingCharge, decimal homeDeliveryCharge)
        {
            return (subtotalPlusShippingCharge - shippingCharge - homeDeliveryCharge);
        }

        private static string GetStreetAddressLine(string streetNumber, string street)
        {
            var addressStringBuilder = new StringBuilder();
            if(!string.IsNullOrEmpty(streetNumber)){
                addressStringBuilder.Append(streetNumber);
                addressStringBuilder.Append(' ');
            }
            addressStringBuilder.Append(street);            
            return addressStringBuilder.ToString();
        }

        private static string GetCityStateZipcodeLine(string city, string state, string zipcode)
        {
            return string.Format("{0}, {1} {2}", city, state, zipcode);
        }

        private static FormattedAddress CreateFormattedAddress(Address address)
        {
            return new FormattedAddress
            {
                StreetAddress =
                    GetStreetAddressLine(address.StreetNumber,
                    address.Street),
                AptNumberOrSuiteAddress =
                    String.IsNullOrEmpty(address.Street2) ? String.Empty
                        : address.Street2,
                CityStateZipcode =
                    GetCityStateZipcodeLine(address.City,
                        address.State,
                        address.ZipCode),
                Country = address.Country,
                Phone = address.Phone,
                Phone2 = address.Phone2,
                Phone3 = address.Phone3,
                Email = address.Email,
                Email2 = address.Email2
            };
        }

        private static OrderDetailPaymentInfo CreatePaymentInfo(TenderDataLine salesOrderPaymentLine)
        {
            if (salesOrderPaymentLine == null)
            {
                return new OrderDetailPaymentInfo();
            }
            return new OrderDetailPaymentInfo
            {
                NameOnCard = salesOrderPaymentLine.TokenizedPaymentCard.NameOnCard,
                CreditCardType = salesOrderPaymentLine.TokenizedPaymentCard.CardType,               
                MaskedCreditCardNumber = String.Format("XXXX-XXXX-XXXX-{0}", 
                    salesOrderPaymentLine.PaymentCard.CardNumber.Substring(
                    salesOrderPaymentLine.PaymentCard.CardNumber.Length - 4))                   
            };
        }

        private static string GetDeliveryMethod(SalesOrder saleOrders) {
            var deliveryMethod = string.Empty;
            if (saleOrders.Items.FirstOrDefault() == null)
                deliveryMethod = MapDeliveryModeDescription(saleOrders.DeliveryModeDescription);
            else
            {
                if (saleOrders.Items.FirstOrDefault(i => i.DeliveryModeId == "DS") != null) {
                    deliveryMethod += saleOrders.Items.FirstOrDefault(i => i.DeliveryModeId == "DS").AFMShippingMode;
                    if (saleOrders.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "DS") != null )
                        deliveryMethod += ":&nbsp;" + String.Format("{0:C}", saleOrders.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "DS").AFMShippingCost);
                }                    
                if (saleOrders.Items.FirstOrDefault(i => i.DeliveryModeId == "HD") != null) {
                    if (!string.IsNullOrEmpty(deliveryMethod))
                        deliveryMethod += "</br>";
                    deliveryMethod += saleOrders.Items.FirstOrDefault(i => i.DeliveryModeId == "HD").AFMShippingMode;
                    if (saleOrders.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "HD") != null)
                        deliveryMethod += ":&nbsp;" + String.Format("{0:C}", saleOrders.Items.FirstOrDefault(i => i.AFMItemType == 1 && i.DeliveryModeId == "HD").AFMShippingCost);
                }
            }
            return deliveryMethod; 
        }

        private static string MapDeliveryModeDescription(string deliveryModeDescription)
        {
            if (deliveryModeDescription.Trim() == "Home Delivery")
            {
                return "Small Parcel";
            }

            return deliveryModeDescription;
        }
    }
}
