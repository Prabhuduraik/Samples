﻿using Afhs.Data.CustomClasses;
using Afhs.Data.CustomClasses.Profile;
using Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Factories.Profile
{
    public class OrderDetailItemFactory
    {
        public static IEnumerable<OrderDetailProductItem> Create(IEnumerable<TransactionItem> transactionItems)
        {
            return MapTransactionItemToProductItem(transactionItems);
        }

        private static IEnumerable<OrderDetailProductItem> MapTransactionItemToProductItem(IEnumerable<TransactionItem> transactionItems)
        {
            var orderDetailProductItems = new List<OrderDetailProductItem>();

            var nonKitItems = transactionItems.Where(ti => ti.AFMItemType != 1 && string.IsNullOrEmpty(ti.AFMKitItemId));

            if(nonKitItems.Count() > 0)
            {
                 var orderDetailItems = nonKitItems.Select(ti => Create(ti));                                
                 orderDetailProductItems.AddRange(orderDetailItems);            
            }

            var kitHeaderItems = transactionItems.Where(ti => ti.AFMItemType != 1 && !string.IsNullOrEmpty(ti.AFMKitItemId))
                .GroupBy(i => i.AFMKitSequenceNumber).Select(i => i.First());

            if (kitHeaderItems.Count() > 0)
            {
                var kitItemList = new List<OrderDetailKitHeaderProductItem>();
                foreach (var kitItem in kitHeaderItems)
                {
                    var kitHeaderItem = MapTransactionItemToKitProductHeaderItem(kitItem);
                    kitHeaderItem.KitComponents = GetKitComponents(transactionItems
                        .Where(i => i.AFMKitItemId == kitItem.AFMKitItemId &&
                            i.AFMKitSequenceNumber == kitItem.AFMKitSequenceNumber));

                    kitHeaderItem.LinePrice = kitHeaderItem.KitComponents.Select(i => i.LinePrice).Aggregate((a, b) => a + b);
                    kitHeaderItem.LineTotal = kitHeaderItem.KitComponents.Select(i => i.LineTotal).Aggregate((a, b) => a + b);
                    kitHeaderItem.LinePriceWithDiscount = kitHeaderItem.KitComponents.Select(i => i.LinePriceWithDiscount).Aggregate((a, b) => a + b);
                    kitHeaderItem.LineTotalDiscount = kitHeaderItem.KitComponents.Select(i => i.LineTotalDiscount).Aggregate((a, b) => a + b);
                    kitItemList.Add(kitHeaderItem);                    
                }

                orderDetailProductItems.AddRange(kitItemList);
            }
                
                                               
            return orderDetailProductItems;
        }

        private static OrderDetailProductItem Create(TransactionItem transactionItem)
        {
            var orderDetailProductItem = new OrderDetailProductItem();
            var productDetails = GetProductDetails(transactionItem.ProductDetails);
            if (transactionItem != null)
            {
                orderDetailProductItem.ActualDeliveryDate = transactionItem.AFMActualDeliveryDate;
                orderDetailProductItem.Color = transactionItem.AFMColor;
                orderDetailProductItem.LineConfirmationNumber = transactionItem.AFMLineConfirmationNumber;
                orderDetailProductItem.LineOrderNumber = transactionItem.LineOrderNumber;
                orderDetailProductItem.LinePrice = decimal.Parse(transactionItem.PriceWithCurrency.Replace("$", ""));
                orderDetailProductItem.LineTotal = decimal.Parse(transactionItem.NetAmountWithCurrency.Replace("$", ""));
                orderDetailProductItem.OfferNames = transactionItem.OfferNames;
                orderDetailProductItem.Name = transactionItem.ProductName;
                orderDetailProductItem.Quantity = transactionItem.Quantity;
                orderDetailProductItem.LinePriceWithDiscount = CaculateLinePriceWithDiscount(decimal.Parse(transactionItem.NetAmountWithCurrency.Replace("$", "")), Convert.ToInt32(transactionItem.Quantity));
                orderDetailProductItem.ProductId = transactionItem.ProductId;
                orderDetailProductItem.ProductNumber = transactionItem.ProductNumber;
                orderDetailProductItem.PromotionCodes = transactionItem.PromotionLines;
                orderDetailProductItem.Size = transactionItem.AFMSize;
                orderDetailProductItem.Style = transactionItem.Style;
                orderDetailProductItem.ScheduledDeliveryDate = transactionItem.AFMScheduledDeliveryDate;
                orderDetailProductItem.DeliveryMethod = transactionItem.AFMShippingMode;
                orderDetailProductItem.CartLine = transactionItem.AFMCartLineATP.ShippingSpan;
                orderDetailProductItem.SalesUnitOfMeasure = transactionItem.AFMUnit;
                orderDetailProductItem.QuantityPerBox = Convert.ToInt32(transactionItem.AFMQtyPerBox);
                orderDetailProductItem.FulfilledBy = transactionItem.AFMVendorName;
                orderDetailProductItem.LineTotalDiscount = CalculateLineDiscount(decimal.Parse(transactionItem.PriceWithCurrency.Replace("$", "")), Convert.ToInt32(transactionItem.Quantity), decimal.Parse(transactionItem.NetAmountWithCurrency.Replace("$", "")));
                orderDetailProductItem.TrackingNumber = transactionItem.AFMTrackingNumber;
                if (productDetails != null)
                {
                    orderDetailProductItem.ImagePath = productDetails.ImageUrl;
                    orderDetailProductItem.ImageAlt = productDetails.ImageAlt;
                    orderDetailProductItem.ProductUrl = productDetails.ProductUrl;
                    orderDetailProductItem.Name = productDetails.Name;
                }
            }
            
            return orderDetailProductItem;
        }

        private static OrderDetailKitHeaderProductItem MapTransactionItemToKitProductHeaderItem(TransactionItem kitTransactionItem)
        {
            var kitProductDetails = GetProductDetails(kitTransactionItem.AFMKitItemProductDetails);
            var kitItem = new OrderDetailKitHeaderProductItem
            {
                Name = kitProductDetails.Name,
                Color = kitProductDetails.DimensionValues.Color,
                Style = kitProductDetails.DimensionValues.Style,
                Size = kitProductDetails.DimensionValues.Size,
                ImagePath = kitProductDetails.ImageUrl,
                LinePrice = 0.00M,
                Quantity = kitTransactionItem.AFMKitItemQuantity,
                ProductId = kitTransactionItem.AFMKitProductId,
                ProductNumber = kitTransactionItem.AFMKitItemId,
                LineConfirmationNumber = kitTransactionItem.AFMLineConfirmationNumber,
                ActualDeliveryDate = kitTransactionItem.AFMActualDeliveryDate,
                ScheduledDeliveryDate = kitTransactionItem.AFMScheduledDeliveryDate,
                DeliveryMethod = kitTransactionItem.AFMShippingMode,
                CartLine = kitTransactionItem.AFMCartLineATP.ShippingSpan,
                FulfilledBy = kitTransactionItem.AFMVendorName
            };            

            return kitItem;
        }

        private static IEnumerable<OrderDetailKitComponent> GetKitComponents(IEnumerable<TransactionItem> kitItems)
        {
            var kitComponents = new List<OrderDetailKitComponent>();

            if (kitItems.Count() > 0)
            {
                foreach (var kitComponent in kitItems)
                {
                    kitComponents.Add(CreateKitComponent(kitComponent));
                }
            }

            return kitComponents;
        }

        private static OrderDetailKitComponent CreateKitComponent(TransactionItem kitItem)
        {            
            var item = new OrderDetailKitComponent
            {
                Name = kitItem.ProductName,
                Color = kitItem.AFMColor,
                Size = kitItem.AFMSize,
                Style = kitItem.Style,
                ProductNumber = kitItem.ItemId,
                Quantity = kitItem.Quantity,
                LinePrice = decimal.Parse(kitItem.PriceWithCurrency.Replace("$","")),
                LineTotal = decimal.Parse(kitItem.NetAmountWithCurrency.Replace("$", "")),
                LinePriceWithDiscount = CaculateLinePriceWithDiscount(decimal.Parse(kitItem.NetAmountWithCurrency.Replace("$", "")), Convert.ToInt32(kitItem.Quantity)),
                LineTotalDiscount = CalculateLineDiscount(decimal.Parse(kitItem.PriceWithCurrency.Replace("$", "")), Convert.ToInt32(kitItem.Quantity), decimal.Parse(kitItem.NetAmountWithCurrency.Replace("$", ""))),
                OfferNames = kitItem.OfferNames,
                SequenceNumber = kitItem.AFMKitSequenceNumber,
                LineConfirmationNumber = kitItem.AFMLineConfirmationNumber,
                LineOrderNumber = kitItem.LineOrderNumber
            };

            return item;
        }

        private static ListingProductDetails GetProductDetails(string productDetails)
        {
            return JsonConvert.DeserializeObject<ListingProductDetails>(productDetails);
        }            

        private static decimal CaculateLinePriceWithDiscount(decimal lineTotal, int quantity)
        {
            return quantity < 1? 0:(lineTotal / quantity);        
        }

        private static decimal CalculateLineDiscount(decimal linePrice, int quantity, decimal lineTotal) 
        {
            return quantity < 1? 0:((linePrice * quantity) - lineTotal);
        }
    }
}
