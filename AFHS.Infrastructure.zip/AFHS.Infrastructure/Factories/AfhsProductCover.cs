﻿using Afhs.Data.Obec;
using AFM.Commerce.Framework.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Factories
{
    public static class AfhsProductCover
    {
        public static Cover Create(AFMItemCovers source)
        {
            var item = new Cover
            {
                CleaningDescription = source.CleaningDescription,
                CleaningId = source.CleaningId,
                Contents = source.Contents,
                CoverColor = source.CoverColor,
                CoverId = source.CoverId,
                CoverName = source.CoverName,
                Location = source.Location,
                LongDescription = source.LongDescription,
                //Cover.ExternalId can't be the same value as the Product.ExternalId, needs to be something 
                //unique to the combination of Product.ExternalId & some other key; in this case chose CoverId
                //if these two ids are the same only one item will save as a child item of the product.
                ExternalId = source.CoverId,
                ProductRecordId = source.ProductRecordId
            };

            return item;
        }
    }
}
