﻿using Afhs.Data.Models.sitecore.templates.User_Defined;
using Microsoft.Dynamics.Retail.Ecommerce.Sdk.Core.Models;
using Afhs.Infrastructure.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Afhs.Data.CustomClasses;

namespace Afhs.Infrastructure.Factories
{
    public class MicrosoftCoreSdkListingModelFactory
    {
        public static Listing Create()
        {
            return new Listing();
        }

        public static string CreateAsJson(CustomProduct productItem, int quantity)
        {
            var listing = MicrosoftCoreSdkListingModelFactory.Create(productItem, quantity);

            return JsonConvert.SerializeObject(listing);
        }

        public static Listing Create(CustomProduct productItem, int quantity, bool forJson = false)
        {
            if (productItem == null)
            {
                //TODO figure out how we want to log this issue?
                return new Listing();
            }

            ImageData image = ImageHelper.GetImageData(productItem);
            var productDescription = !string.IsNullOrEmpty(productItem.ItemFluff) ? productItem.ItemFluff.Trim() : string.Empty;
            var style = String.IsNullOrEmpty(productItem.ProductAttributes["StyleDescription"]) ?
                String.Empty : productItem.ProductAttributes["StyleDescription"];
            var color = String.IsNullOrEmpty(productItem.ProductAttributes["ColorDescription"]) ?
                String.Empty : productItem.ProductAttributes["ColorDescription"];
            var consumerDescription = String.IsNullOrEmpty(productItem.ProductAttributes["ConsumerDescription"]) ?
                String.Empty : productItem.ProductAttributes["ConsumerDescription"];
            var size = String.IsNullOrEmpty(productItem.Size) ?
                String.Empty : productItem.Size;
            var dimensions = GetDimensions(productItem);
            var productUrl = productItem.ProductUrl;
            return Create(productItem.ExternalID, productItem.RecordId, productDescription, productItem.DisplayName, quantity,
                image.GetURL(Afhs.Data.Enums.ImagePresetKeys.afhs_cart_thumb), image.ImageAlt, consumerDescription, color, style, size, dimensions, productUrl, forJson);
        }

        private static string GetDimensions(CustomProduct product)
        {
            var dimensions = string.Empty;
            bool hasBasicDimensions = !string.IsNullOrEmpty(string.Format("{0}{1}{2}", product.ProductHeightInches, product.ProductWidthInches, product.ProductDepthInches));
            if (hasBasicDimensions)
            {
                //&quot;&quot;
                Decimal aux;
                if (!string.IsNullOrEmpty(product.ProductWidthInches) && Decimal.TryParse(product.ProductWidthInches, out aux))
                    dimensions += string.Format("{0}'' w x ", aux.ToString("##.##"));
                if (!string.IsNullOrEmpty(product.ProductDepthInches) && Decimal.TryParse(product.ProductDepthInches, out aux))
                    dimensions += string.Format("{0}'' d x ", aux.ToString("##.##"));
                if (!string.IsNullOrEmpty(product.ProductHeightInches) && Decimal.TryParse(product.ProductHeightInches, out aux))
                    dimensions += string.Format("{0}'' h", aux.ToString("##.##"));
                if (dimensions.EndsWith(" x "))
                    dimensions = dimensions.Remove(dimensions.LastIndexOf(" x "));
            }
            return dimensions;
        }

        public static Listing Create(string externalId, string recordId, string productFullDescription, string name,
            int quantity, string imageUrl, string imageAlt, string consumerDescription,
            string color, string style, string size = "", string dimensions = "", string url = "", bool forJson = false)
        {
            var productDetails = String.Empty;

            if (forJson)
            {
                productDetails = GetProductDetailsForJson(name, productFullDescription, imageUrl, imageAlt,
                    consumerDescription, color, style, size, dimensions, url);
            }
            else
            {
                productDetails = GetProductDetails(name, productFullDescription, imageUrl, imageAlt,
                    consumerDescription, color, style, size, dimensions, url);
            }

            return new Listing
            {
                ItemId = externalId,
                ListingId = long.Parse(recordId),
                ProductDetails = productDetails,
                Quantity = quantity
            };
        }

        private static string GetProductDetails(string name, string description, string imageUrl, string imageAlt,
            string consumerDescription, string color, string style, string size, string dimensions, string url)
        {
            var encodedName = HttpUtility.JavaScriptStringEncode(name);
            var encodedDescription = HttpUtility.JavaScriptStringEncode(description);
            var encodedUrl = HttpUtility.JavaScriptStringEncode(url);
            var encodedSize = HttpUtility.JavaScriptStringEncode(size);
            var productDimensions = new ListingProductDimension
            {
                Color = color,
                Dimension = dimensions,
                //Style = style,
                Size = encodedSize
            };

            var productDetails = new ListingProductDetails
            {
                Name = encodedName,
                ProductUrl = encodedUrl,                
                //Description = string.IsNullOrEmpty(encodedDescription) ? encodedDescription : (encodedDescription.Length > 100 ? encodedDescription.Substring(0, 100) : encodedDescription),
                Description = TruncatDescription(encodedDescription, 100),
                ImageUrl = imageUrl,
                ImageAlt = imageAlt,
                DimensionValues = productDimensions
            };
            var jsonResponse = JsonConvert.SerializeObject(productDetails,
                new JsonSerializerSettings { PreserveReferencesHandling = PreserveReferencesHandling.None });

            return jsonResponse;
        }

        private static string GetProductDetailsForJson(string name, string description, string imageUrl, string imageAlt,
            string consumerDescription, string color, string style, string size, string dimensions, string url)
        {
            var productDimensions = new ListingProductDimension
            {
                Color = color,
                Dimension = dimensions,
                //Style = style,
                Size = size
            };

            var productDetails = new ListingProductDetails
            {
                Name = name,
                ProductUrl = url,               
				//Description = string.IsNullOrEmpty(description) ? description : (description.Length > 100 ? description.Substring(0, 100) : description),
                Description = TruncatDescription(description, 100),
                ImageUrl = imageUrl,
                ImageAlt = imageAlt,
                DimensionValues = productDimensions
            };
            var jsonResponse = JsonConvert.SerializeObject(productDetails, new JsonSerializerSettings { StringEscapeHandling = StringEscapeHandling.EscapeHtml, PreserveReferencesHandling = PreserveReferencesHandling.None });

            return jsonResponse;
        }
        //Incident INC0144865
        private static string TruncatDescription(string description, int length)
        {
            int index = 0;
            if (!string.IsNullOrEmpty(description))
            {
                if (description.Length > length)
                {
                    description = description.Substring(0, length);
                    index = description.LastIndexOf(' ');
                    if (index > 0)
                    {
                        description = description.Substring(0, index);
                    }
                }
            }
            return description;
        }
    }
}
