﻿using Afhs.Data.CustomClasses;
using Afhs.Data.CustomClasses.Search;
using Afhs.Data.Models.sitecore.templates.User_Defined;
using Afhs.Infrastructure.Helpers;
using Glass.Mapper.Sc;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Links;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Afhs.Infrastructure.Factories.Search
{
    public class ProductThumbnailFactory
    {
        public static ProductThumbnail Create()
        {
            throw new NotImplementedException();
        }

        public static ProductThumbnail Create(ProductSearchResultItem productSearchResultItem)
        {
            try
            {
                var imageData = ImageHelper.GetImageData(productSearchResultItem.DisplayName,
                    productSearchResultItem.PrimaryImageID,
                    productSearchResultItem.ImageSetID,
                    productSearchResultItem.ExternalID);

                var RolloverImageData = ImageHelper.GetImageData(productSearchResultItem.DisplayName,
                    productSearchResultItem.RolloverImage,
                    productSearchResultItem.ImageSetID,
                    productSearchResultItem.ExternalID);

                // don't include rollover image if image is not found
                if (RolloverImageData.ImageNotFound)
                {
                    RolloverImageData = null;
                }

                var colorSwatchGroup = SwatchGroupHelper.GetAvailableColors(productSearchResultItem.GetItem().GlassCast<CustomProduct>(), true);

                return Create(productSearchResultItem.ItemId.ToGuid(),
                    productSearchResultItem.Language, productSearchResultItem.Uri,
                    productSearchResultItem.Url,
                    productSearchResultItem.ExternalID,
                    productSearchResultItem.DisplayName,
                    productSearchResultItem.DisplayName,
                    productSearchResultItem.DisplayRank,
                    imageData == null ? String.Empty : imageData.GetURL(Data.Enums.ImagePresetKeys.product_grid_large),
                    imageData == null ? String.Empty : imageData.GetURL(Data.Enums.ImagePresetKeys.product_grid_small),
                    RolloverImageData == null ? String.Empty : RolloverImageData.GetURL(Data.Enums.ImagePresetKeys.product_grid),
                    productSearchResultItem.ItemStatusActivationDate,
                    productSearchResultItem.SeriesNumber,
                    productSearchResultItem.SwatchGroupId,
                    colorSwatchGroup,
                    productSearchResultItem.Color2,
                    productSearchResultItem.ColorDescription,                    
                    productSearchResultItem.EcommAlsoAvailable,
                    productSearchResultItem.Size,
                    productSearchResultItem.Size2,
                    productSearchResultItem.Size3,
                    productSearchResultItem.Size4,
                    productSearchResultItem.Size5,
                    productSearchResultItem.BestSeller,
                    productSearchResultItem.IsNew,
                    productSearchResultItem.OnSale,
                    productSearchResultItem.IsItemStatusCurrent,
                    true,
                    productSearchResultItem.IsECommOwned,
                    productSearchResultItem.IsDefaultProduct
                    );
            }
            catch(Exception ex)
            {
                var errorMessage = new StringBuilder();
                errorMessage.Append("Error creating product Thumbnail.");
                errorMessage.AppendLine();
                errorMessage.Append("Message: ");
                errorMessage.Append(ex.Message);
                errorMessage.AppendLine();
                errorMessage.Append("Errored Product: ");
                errorMessage.Append(productSearchResultItem.Url);
                errorMessage.AppendLine();
                errorMessage.Append("StackTrace: ");
                errorMessage.Append(ex.StackTrace);
                Log.Error(errorMessage.ToString(), typeof(ProductThumbnailFactory));
                throw ex;

            }
        }

        public static ProductThumbnail Create(Guid itemId, string language, ItemUri uri, string url,
            string externalId, string displayName, string displayNameForSorting, 
            int displayRank, string imageUrlLarge, 
            string imageUrlSmall, string RolloverImageUrl, DateTime itemStatusActivationDate,string seriesNumber, string swatchGroupId, List<ColorSwatchGroupItem> colorSwatch, 
            string color2, string colorDescription, string ecommAlsoAvailable, string size, string size2, string size3, string size4, string size5, bool isBestSeller = false, 
            bool isNew = false, bool isOnSale = false, bool isCurrent = false, bool isSoldInStoresOnly = true, bool isEcommOwned = false, bool isDefaultProduct = false)
        {
            var productThumbnail = new ProductThumbnail
            {
                DisplayName = displayName,
                DisplayNameForSorting = displayNameForSorting,
                ExternalId = externalId,
                Id = itemId,
                ImageUrlLarge = imageUrlLarge,
                ImageUrlSmall = imageUrlSmall,
                RolloverImageUrl = RolloverImageUrl,
                IsBestSeller = isBestSeller,
                IsCurrent = isCurrent,
                IsNew = isNew,
                IsOnSale = isOnSale,
                IsSoldInStoresOnly = isSoldInStoresOnly,
                ItemStatusActivationDate = itemStatusActivationDate,
                Language = language,
                DisplayRank = displayRank,
                //RegularPrice
                //SalePrice
                Uri = uri,
                Url = url,
                ColorSwatch = colorSwatch,
                MultiColor = colorSwatch.Count > 1,
                IsEcommOwned = isEcommOwned,
                Color2 = color2,
                ColorDescription = colorDescription,
                IsDefaultProduct = isDefaultProduct, 
                SwatchGroupId = swatchGroupId,
                SeriesNumber = seriesNumber,
                EcommAlsoAvailable = ecommAlsoAvailable,
                Size = size,
                Size2 = size2,
                Size3 = size3,
                Size4 = size4,
                Size5 = size5,
            };

            return productThumbnail;
        }


    }
}
