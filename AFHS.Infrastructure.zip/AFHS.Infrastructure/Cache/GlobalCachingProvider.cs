﻿
using Afhs.Data.Models.sitecore.templates.User_Defined.Configuration;
using Glass.Mapper.Sc;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Runtime.Caching;
using System.Text;

namespace Afhs.Infrastructure.Cache
{
    public class GlobalCachingProvider<T> :CachingProviderBase
    {
        private bool IsDisposed;
        static readonly object padlock = new object();
        static int SLIDINGEXPIRATION = 2; //hours (cache will be refresed only if is not used)
        static string CACHEMEMORYLIMIT = "1000"; //MB
        static string PHYSICALMEMORYLIMIT = "5"; // Percentage
        static string POLLINGINTERVAL = "59"; // In Seconds

        #region Singelton (inheriting enabled)

        public GlobalCachingProvider(string name, NameValueCollection config = null)
        {
            config = ConfigureCacheSettings(name);
            Cache = config != null ? new MemoryCache(name, config) : new MemoryCache(name);
            
            DeleteLog();
        }

        public static GlobalCachingProvider<T> Instance
        {
            get
            {
                return Nested.instance;
            }
        }

        class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }
            internal static string CacheName = typeof(T).ToString().Substring(typeof(T).ToString().LastIndexOf('.')).Replace(".", "");
            internal static readonly GlobalCachingProvider<T> instance = new GlobalCachingProvider<T>(CacheName);
        }

        #endregion

        protected static NameValueCollection ConfigureCacheSettings(string name)
        {
            var cacheItemExpiryTime = ConfigurationManager.AppSettings["PriceCacheExpiryTime"];
            //CacheSettings settings = new SitecoreContext().GetItem<CacheSettings>(string.Format("{0}/{1}CacheSettings", Constants.GetContentPath("DEFAULT_CONFIGURATION_PATH"), name));
            CacheSettings settings = null;
            CacheItemPolicy = new CacheItemPolicy();
            NameValueCollection collection = new NameValueCollection();

            if (settings != null)
            {
                if (!string.IsNullOrEmpty(settings.AbsoluteExpiration))
                {
                    CacheItemPolicy.AbsoluteExpiration = DateTimeOffset.UtcNow.AddHours(Convert.ToDouble(settings.AbsoluteExpiration));
                }
                else if (!string.IsNullOrEmpty(settings.SlidingExpiration))
                {
                    CacheItemPolicy.SlidingExpiration = TimeSpan.FromHours(Convert.ToInt32(settings.SlidingExpiration));
                }
                else
                {
                    CacheItemPolicy.SlidingExpiration = TimeSpan.FromHours(SLIDINGEXPIRATION);
                }

                CacheItemPolicy.Priority = settings.PriorityNotRemovable ? CacheItemPriority.NotRemovable : CacheItemPriority.Default;
                //UpdateCallback = settings.UpdateCallback


                collection.Add("cacheMemoryLimitMegabytes", string.IsNullOrEmpty(settings.CacheMemoryLimit) ? CACHEMEMORYLIMIT : settings.CacheMemoryLimit);
                collection.Add("physicalMemoryLimitPercentage", string.IsNullOrEmpty(settings.PhysicalMemoryLimit) ? PHYSICALMEMORYLIMIT : settings.PhysicalMemoryLimit);
                collection.Add("pollingInterval", string.Format("00:00:{0}", string.IsNullOrEmpty(settings.PollingInterval) ? POLLINGINTERVAL : settings.PollingInterval));
            }
            else
            {
                CacheItemPolicy.AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(Convert.ToInt32(cacheItemExpiryTime ?? "1440"));                
                collection.Add("cacheMemoryLimitMegabytes", CACHEMEMORYLIMIT );               
            }
            return collection;
        }




        public virtual void AddItem(string key, object value)
        {
            base.AddItem(key, value);

        }

        public virtual void RemoveItem(string key)
        {
            base.RemoveItem(key);
        }

        public virtual object GetItem(string key, bool remove)
        {
            return base.GetItem(key, false);//Remove defulat is true because it's Global Cache!

        }

        public virtual object GetItem(string key)
        {
            return this.GetItem(key, false);
        }        
    }
}
