﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Caching;

namespace Afhs.Infrastructure.Cache
{
    public abstract class CachingProviderBase
    {
        protected static CacheItemPolicy CacheItemPolicy { get; set; }
        private bool IsDisposed;
        public MemoryCache Cache;
        static readonly object padlock = new object();

        public CachingProviderBase()
        {
            IsDisposed = false;
            DeleteLog();
        }


        protected virtual void AddItem(string key, object value)
        {


            lock (padlock)
            {
                Cache.Set(key, value, CacheItemPolicy);
            }
        }

        protected virtual void RemoveItem(string key)
        {
            lock (padlock)
            {
                Cache.Remove(key);
            }
        }

        protected virtual object GetItem(string key, bool remove)
        {
            lock (padlock)
            {
                var res = Cache[key];

                if (res != null)
                {
                    if (remove == true)
                        Cache.Remove(key);
                }
                else
                {
                    //WriteToLog("CachingProvider-GetItem: Don't contains key: " + key);
                }

                return res;
            }
        }

        #region Error Logs

        string LogPath = System.Environment.GetEnvironmentVariable("TEMP");

        protected void DeleteLog()
        {
            System.IO.File.Delete(string.Format("{0}\\CachingProvider_Errors.txt", LogPath));
        }

        protected void WriteToLog(string text)
        {
            using (System.IO.TextWriter tw = System.IO.File.AppendText(string.Format("{0}\\CachingProvider_Errors.txt", LogPath)))
            {
                tw.WriteLine(text);
                tw.Close();
            }
        }

        #endregion
    }
}
